/*
 * Copyright 2018-2022 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_SERIAL_TRANSPORT_H_
#define INC_SERIAL_TRANSPORT_H_

/* Stream and Print are only defined by Arduino.h in c++ builds */

#ifdef __cplusplus

#include "../sdk/inc/transport_api.h"

enum debugLevel_e {
    DEBUG_NONE,
    DEBUG_NORMAL,
    DEBUG_VERBOSE
};

/**
 * Create a Transport instance that transfers bytes over a
 * serial port/uart.
 *
 * @param serial HardwareSerial or SoftwareSerial instance for the uart
 * @param lineBased set to 'false' unless using modem USSD support which
 *                  requires line-based reads
 * @param debugOut Print instance used for debug logging
 * @param debugLevel level of debug output required
 */
ThingstreamTransport* serial_transport_create(Stream* serial, bool lineBased, Print* debugOut, enum debugLevel_e debugLevel);

#endif /* __cplusplus */

#endif /* INC_SERIAL_TRANSPORT_H_ */
