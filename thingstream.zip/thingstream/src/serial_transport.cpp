/*
 * Copyright 2018-2023 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <Arduino.h>

#include "thingstream.h"

typedef struct SerialTransportState_s {
    uint8_t buffer[THINGSTREAM_USSD_BUFFER_LEN];
    ThingstreamTransportCallback_t callback;
    void* callback_cookie;
    Stream* serial;
    Print* debugOut;
    enum debugLevel_e debugLevel;
    bool lineBased;
    bool overflowed;
    uint32_t timeStamp;
} SerialTransportState;

static SerialTransportState _transport_state;

static ThingstreamTransportResult serial_init(ThingstreamTransport* self, uint16_t version);
static ThingstreamTransportResult serial_shutdown(ThingstreamTransport* self);
static ThingstreamTransportResult serial_get_buffer(ThingstreamTransport* self, uint8_t** buffer, uint16_t* len);
static ThingstreamTransportResult serial_send(ThingstreamTransport* self, uint16_t flags, uint8_t* data, uint16_t len, uint32_t millis);
static ThingstreamTransportResult serial_register_callback(ThingstreamTransport* self, ThingstreamTransportCallback_t callback, void* cookie);
static ThingstreamTransportResult serial_run(ThingstreamTransport* self, uint32_t millis);

static const ThingstreamTransport _transport_instance = {
    (ThingstreamTransportState_t*)&_transport_state,
    serial_init,
    serial_shutdown,
    serial_get_buffer,
    NULL, /* This slot no longer used */
    serial_send,
    serial_register_callback,
    NULL, /* This slot no longer used */
    serial_run
};

ThingstreamTransport* serial_transport_create(Stream* serial, bool lineBased, Print* debugOut, enum debugLevel_e debugLevel)
{
    ThingstreamTransport *self = (ThingstreamTransport*)&_transport_instance;
    SerialTransportState* state = (SerialTransportState*)self->_state;
    state->serial = serial;
    state->debugOut = debugOut;
    state->debugLevel = debugLevel;
    state->lineBased = lineBased;
    state->overflowed = false;
    return self;
}

static ThingstreamTransportResult serial_init(ThingstreamTransport* self, uint16_t version)
{
    SerialTransportState* state = (SerialTransportState*)self->_state;
    if (!TRANSPORT_CHECK_VERSION_1(version))
    {
        return TRANSPORT_VERSION_MISMATCH;
    }
    if (state->debugLevel >= DEBUG_VERBOSE)
    {
        state->debugOut->println("serial init");
    }
    return TRANSPORT_SUCCESS;
}

static ThingstreamTransportResult serial_shutdown(ThingstreamTransport* self)
{
    UNUSED(self);
    return TRANSPORT_SUCCESS;
}

static ThingstreamTransportResult serial_get_buffer(ThingstreamTransport* self, uint8_t** buffer, uint16_t* len)
{
    SerialTransportState* state = (SerialTransportState*)self->_state;
    *buffer = state->buffer;
    *len = sizeof(state->buffer);
    return TRANSPORT_SUCCESS;
}

static ThingstreamTransportResult serial_send(ThingstreamTransport* self, uint16_t flags, uint8_t* data, uint16_t len, uint32_t millis)
{
    UNUSED(flags);
    UNUSED(millis);
    SerialTransportState* state = (SerialTransportState*)self->_state;
    if (state->debugLevel >= DEBUG_NORMAL)
    {
        state->debugOut->print(">>> ");
        state->debugOut->write(data, len);
    }
    state->serial->write(data, len);
    return TRANSPORT_SUCCESS;
}

static ThingstreamTransportResult serial_register_callback(ThingstreamTransport* self, ThingstreamTransportCallback_t callback, void* cookie)
{
    SerialTransportState* state = (SerialTransportState*)self->_state;
    state->callback = callback;
    state->callback_cookie = cookie;
    return TRANSPORT_SUCCESS;
}

/* Output debug logging to support the serial_run routine. */
static void serial_run_debug_output(SerialTransportState* state, int numBytes)
{
    if (numBytes > 0)
    {
        if (state->callback != NULL)
        {
            if (state->debugLevel >= DEBUG_NORMAL)
            {
                state->debugOut->print("<<< (");
                state->debugOut->print(numBytes);
                state->debugOut->print(") ");
                state->debugOut->write(state->buffer, numBytes);
                state->debugOut->println();
            }
        }
        else
        {
            if (state->debugLevel >= DEBUG_VERBOSE)
            {
                state->debugOut->print(numBytes);
                state->debugOut->println(" bytes discarded");
            }
        }
    }
}

static ThingstreamTransportResult serial_run(ThingstreamTransport* self, uint32_t millis)
{
    SerialTransportState* state = (SerialTransportState*)self->_state;
    size_t count = 0;

    uint32_t now = Thingstream_Platform_getTimeMillis();
    uint32_t limit = now + millis;

    ThingstreamTransportResult ret = TRANSPORT_READ_TIMEOUT;

    /* Read bytes with an overall timeout of 'millis'. Stop if the
     * receive buffer is full.
     * Wait up to 'millis' for the first byte but then only wait
     * 10ms for each subsequent byte.
     *
     * Line-based (modem USSD)
     * - stop reading when \n received
     * - if no new-line is received before the buffer is full or
     *   the read times-out then discard this partial line and
     *   also the next partial line.
     */
    do
    {
        int val = state->serial->read();
        if (val >= 0)
        {
            ret = TRANSPORT_SUCCESS;

            state->buffer[count++] = (uint8_t)val;
            if (state->lineBased)
            {
                if (val == '\n')
                    goto new_line;
            }
            if (count >= sizeof(state->buffer))
                break;
            limit = now + 10; /* wait 10ms for subsequent bytes */
        }
        if ((state->debugLevel >= DEBUG_VERBOSE)
            && (TIME_COMPARE(now, >=, state->timeStamp)))
        {
            state->debugOut->print(now);
            state->debugOut->println("ms ");
            state->timeStamp = now + 1000;
        }
        yield();
        now = Thingstream_Platform_getTimeMillis();
    } while (TIME_COMPARE(now, <, limit));

    if (state->lineBased)
    {
        if (count > 0)
        {
            /* Incomplete line received due to buffer overflow or timeout.
             * Take note, so that the next partial line can also be
             * discarded.
             */
            state->overflowed = true;
            ret = TRANSPORT_READ_OVERFLOW;

            if (state->debugLevel >= DEBUG_NORMAL)
            {
                state->debugOut->print(count);
                state->debugOut->println(" bytes discarded");
            }
        }
        return ret;
    }

new_line:
    if (state->overflowed == true)
    {
        /* Received a partial line last time. This is the remainder
         * of that partial line. Discard it and return an error.
         */
        state->overflowed = false;

        if (state->debugLevel >= DEBUG_NORMAL)
        {
            state->debugOut->print(count);
            state->debugOut->println(" bytes discarded");
        }

        return TRANSPORT_READ_OVERFLOW;
    }

    serial_run_debug_output(state, count);

    if ((state->callback != NULL) && (count > 0))
    {
        state->callback(state->callback_cookie, state->buffer, count);
    }

    return ret;
}
