/*
 * Copyright 2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_BITARRAY_H_
#define INC_BITARRAY_H_

#include <stdint.h>

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

/* These apis help construct a contiguous sequence of bit fields
 * of varying width.
 * The first bit added is the the most signifiant bit of the first byte.
 *
 * E.g.
 *
 *    uint8_t data[2];
 *    BitArray_t array;
 *    bitarray_init(&array, data, 2);
 *    bitarray_appendValue(&array, 0, 5);     // Write  0x0 to data[0] 7..3
 *    bitarray_appendValue(&array, 0x0B, 4);  // write  0x5 to data[0] 2..0
 *                                            //    and 0x1 to data[1] bit 7
 *    bitarray_appendValue(&array, 0x59, 7);  // write 0x59 to data[1] 6..0
 *
 * results in data[1] containing 0xD5 and data[0] containing 0x05
 */
typedef struct __bitarray
{
    uint16_t capacity;
    uint16_t size;
    uint8_t *bytes;
} BitArray_t;

/**
 * Initialise the given bit-array.
 * The next call to bitarray_appendValue() will write to bit 7 of bytes[0].
 *
 * @param array the bit-array structure
 * @param bytes the storage area for the bit-array
 * @param len the size in bytes of the storage area
 */
void bitarray_init(BitArray_t* array, uint8_t* bytes, uint16_t len);

/*
 * Extend the given bit array by the given bits (most significant first).
 *
 * Equivalent to:
 *
 *     for (int shift = width - 1; shift >= 0; shift--)
 *     {
 *         bitarray_appendValue(array, (value >> shift) & 1, 1);
 *     }
 *
 * @param array the bit-array structure
 * @param value the bits to extend
 * @param width the width in bits of the value to add.
 */
void bitarray_appendValue(BitArray_t* array, uint32_t value, uint8_t width);

#if defined(__cplusplus)
}
#endif

#endif /* INC_BITARRAY_H_ */
