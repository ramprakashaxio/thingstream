/*
 * Copyright 2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_MEASX_H_
#define INC_MEASX_H_

#include <stdint.h>
#include <stdbool.h>

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif


/**
 * Initialize the ublox GNSS extension message parser and the generic
 * GNSS NMEA parsing module.
 * Also initialise pins associated with the GNSS.
 * This can be called instead of GnssNmea_init().
 * It can safely be called at any time to turn GNSS functionality on or off.
 * Explicitly disabling GNSS using this function will save power.
 *
 * @param enable true if GNSS should be enabled
 * @param measxBuf a buffer to contain parsed UBX-RXM-MEASX messages.
 * @param measxSize the size of the measxBuf buffer in bytes.
 * @return the cookie to be passed to GnssNmea_callback
 */
extern void *GnssNmeaMeasx_init(bool enable, uint8_t* measxBuf, uint16_t measxSize);
/** TODO */
#define MEASX_MAX_MEASUREMENTS 64

/*
 * Obtain a valid MEASX record if one is available.
 *
 * @param measxData address of variable to receive pointer to measx data
 * @param measxLen  address of variable to receive pointer to measx length
 * @return true if the MEASX record is valid (and measxData/measxLen updated)
 */
extern bool GnssMeasx_valid(char **measxData, uint16_t *measxLen);

#if defined(__cplusplus)
}
#endif

#endif /* INC_MEASX_H_ */
