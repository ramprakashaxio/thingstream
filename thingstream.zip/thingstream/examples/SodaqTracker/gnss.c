/*
 * Copyright 2021-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/* An implementaion of Gnss_get_location() which retrieves NMEA
 * sentences from the M8Q device over I2C,
 */

#include <Arduino.h>
#include <stdint.h>
#include <stddef.h>

#include <thingstream.h>
#include "gnss.h"
#include "gnss_parser.h"
#include "platform.h"


uint8_t Gnss_get_location(uint32_t maxtime, int32_t *lat, int32_t *lon)
{
    uint8_t gnssFixQuality = 0;

    /* Turn on GNSS and initialise NMEA parser */
    void *gnss_cookie = GnssNmea_init(true);

    uint32_t now = Thingstream_Platform_getTimeMillis();
    uint32_t gnssTimeout = now + maxtime;

    /* Wait for a fix */

    for (;;)
    {
        if (TIME_COMPARE(now, >=, gnssTimeout))
        {
            DEBUGOUT("Failed to latch GNSS location\n");
            break;
        }

        uint8_t buffer[250];  // keep this less than 256
        uint32_t count = Platform_gnssRecv(buffer, sizeof(buffer));

        if (count)
        {
            GnssNmea_callback(gnss_cookie, buffer, count);
        }

        gnssFixQuality = GnssNmea_getQuality();
        if (gnssFixQuality)
        {
            DEBUGOUT("GNSS location determined successfully (%d)\n", gnssFixQuality);
            *lat = GnssNmea_getLatitude();
            *lon = GnssNmea_getLongitude();
            break;
        }

        delay(250);

        now = Thingstream_Platform_getTimeMillis();
    }

    GnssNmea_init(false);

    return gnssFixQuality;
}
