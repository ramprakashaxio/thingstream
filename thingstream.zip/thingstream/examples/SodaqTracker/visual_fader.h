/*
 * Copyright 2021-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _VISUAL_H_
#define _VISUAL_H_

/* An implementation of the "visual" abstraction that uses
 * the LED fader.
 *
 * VISUALISE(STARTING, COMPONENT) -> Led_Background(r,g,b)
 * VISUALISE(SUCCESS,  COMPONENT) -> Led_Flash(r,g,b, 500, 500, 1)
 * VISUALISE(ERROR, COMPONENT)    -> Led_Flash(100, 0, 0, ...)
 *
 */

#include "led_fader.h"

/* Assign rgb triplets to the various components */
#define VIS_RGB_TRACKER  0,100,0
#define VIS_RGB_GNSS     100,100,0
#define VIS_RGB_MEASX    100,100,100
#define VIS_RGB_CELL     0,100,100
#define VIS_RGB_WIFI     0,0,100
#define VIS_RGB_PUBLISH  100,0,100

/* And the error patterns - on time, off time, count */
#define VIS_ERROR_TRACKER  500,500,1
#define VIS_ERROR_GNSS     750,250,2
#define VIS_ERROR_MEASX    750,250,3
#define VIS_ERROR_CELL     500,500,2
#define VIS_ERROR_WIFI     250,750,2
#define VIS_ERROR_PUBLISH  200,200,5

/* Implementation details */

#define VIS_CONCAT2(a,b)    a ## b
#define VIS_STARTING(component)  Led_Background(VIS_CONCAT2(VIS_RGB_,component))
#define VIS_SUCCESS(component)   Led_Flash(VIS_CONCAT2(VIS_RGB_,component), 500, 500, 1)
#define VIS_PROGRESS(component)  Led_Flash(VIS_CONCAT2(VIS_RGB_,component), 250, 250, 2)
#define VIS_ERROR(component)     Led_Flash(100, 0, 0, VIS_CONCAT2(VIS_ERROR_,component))

/* The public interface */

#define VISUALISE(status, component)  \
      VIS_CONCAT2(VIS_, status)(component)

#define VISUALISE_NONE()  Led_Background(0, 0, 0)

#endif /* _VISUAL_H_ */
