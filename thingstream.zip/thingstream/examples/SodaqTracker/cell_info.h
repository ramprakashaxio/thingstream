/*
 * Copyright 2017-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_CELL_INFO_H_
#define INC_CELL_INFO_H_

#include <stdint.h>
#include <stdbool.h>

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

typedef struct cellinfo_s {
    int16_t rssi;    /* 0-31, or 99 for unknown */
    char mcc[4];     /* 3 digits + \0 */
    char mnc[4];     /* 3 digits + \0 */
    char cellId[9];  /* 8 hex digits + \0 */
    char lac[9];     /* 8 hex digits + \0 */
} CellInfo;

#define EMPTY_CELLINFO { 99, "", "", "", "" };


/**
 * Determine the cell tower information.
 * @param modem an initialised modem transport instance
 * @param send_modem_line the corresponding modem_sendLine function
 * @param count a pointer which is set to the number of results found
 * @return the cell information array, or NULL on error
 */
CellInfo *get_cell_info(ThingstreamTransport *modem,
                        ThingstreamTransportResult (*send_modem_line)(ThingstreamTransport* self, const char* line, uint32_t millis),
                        int *count);

/**
 * The AT commands needed to triangulate location from mobile cell towers
 * varies depending on modem.
 * The following defines are used to select the desired command and parser.
 *
 * When the type of modem is known the command and parser can be explicitly
 * selected by defining LOCATE_MOBILE_CELL_METHODS to one (or more) of the values
 * below.
 */
#define LOCATE_MOBILE_CELL_NONE        (1U << 0)  /* No location code required. */
#define LOCATE_MOBILE_CELL_CNETSCAN    (1U << 1)  /* E.g. Sim868 */
#define LOCATE_MOBILE_CELL_QOPS        (1U << 2)  /* E.g. Quectel UG95 */
#define LOCATE_MOBILE_CELL_QENG        (1U << 3)  /* E.g. Quectel M66 */
#define LOCATE_MOBILE_CELL_CSURVC      (1U << 4)  /* E.g. Telit GL865 */
#define LOCATE_MOBILE_CELL_CxREG       (1U << 5)  /* None, fake it with +CxREG: and +COPS: */
#define LOCATE_MOBILE_CELL_UCFSCAN     (1U << 6)  /* E.g. Sara r422 */
#define LOCATE_MOBILE_CELL_ANY         (0xFFFFFFFF)  /* Try all versions */

#if defined(__cplusplus)
}
#endif

#endif /* INC_CELL_INFO_H_ */
