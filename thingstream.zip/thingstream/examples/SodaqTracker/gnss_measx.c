/*
 * Copyright 2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <assert.h>
#include <stdint.h>
#include <stdbool.h>

#include <stdio.h>
#include <string.h>

#include "ubx_proto.h"
#include "gnss_parser.h"
#include "gnss_measx.h"
#include "bitarray.h"
#include "base64.h"
#include "platform.h"

#define MIN(i, j) (((i) < (j)) ? (i) : (j))
#define MAX(i, j) (((i) > (j)) ? (i) : (j))

/** Length of the MEASX header */
#define MEASX_HEADER_LEN 44

/** Offset of the satellite count within the header */
#define MEASX_OFF_NUMSV 34

/** Length of one measurement block */
#define MEASX_BLOCK_LEN 24

#define MEASX_BLOCK_OFF_GNSSID 0
#define MEASX_BLOCK_OFF_SVID 1
#define MEASX_BLOCK_OFF_CNO 2
#define MEASX_BLOCK_OFF_MPI 3
#define MEASX_BLOCK_OFF_DOPPLERHZ 8
#define MEASX_BLOCK_OFF_CPMS 16
#define MEASX_BLOCK_OFF_PRRMS 21

#define MEASX_BLOCK_START(n) (MEASX_HEADER_LEN + n * MEASX_BLOCK_LEN)

#define MEAS50_MAX_MEASUREMENTS 13
#define MEAS50_MAX_DOPPLER 7

#define MEAS50_GNSS_BITS 2
#define MEAS50_SVID_BITS 6
#define MEAS50_CHIP_BITS 17
#define MEAS50_DOPPLER_BITS 12

#define MEAS50_MAX_BITS \
    (MEAS50_MAX_MEASUREMENTS * (MEAS50_GNSS_BITS + MEAS50_SVID_BITS + MEAS50_CHIP_BITS) + \
    ((MEAS50_MAX_DOPPLER - 1) * MEAS50_DOPPLER_BITS))

#define MEAS50_NUM_GNSS_IDS 4

#define CONF_GNSS 0
#define CONF_MINSV 5
#define CONF_MIN_CNO 25
#define CONF_MAX_MULTIPATH 2
#define CONF_MAX_PRRMS 39

static const char* GNSS_STR[MEAS50_NUM_GNSS_IDS+1] =
    { "GPS", "GAL", "BDS", "GLO", "OTH"};

/**
 * Map from UBX GNSS IDs to the four supported IDs in
 * MEAS50. All others are mapped to MEAS50_NUM_GNSS_IDS.
 */
static uint8_t mapGnssID(uint8_t ubx_id) {
    static const uint8_t map[] = {
        0,                   /* GPS */
        MEAS50_NUM_GNSS_IDS, /* UNUSED */
        1,                   /* Galileo */
        2,                   /* BeiDou */
        MEAS50_NUM_GNSS_IDS, /* UNUSED */
        MEAS50_NUM_GNSS_IDS, /* QZSS UNSUPPORTED */
        3                    /* GLONASS */
    };
    if (ubx_id < sizeof(map)) {
        return map[ubx_id];
    }
    return MEAS50_NUM_GNSS_IDS;
};

static BitArray_t meas50;
#define MEAS50_SIZE_BYTES ((MEAS50_MAX_BITS + 7) / 8)
static uint8_t ubx_rxm_meas50_bytes[6 + MEAS50_SIZE_BYTES + 2];
static char ubx_rxm_meas50_base64[BASE64_LEN(sizeof(ubx_rxm_meas50_bytes)) + 1];
static uint8_t *meas50_bytes = ubx_rxm_meas50_bytes + 6;

static int32_t readInt32(uint8_t* bytes) {
    int32_t value = 0;
    for (int i = 0; i < 4; i++) {
        value |= bytes[i] << (8*i);
    }
    return value;
}

static void printMeasurement(uint8_t *block, uint8_t num, uint8_t index) {
    uint8_t gnssID = mapGnssID(block[MEASX_BLOCK_OFF_GNSSID]);
    assert(gnssID < sizeof(GNSS_STR));
    uint8_t satID = block[MEASX_BLOCK_OFF_SVID];
    int32_t dopplerHz = readInt32(block + MEASX_BLOCK_OFF_DOPPLERHZ);
    DEBUGOUT("%2d: index %2d %s:%03d %6d\n", num, index, GNSS_STR[gnssID], satID, dopplerHz);
}


uint16_t ubx_checksum(uint8_t *buffer, uint16_t len) {
    uint8_t chk_a = 0;
    uint8_t chk_b = 0;
    for (int i = 0; i < len; i++) {
        chk_a += buffer[i];
        chk_b += chk_a;
    }
    return ((uint16_t)chk_a << 8) | chk_b;
}

static bool measx_process(uint8_t* payload, uint16_t len)
{
    struct {
        uint8_t numSV;
        uint8_t numGood;
        int8_t startOffset;
    } gnssInfo[MEAS50_NUM_GNSS_IDS+1];
    for (int i = 0; i < MEAS50_NUM_GNSS_IDS+1; i++) {
        gnssInfo[i].numSV = 0;
        gnssInfo[i].numGood = 0;
        gnssInfo[i].startOffset = -1;
    }
    //uint8_t gnssTypeCount[MEAS50_NUM_GNSS_IDS+1] = { 0 };
    //uint8_t gnssTypeOffset[MEAS50_NUM_GNSS_IDS+1] = { 0 };
    /* TODO: static */
    int8_t measurement[MEAS50_MAX_MEASUREMENTS] = { 0 };
    for (int i = 0; i < MEAS50_MAX_MEASUREMENTS; i++) {
        measurement[i] = -1;
    }

    assert(len > UBX_HEADER_LEN + UBX_CHECKSUM_LEN);
    payload += UBX_HEADER_LEN;
    len -= UBX_HEADER_LEN + UBX_CHECKSUM_LEN;
    //assert(len > MEASX_HEADER_LEN);
    if (len <= MEASX_HEADER_LEN) {
        return false;
    }

    /* Iterate through measurements and count number of (encodable)
     * measurements by constellation. Also count measurements that meet the
     * quality criteria. */
    uint8_t numSV = payload[MEASX_OFF_NUMSV];
    assert(len >= MEASX_HEADER_LEN + numSV * MEASX_BLOCK_LEN);
    uint8_t invalid = 0;
    for (int i = 0; i < numSV; i++) {
        uint8_t svID = payload[MEASX_BLOCK_START(i) + MEASX_BLOCK_OFF_SVID];
        uint8_t gnssID = mapGnssID(payload[MEASX_BLOCK_START(i) + MEASX_BLOCK_OFF_GNSSID]);
        // TODO: only if targeting MEAS50
        if ((svID - 1) >= (1 << MEAS50_SVID_BITS)) {
            DEBUGOUT("svID out of encodable range: GNSS:%s ID:%d\n", GNSS_STR[gnssID], svID);
            invalid += 1;
            continue;
        }
        uint8_t cNO = payload[MEASX_BLOCK_START(i) + MEASX_BLOCK_OFF_CNO];
        uint8_t multiPath = payload[MEASX_BLOCK_START(i) + MEASX_BLOCK_OFF_MPI];
        uint8_t prRMS = payload[MEASX_BLOCK_START(i) + MEASX_BLOCK_OFF_PRRMS];
        if ((cNO >= CONF_MIN_CNO) && (multiPath <= CONF_MAX_MULTIPATH) && (prRMS <= CONF_MAX_PRRMS)) {
            gnssInfo[gnssID].numGood += 1;
        }
        DEBUGOUT("Found measurement: GNSS:%s cNO:%c MP:%c PR:%c\n",
            GNSS_STR[gnssID],
            (cNO >= CONF_MIN_CNO) ? 'y' : 'n',
            (multiPath <= CONF_MAX_MULTIPATH) ? 'y' : 'n',
            (prRMS <= CONF_MAX_PRRMS) ? 'y' : 'n');
        // MEAS50 only: do not count SVs with IDs that can't be converted
        gnssInfo[gnssID].numSV += 1;
    }
    DEBUGOUT("numSV: %d\n", numSV);
    for (int i = 0; i < MEAS50_NUM_GNSS_IDS + 1; i++) {
        DEBUGOUT("%s: count: %d, good: %d\n", GNSS_STR[i], gnssInfo[i].numSV, gnssInfo[i].numGood);
    }
    DEBUGOUT("Invalid svIDs: %d\n", invalid);

    /* Find the maximum number of measurements within a constellation that
     * fulfill the quality criteria and calculate the total number of
     * measurements we can encode. */
    uint8_t goodSVs = 0;
    uint8_t totalSVs = 0;
    for (int i = 0; i < MEAS50_NUM_GNSS_IDS + 1; i++) {
        if (gnssInfo[i].numGood > goodSVs) {
            goodSVs = gnssInfo[i].numGood;
        }
        totalSVs += gnssInfo[i].numSV;
    }
    if (goodSVs < CONF_MINSV) {
        // TODO: fallback
        DEBUGOUT("Insufficient SVs meeting criteria: %d\n", goodSVs);
        return false;
    }
    /* Restrict total number of measurements to MEAS50 size */
    totalSVs = MIN(totalSVs, MEAS50_MAX_MEASUREMENTS);

    int offset = 0;
    /* Note that MEAS50_NUM_GNSS_IDS does not get sorted */
    for (int i = 0; i < MEAS50_NUM_GNSS_IDS; i++) {
        int max = 0;
        int idx = -1;
        // find the index of the GNSS with the most SVs
        for (int y = 0; y < MEAS50_NUM_GNSS_IDS; y++) {
            if ((gnssInfo[y].startOffset < 0) && (gnssInfo[y].numSV > max)) {
                max = gnssInfo[y].numSV;
                idx = y;
            }
        }
        if (idx < 0) {
            break;
        } else {
            // indices of the GNSS idx start at offset
            gnssInfo[idx].startOffset = offset;
            offset += gnssInfo[idx].numSV;
        }
    }
    /* OTHER GNSS IDs come last */
    if (gnssInfo[MEAS50_NUM_GNSS_IDS].numSV > 0) {
        gnssInfo[MEAS50_NUM_GNSS_IDS].startOffset = offset;
    }

    for (int i = 0; i <= MEAS50_NUM_GNSS_IDS; i++) {
        DEBUGOUT("%s: offset: %d\n", GNSS_STR[i], gnssInfo[i].startOffset);
    }

    // TODO: code below is wrong if encodableSVs != numSV

    /* generate a sorted array of measurement indices */
    /* Fill measurement[] with the indices of the measurements in the
     * right order. */
    for (int sv = 0, mapped = 0; sv < numSV; sv++) {
        uint8_t svID = payload[MEASX_BLOCK_START(sv) + MEASX_BLOCK_OFF_SVID];
        if ((svID - 1) < (1 << MEAS50_SVID_BITS)) {
            uint8_t gnssID = mapGnssID(payload[MEASX_BLOCK_START(sv) + MEASX_BLOCK_OFF_GNSSID]);
            DEBUGOUT("%d:%d:%d\n", sv, gnssID, gnssInfo[gnssID].startOffset);
            assert(gnssInfo[gnssID].startOffset >= 0);
            if (gnssInfo[gnssID].startOffset < MEAS50_MAX_MEASUREMENTS) {
                assert(measurement[gnssInfo[gnssID].startOffset] == -1);
                measurement[gnssInfo[gnssID].startOffset] = sv;
                gnssInfo[gnssID].startOffset += 1;
                /* if we have mapped as many measurements as possible, we can exit early */
                if (++mapped >= totalSVs) {
                    break;
                }
            }
        }
    }

    /* pick the minimum Doppler reading among the prime candidates */
    int32_t refDopplerHz = INT32_MAX;
    int refIdx = -1;
    for (int i = 0; i < totalSVs; i++) {
        assert(measurement[i] >= 0);
        uint8_t m = measurement[i];
        uint8_t svID = payload[MEASX_BLOCK_START(m) + MEASX_BLOCK_OFF_SVID];
        if ((svID - 1) < (1 << MEAS50_SVID_BITS)) {
            int32_t dopplerHz = readInt32(payload + MEASX_BLOCK_START(m) + MEASX_BLOCK_OFF_DOPPLERHZ);
            if (dopplerHz < refDopplerHz) {
                refDopplerHz = dopplerHz;
                refIdx = i;
            }
        }
    }
    assert(refIdx >= 0);
    /* move the ref measurement first */
    int tempIdx = measurement[0];
    measurement[0] = measurement[refIdx];
    measurement[refIdx] = tempIdx;

    DEBUGOUT("Reference DopplerHz: %d\n", refDopplerHz);
    for (int i = 0; i < totalSVs; i++) {
        uint8_t idx = measurement[i];
        printMeasurement(payload + MEASX_BLOCK_START(idx), i, idx);
    }

    bitarray_init(&meas50, meas50_bytes, MEAS50_SIZE_BYTES);

    uint8_t meas50Count = 0;
    for (int i = 0; i < totalSVs; i++) {
        bool needDoppler = ((meas50Count > 0) && (meas50Count < MEAS50_MAX_DOPPLER));
        uint8_t idx = measurement[i];
        uint8_t svID = payload[MEASX_BLOCK_START(idx) + MEASX_BLOCK_OFF_SVID] - 1;
        /* cannot encode IDs above 63 */
        if (svID >= (1 << MEAS50_SVID_BITS)) {
            DEBUGOUT("Discarding measurement due to svID\n");
            continue;
        }
        uint8_t gnssID = mapGnssID(payload[MEASX_BLOCK_START(idx) + MEASX_BLOCK_OFF_GNSSID]);
        if (gnssID >= (1 << MEAS50_GNSS_BITS)) {
            gnssID = 0; // incorrectly representing as GPS
        }
        uint32_t codePhase = (uint32_t)readInt32(payload + MEASX_BLOCK_START(idx) + MEASX_BLOCK_OFF_CPMS);
        codePhase >>= 4;
        if (codePhase >= (1 << MEAS50_CHIP_BITS)) {
            DEBUGOUT("Ignoring codephase overrun!\n");
        }
        int32_t dopplerHz = 0;
        if (needDoppler) {
            dopplerHz = readInt32(payload + MEASX_BLOCK_START(idx) + MEASX_BLOCK_OFF_DOPPLERHZ);
            dopplerHz = (dopplerHz - refDopplerHz) / 10;
            if (dopplerHz >= (1 << MEAS50_DOPPLER_BITS)) {
                DEBUGOUT("Discarding large doppler offset\n");
                continue;
            }
        }
        DEBUGOUT("GNSS: %d, svID: %d, cp: %d ", gnssID, svID, codePhase);
        bitarray_appendValue(&meas50, gnssID, MEAS50_GNSS_BITS);
        bitarray_appendValue(&meas50, svID, MEAS50_SVID_BITS);
        bitarray_appendValue(&meas50, codePhase, MEAS50_CHIP_BITS);
        if (needDoppler) {
            DEBUGOUT("doppler: %d\n", dopplerHz);
            bitarray_appendValue(&meas50, dopplerHz, MEAS50_DOPPLER_BITS);
        } else {
            DEBUGOUT("\n");
        }
        meas50Count += 1;
        if (meas50Count >= MEAS50_MAX_MEASUREMENTS) {
            // no more space
            break;
        }
    }
    DEBUGOUT("Encoded %d bits from %d measurements\n", meas50.size, meas50Count);
    int payloadSize = MEAS50_SIZE_BYTES;
    ubx_rxm_meas50_bytes[0] = 0xB5;
    ubx_rxm_meas50_bytes[1] = 0x62;
    ubx_rxm_meas50_bytes[2] = 0x02;
    ubx_rxm_meas50_bytes[3] = 0x86;
    ubx_rxm_meas50_bytes[4] = (uint8_t)payloadSize;
    ubx_rxm_meas50_bytes[5] = (uint8_t)(payloadSize >> 8);
    int packetLength = 6 + payloadSize;
    uint16_t checkSum = ubx_checksum(ubx_rxm_meas50_bytes + 2, packetLength - 2);
    ubx_rxm_meas50_bytes[packetLength++] = (uint8_t)(checkSum >> 8);
    ubx_rxm_meas50_bytes[packetLength++] = (uint8_t)checkSum;
    for (int idx = 0; idx < packetLength; idx++) {
        DEBUGOUT("%02x ", ubx_rxm_meas50_bytes[idx]);
    }
    DEBUGOUT("\n");
    base64encode(ubx_rxm_meas50_bytes, packetLength, ubx_rxm_meas50_base64);
    DEBUGOUT("base64: %s\n", ubx_rxm_meas50_base64);
    return true;
}

void *GnssNmeaMeasx_init(bool enable, uint8_t* measxBuf, uint16_t measxSize)
{
    ubx_rxm_meas50_bytes[0] = 0;
    return GnssParser_init(enable, measxBuf, measxSize, measx_process);
}

bool GnssMeasx_valid(char **measxData, uint16_t *measxLen)
{
    if (ubx_rxm_meas50_bytes[0] != 0)
    {
        *measxData = ubx_rxm_meas50_base64;
        *measxLen = strlen(ubx_rxm_meas50_base64);
        return true;
    }
    return false;
}
