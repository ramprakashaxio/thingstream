/*
 * Copyright 2018-2021 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file
 * @brief An interface for flashing patterns on LED.
 */
#ifndef INC_LEDS_H_
#define INC_LEDS_H_

#include <stdint.h>
#include <stdbool.h>

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

/**
 * No longer used in this interface, but some old implementations
 * still reference it.
 * @private
 */
typedef enum
{
    Led_idle,
    Led_background,
    Led_foreground
} led_status_t;


/**
 * Initialise the LED system.
 */
extern void Led_Init(void);

/** Simple flash
 * A convenience function to display a simple flash pattern as foreground activity
 * (ie it takes precedence over a background pattern).
 * @param red, green, blue - intensity of each colour, 0-100
 * @param on, off - number of milliseconds the led is on / off
 * @param count number of times to repeat the flash
 */
extern void Led_Flash(uint8_t red, uint8_t green, uint8_t blue, uint32_t on, uint32_t off, uint32_t count);

/** Establish a background indication
 * The actual manifestation of this indication is target-dependent. It is assumed
 * to be ongoing until replaced by a subsequent call.
 * Setting red, green and blue to zero will turn off background indication.
 * @param red red intensity (0-100)
 * @param green green intensity (0-100)
 * @param blue blue intensity (0-100)
 */
extern void Led_Background(uint8_t red, uint8_t green, uint8_t blue);

/** Disable all timer-based activity and set leds explicitly
 * @param red red intensity (0-100)
 * @param green green intensity (0-100)
 * @param blue blue intensity (0-100)
 */
void Led_setRGB(uint8_t red, uint8_t green, uint8_t blue);

/** Wait for current program to complete.
 * Not yet in all implementations, and only needed in non-blocking
 * implementations.
 *
 * @param full   true to wait for the full program, or false to wait
 *    for the minimum required period.
 */
extern void Led_Wait(bool full);


#if defined(__cplusplus)
}
#endif

#endif /* INC_LEDS_H_ */
