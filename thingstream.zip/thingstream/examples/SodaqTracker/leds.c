/*
 * Copyright 2021 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#include <Arduino.h>
#include "leds.h"
#include "led_fader.h"
#include "timer.h"

/* All the work is done by led_fader.c + led_fader_config.h
 *
 * Change the resolution to be 16 bits, to match the hardware.
 * The default of 8 bits is just for compatability.
 */

void Led_Init(void)
{
    /* By default, writeAnalog takes an 8-bit value, but internally the
     * hardware uses 16 bits, so the value is shifted left. But that means
     * that we cannot write 0xffff, only 0xff00 - we cannot set the LED
     * fully off.
     *
     * Change the resolution to be 16 bits to match the hardware.
     */
    analogWriteResolution(16);

    LedFader_Init(1);
}


// override the weak handler in timer.c

void Timer_triggered(void)
{
    LedFader_Tick();
}
