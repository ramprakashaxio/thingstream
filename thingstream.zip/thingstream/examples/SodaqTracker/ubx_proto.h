/*
 * Copyright 2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_UBX_PROTO_H_
#define INC_UBX_PROTO_H_

#include <stdint.h>

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

#define UBX_HEADER_LEN 6
#define UBX_CHECKSUM_LEN 2

#define UBX_MAX_GNSS_ID 7

extern const uint8_t ubx_preamble[2];
extern const uint8_t ubx_cid_valset[2];
extern const uint8_t ubx_cfg_msgout_ubx_rxm_measx_uart1[4];

uint16_t ubx_checksum(uint8_t *buffer, uint16_t len);

#if defined(__cplusplus)
}
#endif

#endif /* INC_UBX_PROTO_H_ */
