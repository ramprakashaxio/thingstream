/*
 * Copyright 2017-2023 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdlib.h>
#include "modem_multiplexor.h"
#include "thingstream.h"

/**
 * If the application updates this variable then that routine routine will be
 * called when the modem transport receives an unexpected response.
 *
 * @param response the unrecognized modem response
 * @param len the length of the response
 */
void (*Application_activeModemCallback)(const char* data, uint16_t len);

/**
 * This routine will be called when the modem transport receives an unexpected
 * response.
 * E.g. the response from a call to Thingstream_Modem_sendLine()
 *
 * @param response the modem response
 * @param len the length of the response
 */
void Thingstream_Application_modemCallback(const char* response, uint16_t len)
{
    /* Pass the response to the correct callback handler */
    if (Application_activeModemCallback != NULL)
    {
        Application_activeModemCallback(response, len);
    }
}
