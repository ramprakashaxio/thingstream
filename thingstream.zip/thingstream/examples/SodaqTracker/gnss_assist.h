/*
 * Copyright 2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_GNSS_ASSIST_H_
#define INC_GNSS_ASSIST_H_

#include <stdint.h>

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

#if defined(GNSS_ENABLED) && defined(UBLOX_ASSIST_NOW)
/**
 * Ask for AssistNow data from the Thingstream server
 *
 * @param client the ThingstreamClient to use to request the data.
 * @param pEpoch pointer to current unix epoch time
 */
extern void Gnss_request_assistNow(ThingstreamClient * client, uint32_t *pEpoch);


/**
 * Receive the AssistNow data received from the server.
 *
 * If the GNSS device is not a u-blox modem then this api can be ignored
 *
 * @param message the UBX-XXX message to save (will be sent to the u-blox
 *        GNSS device in the future)
 * @param len the length of the message
 */
extern void Gnss_receive_assistNow(const uint8_t *message, uint16_t len);

/**
 * Store the AssistNow data received from the server.
 * The saved area should be implemented in memory with battery back-up
 *
 * If the GNSS device is not a u-blox modem then this api can be ignored
 *
 * @param message the UBX-XXX message to save (will be sent to the u-blox
 *        GNSS device in the future)
 * @param len the length of the message
 */
extern void Gnss_store_assistNow(const uint8_t *message, uint16_t len);

/**
 * Load the AssistNow data saved by #Gnss_store_assistNow()
 *
 * If the GNSS device is not a u-blox modem then this api can return 0
 *
 * @param pBuffer a pointer to a variable to receive the address of the data
 * @return the length of the saved data
 */
extern uint16_t Gnss_load_assistNow(uint8_t **pBuffer);

/**
 * Send the AssistNow data (previously received from the server) to the GNSS
 * device.
 *
 * If the GNSS device is not a u-blox modem then this api can
 * just ignore the message.
 *
 * @param device the #ThingstreamTransport connected to the GNSS device,
 *        or NULL if the GNSS is integrated into the modem.
 * @param message the UBX-XXX message to send to the u-blox GNSS device
 * @param len the length of the message
 */
extern void Gnss_install_assistNow(ThingstreamTransport* device, const uint8_t *message, uint16_t len);

/**
 * The maximum size of the AssistNow data.
 */
#define UBLOX_ASSIST_NOW_SIZE (1024)

#endif /* GNSS_ENABLED && UBLOX_ASSIST_NOW */


#if defined(__cplusplus)
}
#endif

#endif /* INC_GNSS_ASSIST_H_ */
