/*
 * Copyright 2021 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_LED_FADER_CONFIG_H_
#define INC_LED_FADER_CONFIG_H_

#include <Arduino.h>
#include "timer.h"

/* Platform-specific configuration for the led_fader library.
 *
 * This operates in an up-counter mode
 */


/* The public interface uses 0-100 for brightness.
 * Background uses only half that range, so can be a bit "steppy" at low
 * levels. Scale up by a factor of 5 to increase the resolution - this
 * makes the transition bounce around black slightly smoother.
 */
#define LED_SCALE_FACTOR 5

/* analogWrite() writes a 16-bit PWM value, so need to scale up
 * further when writing. But because red and green are brighter
 * than blue, scale red and green by less.
 */
#define SCALE_RED   110   /* 0-500 => 0-55000 */
#define SCALE_GREEN 110   /* 0-500 => 0-55000 */
#define SCALE_BLUE  131   /* 0-500 => 0-65500 */

/* The LEDs are common-anode, so we need to invert the
 * value : 0 for fully on, 0xffff for fully off.
 */
#define LED_SET_RGB(r,g,b) do {       \
     analogWrite(LED_RED,   ~((r) * SCALE_RED));   \
     analogWrite(LED_GREEN, ~((g) * SCALE_GREEN)); \
     analogWrite(LED_BLUE,  ~((b) * SCALE_BLUE));  \
  } while(0)


/* Start the timer so that it will interrupt after the given time.
 * Timer must be stopped to use this.
 */
#define LED_TIMER_START(ticks) Timer_start(ticks)

/* Load a new interval into the timer so that it will load the new
 * value after the current time expires. Unused since this is
 * an up-counter
 */
#define LED_TIMER_SET_NEXT_INTERVAL(ticks)  do {} while(0)

/* Set the compare value which triggers the interrupt */
#define LED_TIMER_SET_COMPARE(ticks)  Timer_set_compare(ticks)


/* Stop the timer so that there are no further interrupts. The
 * current countdown value does not need to be preserved.
 */
#define LED_TIMER_STOP()  Timer_stop()

#endif /* INC_LED_FADER_CONFIG_H_ */
