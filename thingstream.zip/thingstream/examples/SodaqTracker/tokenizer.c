/*
 * Copyright 2021-2022 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stddef.h>

#include "tokenizer.h"

/**
 * This tokenizer is designed to accept a subset of well-formed JSON.
 * Specifically, JSON values may be strings, integers or objects. Arrays are
 * not fully supported.
 *
 * Badly formed JSON input is also supported. Specifically:
 *    * the root object does not need to be enclosed in curly braces
 *    * keys and values do not have to be quoted (see below)
 *    * quote characters can be <"> or <'>
 *    * assignment character can be <:> or <=>
 *    * tuple separator can be <,> or <;>
 *
 * Scalar values (string, number, true, false, null) are all processed the
 * same, so that the handler can decide whether to allow e.g. 0x10 as a number,
 * even though JSON does not. However, the processToken() method is told whether
 * values were quoted, so that it can apply different rules,
 * i.e. treat "9" and 9 differently, if that's desired.
 *
 * Keys and string values may be quoted, in which case they end strictly at the
 * following quote. Escaped quotes in strings are not supported. Single or
 * double quotes are allowed.
 *
 * Keys and string values that are not quoted end at the next whitespace or the
 * expected following special character. That is an assignment character (':'
 * or '=') for keys and a separator (',' or ';') for values. No escaping is
 * supported.
 */

enum CharClass_e
{
    UNKNOWN    = 0,
    ALPHABETIC = (1 << 0),
    NUMERIC    = (1 << 1),
    QUOTE      = (1 << 2),
    SPACE      = (1 << 3),
    ASSIGNMENT = (1 << 4),
    SEPARATOR  = (1 << 5),
    OPEN       = (1 << 6),
    CLOSE      = (1 << 7),
    END        = (1 << 8)
};

static enum CharClass_e classify(char ch)
{
    if (((ch >= 'a') && (ch <= 'z')) || ((ch >= 'A') && (ch <= 'Z')))
        return ALPHABETIC;
    if ((ch >= '0') && (ch <= '9'))
        return NUMERIC;
    if ((ch == '\'') || (ch == '"'))
        return QUOTE;
    if ((ch == ':') || (ch == '='))
        return ASSIGNMENT;
    if ((ch == ',') || (ch == ';'))
        return SEPARATOR;
    if ((ch == ' ') || (ch == '\t') || (ch == '\r') || (ch == '\n'))
        return SPACE;
    if ((ch == '{') || (ch == '['))
        return OPEN;
    if ((ch == '}') || (ch == ']'))
        return CLOSE;
    return UNKNOWN;
}

void tokenizeString(uint8_t *str, uint16_t len, TokenHandler_t handler, void *cookie)
{
    // the state indicates what kind of input the parser is looking for
    enum
    {
        S_KEY_START, S_QUOTED_KEY_END, S_KEY_END, S_ASSIGN, S_VALUE_START, S_STRINGVALUE_END,
        S_CHARSVALUE_END, S_OBJVALUE_END, S_ARRVALUE_END
    } state = S_KEY_START;
    // key points to the start of the key string
    uint8_t *key = NULL;
    // the length of the key
    uint16_t klen = 0;
    // value points to the start of the value string
    uint8_t *value = NULL;
    // counter for keeping track of nested arrays or objects
    uint16_t nesting = 0;

    for (int i = 0; i <= len; i++, str++)
    {
        char ch;
        enum CharClass_e class;

        if (i == len)
        {
            ch = '\0';
            class = END;
        }
        else
        {
            ch = (char) *str;
            class = classify(ch);
        }

        switch (state)
        {
        case S_KEY_START:
            if (class & (ALPHABETIC))
            {
                key = str;
                state = S_KEY_END;
            }
            else if (class == QUOTE)
            {
                key = str + 1;
                state = S_QUOTED_KEY_END;
            }
            break;

        case S_KEY_END:
            if (class & (QUOTE | SPACE)) // TODO: QUOTE seems wrong
            {
                klen = str - key;
                state = S_ASSIGN;
            }
            else if (class == ASSIGNMENT)
            {
                klen = str - key;
                state = S_VALUE_START;
            }
            else if (!(class & (ALPHABETIC | NUMERIC)))
            {
                // give up and wait for next key
                key = NULL;
                state = S_KEY_START;
            }
            break;

        case S_QUOTED_KEY_END:
            if (class == QUOTE)
            { // escaped quotes not supported
                klen = str - key;
                state = S_ASSIGN;
            }
            break;

        case S_ASSIGN:
            if (class == ASSIGNMENT)
            {
                state = S_VALUE_START;
            }
            else if (class == ALPHABETIC)
            {
                // looks like another key start
                key = str;
                state = S_KEY_END;
            }
            else if (class == QUOTE)
            {
                // looks like another quoted key start
                key = str + 1;
                state = S_QUOTED_KEY_END;
            }
            else if (class == SEPARATOR)
            {
                // look for another key after the separator
                key = NULL;
                state = S_KEY_START;
            }
            break;

        case S_VALUE_START:
            if (class == SPACE)
            {
                // ignore
            }
            else if (class & (SEPARATOR | CLOSE))
            {
                state = S_KEY_START; // give up
            }
            else
            {
                if (class == QUOTE)
                {
                    state = S_STRINGVALUE_END;
                    value = str + 1;
                }
                else if (class == OPEN)
                {
                    state = (ch == '{') ? S_OBJVALUE_END : S_ARRVALUE_END;
                    nesting = 1;
                    value = str;
                }
                else
                {
                    state = S_CHARSVALUE_END;
                    value = str;
                }
            }
            break;

        case S_STRINGVALUE_END:
            if (class == QUOTE)
            {
                (*handler)(TOKENIZER_STRING, key, klen, value, str - value, cookie);
                state = S_KEY_START;
            }
            break;

        case S_CHARSVALUE_END:
            if (class & (SEPARATOR | SPACE | CLOSE | END))
            {
                (*handler)(TOKENIZER_CHARS, key, klen, value, str - value, cookie);
                state = S_KEY_START;
            }
            break;

        case S_OBJVALUE_END:
            // TODO: add a skip function that fast forwards to the matching brace
            // and disregard braces inside quoted strings
            if ((ch == '}') && (--nesting == 0))
            {
                (*handler)(TOKENIZER_OBJECT, key, klen, value, str - value + 1, cookie);
                state = S_KEY_START;
            }
            else if (ch == '{')
            {
                nesting += 1;
            }
            break;

        case S_ARRVALUE_END:
            if ((ch == ']') && (--nesting == 0))
            {
                (*handler)(TOKENIZER_ARRAY, key, klen, value, str - value + 1, cookie);
                state = S_KEY_START;
            }
            else if (ch == '[')
            {
                nesting += 1;
            }
            break;

        default:
            break;
        }
    }
}
