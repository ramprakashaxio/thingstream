/*
 * Copyright 2017-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <stdlib.h>

#include "flags.h"  /* configuration */

/* SDK headers */
#include <thingstream.h>

/* application headers */
#include "tracker2.h"
#include "modem_uart_transport.h"
#include "nvmem.h"
#include "config.h"
#include "visual.h"
#include "gnss.h"
#include "gnss_assist.h"
#include "cell_info.h"
#include "platform_wifi.h"
#include "json.h"
#include "platform.h"

#define TRACKER_UNUSED(symbol)  ((void)symbol)

#define ASSERT(truth)                                          \
    do                                                         \
    {                                                          \
        if (!(truth))                                          \
        {                                                      \
            DEBUGOUT("Tracker AssertFail: %d\n", __LINE__);            \
            goto exit;                                         \
        }                                                      \
    } while (0)

#define ASSERT_CLIENT_SUCCESS(cr, label)                       \
    do                                                         \
    {                                                          \
        if (cr != CLIENT_SUCCESS)                              \
        {                                                      \
            DEBUGOUT("Tracker AssertClientFail@%d: %d\n", __LINE__, cr);  \
            goto label;                                        \
        }                                                      \
    } while (0)

#define MAX_SECONDS_GNSS_LOCK_WAIT   15
#define LONG_PRESS_MAX_SECONDS_GNSS_LOCK_WAIT    120

/* The published message is generated into this buffer */
#define JSON_BUFFER_LENGTH 1501
static char json_chars[JSON_BUFFER_LENGTH];


/* Configuration for the thingstream stack */

static ThingstreamTransport *modem;
static ThingstreamTransport *modem_inner;


#define THINGSTREAM_BUFFER_LENGTH 1500
static uint8_t thingstream_buffer[THINGSTREAM_BUFFER_LENGTH];

#ifndef RING_BUFFER_LENGTH
#define RING_BUFFER_LENGTH 2000
#endif

#ifdef UDP_MODEM_INIT
#define MODEM_BUFFER_LENGTH MODEM_UDP_BUFFER_LEN
#else
/* If no hardware specific modem initialisation was specified then use the
 * USSD transport.
 */
#define MODEM_BUFFER_LENGTH MODEM_USSD_BUFFER_LEN
#define UDP_MODEM_INIT     Thingstream_UssdInit
#endif /* !UDP_MODEM_INIT */

static uint8_t modemBuf[MODEM_BUFFER_LENGTH];

/* Set by Thingstream_Application_subscribeCallback() to indicate
 * that a config message from the server was received and a reply
 * needs to be sent from outside the callback. */
static bool needConfigResponse;

/**
 * Send the line to the modem and wait for an OK response.
 *
 * @param line a null-terminated line to send to the modem ("\r\n" will be added)
 * @param millis the maximum number of milliseconds to run
 * @return an integer status code (success / fail)
 */
ThingstreamTransportResult Tracker_modem_send_line(const char* line, uint32_t millis)
{
    if (modem != NULL)
    {
        return Thingstream_Modem_sendLine(modem, line, millis);
    }
    else
    {
        return TRANSPORT_ILLEGAL_ARGUMENT;
    }
}

/**
 * Get the modem ThingstreamTransport used by the Tracker.
 *
 * @return the modem transport
 */
ThingstreamTransport* Tracker_get_modem(void)
{
    return modem;
}

/**
 * Get the modem inner ThingstreamTransport used by the Tracker.
 *
 * @return the modem inner transport
 */
ThingstreamTransport* Tracker_get_modem_inner(void)
{
    return modem_inner;
}

/* This api is called by the SDK when the server sends the Client a message.
 * This is the mechanism by which the behaviour can be configured
 */
void Thingstream_Application_subscribeCallback(ThingstreamTopic topic, ThingstreamQualityOfService_t qos, uint8_t* payload, uint16_t payloadlen)
{
    TRACKER_UNUSED(qos);
    int idx;
    DEBUGOUT("subscribeCallback: %04x:%04x\n", topic.topicType, topic.topicId);
    DEBUGOUT("   payload: ");
    for (idx = 0; idx < payloadlen; idx++)
    {
        uint8_t byte = payload[idx];
        if ((byte == '[') || (byte == ']') || (byte == '\\'))
            DEBUGOUT("\\%c", byte);
        else if ((' ' <= byte) && (byte <= '~'))
            DEBUGOUT("%c", byte);
        else if (byte == '\n')
            DEBUGOUT("\\n");
        else if (byte == '\r')
            DEBUGOUT("\\r");
        else
            DEBUGOUT("[%02x]", byte);
    }
    DEBUGOUT("\n");
    if ((topic.topicId == Thingstream_PredefinedSelfTopic.topicId) &&
        (topic.topicType == Thingstream_PredefinedSelfTopic.topicType))
    {
#if defined(GNSS_ENABLED) && defined(UBLOX_ASSIST_NOW)
        static const uint8_t UBX_MESSAGE_HDR[] = { 0xB5, 0x62 };
        uint16_t ubx_len = sizeof(UBX_MESSAGE_HDR);
        if ((payloadlen > ubx_len)
         && (memcmp(payload, UBX_MESSAGE_HDR, ubx_len) == 0))
        {
            // This is an AssistNow UBX message to be sent to the GNSS chip
            Gnss_receive_assistNow(payload, payloadlen);
        }
        else
#endif /* GNSS_ENABLED && UBLOX_ASSIST_NOW */
        {
            // TODO: just refer to the global instance directly
            NVMem* nvmem = NVMem_init();
            parseConfigString(payload, payloadlen, nvmem);
            NVMem_commit();
            needConfigResponse = true;
        }
    }
}


/**
 * This is called by the SDK when the server sends the Client a mapping
 * between the name of a topic and the topic ID.
 *
 * @param topicName the name of the topic
 * @param topic the #ThingstreamTopic that matches the topicName
 */
void Thingstream_Application_registerCallback(const char* topicName, ThingstreamTopic topic)
{
    TRACKER_UNUSED(topicName);
    TRACKER_UNUSED(topic);
    /*
     * We do not use this information in the tracker application but we provide
     * an empty stub to reduce size. The default code provided by the SDK is
     * larger because it provides backwards compatibility with previous SDK
     * versions.
     */
}



/**
 * Build the Thingstream transport stack
 * @param modemCreateFlags the flags to pass to the modem instance
 * @return client instance, or NULL on error
 */
static ThingstreamClient* get_client(uint16_t modemCreateFlags)
{
    ThingstreamTransport *transport = modem_uart_transport_create();
    ASSERT(transport != NULL);

#if RING_BUFFER_LENGTH > 0
    static uint8_t ringBuffer[RING_BUFFER_LENGTH];
    transport = Thingstream_createRingBufferTransport(transport,
                                                      ringBuffer, RING_BUFFER_LENGTH);
    ASSERT(transport != NULL);
#endif /* RING_BUFFER_LENGTH */

#if defined(DEBUG_LOG_MODEM) && (DEBUG_LOG_MODEM > 0)
    transport = Thingstream_createModemLogger(transport,
                                              Thingstream_Util_printf,
                                              TLOG_TRACE | TLOG_TIME);
    ASSERT(transport != NULL);
#endif /* DEBUG_LOG_MODEM */

    /* preserve the transport since it will be needed for combo gnss */
    modem_inner = transport;

    transport = Thingstream_createModemTransport(transport, modemCreateFlags,
                                                 modemBuf, sizeof(modemBuf),
                                                 UDP_MODEM_INIT);
    ASSERT(transport != NULL);

    /* preserve this since it will be needed for direct communication */
    modem = transport;

    transport = Thingstream_createBase64CodecTransport(transport);
    ASSERT(transport != NULL);

    transport = Thingstream_createProtocolTransport(transport,
                                                    thingstream_buffer,
                                                    THINGSTREAM_BUFFER_LENGTH);
    ASSERT(transport != NULL);

    DEBUGOUT("initializing @ %d\n", __LINE__);
#if defined(DEBUG_LOG_CLIENT) && (DEBUG_LOG_CLIENT > 0)
    transport = Thingstream_createClientLogger(transport,
                                               Thingstream_Util_printf,
                                               TLOG_TRACE | TLOG_TIME);
    ASSERT(transport != NULL);
#endif /* DEBUG_LOG_CLIENT */
    ThingstreamClient * client = Thingstream_createClient(transport);
    ASSERT(client != NULL);

    return client;

 exit:
    return NULL;
}



#ifdef USE_WIFI

struct wifi_s
{
    JsonBuffer *json;
    int count;
} wifi_state;

static wifi_callback_t wifi_callback;

/* Add one wifi access point to the json buffer */

static void wifi_callback(void *cookie, const uint8_t *mac, int32_t strength)
{
    struct wifi_s *state = cookie;
    if (state->count++ == 0)
    {
        json_key_append(state->json, "wifi");
        json_start_array(state->json);
    }
    else
    {
        json_separator(state->json);  /* between entries */
    }

    json_start_object(state->json);
    json_key_append(state->json, "bssid");
    char before = '"';
    int idx;
    for (idx = 0; idx < 6; ++idx)
    {
        static const char hex[] = "0123456789ABCDEF";
        uint8_t fld = mac[idx];
        json_char_append(state->json, before);
        json_char_append(state->json, (hex[fld >> 4]));
        json_char_append(state->json, (hex[fld & 0xf]));
        before = ':';
    }
    json_char_append(state->json, '"');
    json_named_int32_append(state->json, "signalStrength", strength);
    json_end_object(state->json);
}


/* Try to obtain a location using wireless access points.
 * wifi_callback adds the data to the json packet.
 */

static bool get_wifi_location(JsonBuffer *jbuf)
{
    struct wifi_s wifi_state;
    wifi_state.json = jbuf;
    wifi_state.count = 0;
    VISUALISE(STARTING, WIFI);
    Platform_enumerate_wifi_ap(&wifi_state, wifi_callback);

    if (wifi_state.count > 0)
    {
        VISUALISE(SUCCESS, WIFI);
        json_end_array(jbuf);
        return true;
    }

    return false;
}

#endif /* USE_WIFI */

#ifdef GNSS_ENABLED

/* Try to obtain a location using gnss */

static bool get_gnss_location(JsonBuffer *jbuf)
{
    VISUALISE(STARTING, GNSS);

    uint8_t gnssFixQuality;
    int32_t lat, lon;

    gnssFixQuality = Gnss_get_location(LONG_PRESS_MAX_SECONDS_GNSS_LOCK_WAIT * 1000,
                                      &lat, &lon);

    if (gnssFixQuality)
    {
        VISUALISE(SUCCESS, GNSS);

        /* Add the data to the json message */

        json_key_append(jbuf, "gnss");
        json_start_object(jbuf);
        json_named_fixedpoint_append(jbuf, "lat", lat, 6);
        json_named_fixedpoint_append(jbuf, "lon", lon, 6);
        json_named_uint32_append(jbuf, "qty", gnssFixQuality);
        json_end_object(jbuf);
        return true;
    }

    return false;
}


#ifdef GNSS_MEASX
static bool get_measx_location(JsonBuffer *jbuf)
{
    VISUALISE(STARTING, MEASX);

    char *measxData;
    uint16_t measxLen;

    if (Gnss_get_measx(30000, &measxData, &measxLen))
    {
        DEBUGOUT("MEASX data obtained successfully\n");

        VISUALISE(SUCCESS, MEASX);

        /* Add the data to the json message */

        json_key_append(jbuf, "GNSSMeasurements");
        json_start_object(jbuf);
        json_named_string_append(jbuf, "Payload", measxData, measxLen);
        json_end_object(jbuf);
        return true;
    }

    return false;
}
#endif /* GNSS_MEASX */
#endif /* GNSS_ENABLED */


/* Try to obtain a location using cell-tower information */

static bool get_cell_location(JsonBuffer *jbuf)
{
    int cellInfoCount;
    VISUALISE(STARTING, CELL);
    CellInfo *cellInfoArray = get_cell_info(modem, Thingstream_Modem_sendLine, &cellInfoCount);
    if (cellInfoCount == 0)
        return false;

    VISUALISE(SUCCESS, CELL);

    /* And add it to the json message */

    int i;
    json_key_append(jbuf, "cell");
    json_start_array(jbuf);
    for (i = 0; i < cellInfoCount; i++)
    {
        CellInfo* info = &cellInfoArray[i];
        if (i > 0)
            json_separator(jbuf);
        json_start_object(jbuf);
        json_named_cstring_append(jbuf, "mcc", info->mcc);
        json_named_cstring_append(jbuf, "mnc", info->mnc);
        json_named_int32_append(jbuf, "rssid", info->rssi);
        json_named_cstring_append(jbuf, "cid", info->cellId);
        json_named_cstring_append(jbuf, "lac", info->lac);
        json_end_object(jbuf);
    }
    json_end_array(jbuf);

    return true;
}


/* Add the event info to the json buffer.
 * It is assumed that no more than one event will have
 * an associated parameter - the interpretation depends
 * on invocation
 */
static void add_json_event(JsonBuffer *jbuf,
                           InvocationType invocation,
                           int32_t param)
{
    json_key_append(jbuf, "event");
    json_start_object(jbuf);
    switch(invocation)
    {
        case eventTimer:
            json_named_int32_append(jbuf, "timer", param);
            break;
        case eventMotion:
            json_named_bool_append(jbuf, "motion", 1);
            break;
        case eventPower:
            json_named_bool_append(jbuf, "poweron", 1);
            break;
        case eventButton:
            json_named_cstring_append(jbuf, "button", param ? "long" : "short");
            break;

        case NUM_EVENTS:  /* to suppress a warning */
            break;
    }
    json_end_object(jbuf);
}


/* Add sensor info to the json buffer */

static void add_json_sensors(JsonBuffer *jbuf)
{
    /* only add the sensor object if we get any readings.
     * Which makes this slightly messy...
     * bit 0 is battery, bit 1 is temperature, etc.
     *
     * *FIXME* probably tidier to use a mark/rewind
     * mechanism : copy *jbuf, start the sensors
     * group unconditionally, then restore the backup
     * state if it turns out we didn't have any sensor
     * information.
     */
    uint32_t sensors = 0;

#ifdef PLATFORM_HAS_BATTERY
    uint16_t voltage;
    uint16_t charge;
    if (Platform_getBatteryState(&voltage, &charge) && (voltage | charge))
        sensors |= 1;
#endif

#ifdef PLATFORM_HAS_TEMPERATURE
    int16_t temperature;
    if (Platform_getTemperature(&temperature))
        sensors |= 2;
#endif

    if (sensors)
    {
        json_key_append(jbuf, "sensor");
        json_start_object(jbuf);

#ifdef PLATFORM_HAS_BATTERY
        if (sensors & 1)
        {
            json_key_append(jbuf, "bat");
            json_start_object(jbuf);
            if (voltage > 0)
            {
                json_named_uint32_append(jbuf, "mV", voltage);
            }
            if (charge > 0)
            {
                json_named_uint32_append(jbuf, "pct", charge);
            }
            json_end_object(jbuf);
        }
#endif /* PLATFORM_HAS_BATTERY */

#ifdef PLATFORM_HAS_TEMPERATURE
        if (sensors & 2)
        {
            json_named_fixedpoint_append(jbuf, "temp", temperature, 1);
        }
#endif /* PLATFORM_HAS_TEMPERATURE */

        json_end_object(jbuf);
    }
}


/* The various location source functions are stored in a
 * table so that we can iterate over the various source
 * identifiers. NULL means that location is not
 * supported.
 */

typedef bool location_function_t(JsonBuffer *jbuf);

static location_function_t * const location_functions[NUM_LOCATIONS] =
{
#ifdef GNSS_ENABLED
#ifdef GNSS_MEASX
   [locationMeasx] = get_measx_location,
#endif /* GNSS_MEASX */
   [locationGnss] = get_gnss_location,
#endif /* GNSS_ENABLED */
#ifdef USE_WIFI
   [locationWifi] = get_wifi_location,
#endif
   [locationCell] = get_cell_location
};


/**
 * The main entry point
 */
bool Tracker_run(InvocationType invocation,
                 NVMem *nvmem,
                 uint32_t *pEpochGuess,
                 uint16_t modemCreateFlags)
{
    bool dataSent = false;
    ThingstreamClientResult cr;
    JsonBuffer jbuf;

    VISUALISE(STARTING, TRACKER);

    /* Turn on modem hardware */
    bool enabled = Platform_modemEnable();
    ASSERT(enabled);

    /* Set up the thingstream stack now, since the modem may be needed for
     * cell-based location or for obtaining AssistNow data.
     * Full stack initialisation is deferred until we publish.
     */
    ThingstreamClient *client = get_client(modemCreateFlags);
    if (client == NULL)
    {
        VISUALISE(ERROR, TRACKER);
        goto exit;
    }

    VISUALISE(SUCCESS, TRACKER);

#if defined(GNSS_ENABLED) && defined(UBLOX_ASSIST_NOW)
    if (nvmem->assistNow.age != 0)
    {
        Gnss_request_assistNow(client, pEpochGuess);
    }
#else  /* GNSS_ENABLED && UBLOX_ASSIST_NOW */
    TRACKER_UNUSED(pEpochGuess);
#endif /* GNSS_ENABLED && UBLOX_ASSIST_NOW */

    /* Start building up the json message */
    json_init_buffer(&jbuf, json_chars, JSON_BUFFER_LENGTH);
    json_start_object(&jbuf);

    /* Add the fixed bits.
     * Could possible defer the sensors to the end, so
     * that if there's an overflow, it's the sensors rather
     * than the location that is sacrificed.
     */
    add_json_event(&jbuf, invocation, 0);
    add_json_sensors(&jbuf);

    json_key_append(&jbuf, "loc");
    json_start_object(&jbuf);

    /* Now iterate over the various location priority classes,
     * trying to get locations.
     */
    int prio;
    for (prio = 0; prio <= MAX_PRIORITY_CLASS; ++prio)
    {
        bool found = false;
        for (int idx = 0; idx < NUM_LOCATIONS; ++idx)
        {
            if (nvmem->priority[idx] == prio &&
                location_functions[idx] != NULL)
            {
                if (location_functions[idx](&jbuf))
                    found = true;
            }
        }

        /* special case for prio 0 : these are always run in addition
        * the other levels
        */
        if (found && prio != 0)
            break;
    }

    json_end_object(&jbuf);  /* "loc" */

    /* The json message is now complete */

    json_end_object(&jbuf);
    if (json_full(&jbuf))
    {
        json_reset(&jbuf, 0);
        json_start_object(&jbuf);
        json_named_bool_append(&jbuf, "overflowed", true);
        json_end_object(&jbuf);
    }
    uint16_t msgLength = json_terminate(&jbuf);
    DEBUGOUT("JSON(%d): %s\n", msgLength, json_chars);

    /* Publish the json message */
    VISUALISE(STARTING, PUBLISH);

    /* Initialise the client */
    cr = Thingstream_Client_init(client);
    ASSERT_CLIENT_SUCCESS(cr, exit);

    /* Publish the data using the connection-less QoS-1 */
    cr = Thingstream_Client_publish(client,
                                    Thingstream_PredefinedSelfTopic,
                                    ThingstreamQOSM1, false,
                                    (uint8_t *)json_chars, msgLength);
    if (cr != CLIENT_SUCCESS)
    {
        if ((int)cr == (int)TRANSPORT_ACK_TIMEOUT)
        {
            /* The expected ACK from the server was not received in time.
             * The publish may or may not have been received by the server.
             * The application could choose to retry the publish, but since we
             * wish to conserve battery power we choose to just wait for the
             * next publish.
             */
            ASSERT_CLIENT_SUCCESS(cr, shutdown);
        }
        else
        {
            /* Some other error returned by the publish */
            ASSERT_CLIENT_SUCCESS(cr, shutdown);
        }
    }
    VISUALISE(SUCCESS, PUBLISH);
    dataSent = true;
    needConfigResponse = false;

    /* Check for inbound messages.
     *
     * As part of the Thingstream_Client_publish() communications the client
     * usually receives the number of queued messages from the server.
     * Retrieve this information so we can avoid a ping.
     */
    cr = Thingstream_Client_messageWaiting(client);
    DEBUGOUT("MessageWaiting check returned %d\n", (int)cr);
    if (cr > 0)
    {
        /* Ask for messages (only works if connected or asleep) */
        DEBUGOUT("Ask for waiting messages...\n");
        cr = Thingstream_Client_ping(client);
        DEBUGOUT("ping returned %d\n", (int)cr);
    }
    else if (cr == CLIENT_INFORMATION_NOT_AVAILABLE)
    {
        /* The Thingstream_Client_messageWaiting() can return this when the
         * the device has never previously connected or pinged the server.
         * Do a connection below and in future the
         * Thingstream_Client_messageWaiting() will return valid information.
         */
    }

    if ((cr == CLIENT_NOT_CONNECTED)
     || (cr == CLIENT_INFORMATION_NOT_AVAILABLE))
    {
        /* The Thingstream_Client_ping() reported that we are not connected or
         * the Thingstream_Client_messageWaiting() failed to provide any
         * information. Both problems are resolved by establishing the "asleep"
         * MQTT-SN state with the server by disconnecting with a large timeout,
         * but to do that we must first connect.
         * Use a short keepAlive time so that if network errors prevent
         * the disconnect getting through, the server will disconnect
         * automatically.
         */
        DEBUGOUT("Connecting...\n");
        VISUALISE(PROGRESS, TRACKER);
        cr = Thingstream_Client_connect(client, false, 3, DOMAIN_KEY);
        ASSERT_CLIENT_SUCCESS(cr, shutdown);

        /* Restore the sleeping state (use a sleep time of 25 hours) */
        DEBUGOUT("Disconnecting to set sleep state...\n");
        cr = Thingstream_Client_disconnect(client, 25 * 60);
        ASSERT_CLIENT_SUCCESS(cr, shutdown);

        /* Repeat the check to see if there are waiting inbound messages.
         * The Thingstream_Client_connect() above will have informed of waiting
         * messages.
         */
        cr = Thingstream_Client_messageWaiting(client);
        DEBUGOUT("MessageWaiting check says = %d\n", cr);
        if (cr > 0)
        {
            DEBUGOUT("Ask for waiting messages...\n");
            cr = Thingstream_Client_ping(client);
            DEBUGOUT("ping returned %d\n", (int)cr);
            /* Note that there may be more message waiting on the server, but
             * we don't bother (in this tracker application which only rarely
             * has inbound messages) calling Thingstream_Client_messageWaiting()
             * again. We wait for the next time we publish.
             */
        }
    }

    if (needConfigResponse)
    {
        /* The server has sent a configuration message; send the current
         * configuration back as confirmation. */
        json_reset(&jbuf, 0);
        json_start_object(&jbuf);
        json_key_append(&jbuf, "event");
        json_start_object(&jbuf);
        json_named_bool_append(&jbuf, "config", true);
        json_end_object(&jbuf); /* event */
        writeConfigString(&jbuf, nvmem);
        json_end_object(&jbuf);
        uint16_t msgLength = json_terminate(&jbuf);
        DEBUGOUT("JSON(%d): %s\n", msgLength, json_chars);
        /* Publish the data using the connection-less QoS-1 */
        cr = Thingstream_Client_publish(client,
                                        Thingstream_PredefinedSelfTopic,
                                        ThingstreamQOSM1, false,
                                        (uint8_t *)json_chars, msgLength);
        ASSERT_CLIENT_SUCCESS(cr, shutdown);
    }

 shutdown:
    cr = Thingstream_Client_shutdown(client);
    ASSERT_CLIENT_SUCCESS(cr, destroy);

 destroy:
    cr = Thingstream_Client_destroy(client);
    ASSERT_CLIENT_SUCCESS(cr, exit);

 exit:
    VISUALISE_NONE();
    Platform_modemDisable();
    return dataSent;
}
