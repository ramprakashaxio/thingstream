/*
 * Copyright 2017-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_GNSS_NMEA_H_
#define INC_GNSS_NMEA_H_

#include <stdint.h>
#include <stdbool.h>

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

/**
 * Initialize the GNSS NMEA parsing module.
 * Also initialise pins associated with the GNSS.
 * This should be called at least once at application startup.
 * It can safely be called at any time to turn GNSS functionality on or off.
 * Explicitly disabling GNSS using this function will save power.
 *
 * @param enable true if GNSS should be enabled
 * @return the cookie to be passed to GnssNmea_callback
 */
extern void *GnssNmea_init(bool enable);

/**
 * Return the quality of the GNSS fix according to NMEA 0183. A value of 0
 * indicates that GNSS does not have a location fix yet.
 * @return the quality of the GNSS fix or 0 if there is no fix
 */
extern uint8_t GnssNmea_getQuality(void);

/**
 * Callback function that can be registered with a serial #ThingstreamTransport
 * instance in order to parse raw GNSS NMEA data sent by the transport.
 * Data can be sent in any granularity: bytes, lines or partial lines.
 *
 * @param cookie the value returned by GnssNmea_init
 * @param data a pointer to the data to process
 * @param len the length of the data
 */
extern void GnssNmea_callback(void* cookie, uint8_t* data, uint16_t len);

/**
 * Return the longitude of the last GNSS position.
 * Only valid when GnssNmea_getQuality() returns a non-zero value.
 * @return the longitude in micro-degrees.
 */
extern int32_t GnssNmea_getLongitude(void);

/**
 * Return the latitude of the last GNSS position.
 * Only valid when GnssNmea_getQuality() returns a non-zero value.
 * @return the latitude in micro-degrees.
 */
extern int32_t GnssNmea_getLatitude(void);

#ifdef MANUFACTURING_TEST_MODE
/**
 * For MANUFACTURING_TEST_MODE return the time field from the last GNSS $GGA
 * seen. A GNSS fix is not required.
 *
 * @return GNSS time as a number ((hh * 1000) + (mm * 100) + ss)
 */
extern uint32_t GnssNmea_time(void);
#endif /* MANUFACTURING_TEST_MODE */

/* GnssNmea_wfi() is a wrapper around Platform_wfi that also dumps
 * gnss log buffers, when enabled. Should be called while waiting
 * for gnss data to become available.
 */
#ifdef DEBUG_ENABLE
extern void GnssNmea_wfi(void);
#else
#include "platform.h"
#define GnssNmea_wfi() Platform_wfi()
#endif

typedef bool (measx_callback)(uint8_t* payload, uint16_t len);

extern void *GnssParser_init(bool enable, uint8_t* measxBuf, uint16_t measxSize, measx_callback measx_process);

#if defined(__cplusplus)
}
#endif

#endif /* INC_GNSS_NMEA_H_ */
