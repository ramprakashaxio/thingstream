/*
 * Copyright 2021 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* Configure the RTC as a timer, for use with led fader, and
 * to wake from sleep.
 *
 * This configures the RTC as a 32-bit counter, clocked from generator 2,
 * which the startup code says is configured to use OSCULP32K (the ultra
 * low power 32k oscillator).  (I did try setting up clock generator 4
 * myself, but that seemed to cause character drops from the modem.)
 */

#include <Arduino.h>
#include "timer.h"


// most peripherals require waiting for a busy bit to clear
// after each operation
// *FIXME* all examples do the sync after a write. I wonder if we
// can do it before instead : most calls will be to Timer_set_compare(),
// and they will only be every 30ms or so. There's no need to wait
// until the change has been completed before proceeding. We'd just
// need to check *before* each write instead.
// Though I think all that happens if we don't wait for synchronisation
// is a bus stall.

#define SYNC_GCLK()   do {} while (GCLK->STATUS.reg & GCLK_STATUS_SYNCBUSY)
#define SYNC_RTC0()   do {} while (RTC->MODE0.STATUS.bit.SYNCBUSY)

/* from startup.c */
#define GENERIC_CLOCK_GENERATOR_OSCULP32K (2u) /* Initialized at reset for WDT */

void Timer_init(void)
{
    // Attach the clock generator to the RTC clock, and enable it.

    GCLK->CLKCTRL.reg =
        GCLK_CLKCTRL_GEN(GENERIC_CLOCK_GENERATOR_OSCULP32K)  |
        GCLK_CLKCTRL_ID(GCLK_CLKCTRL_ID_RTC)                 |
        GCLK_CLKCTRL_CLKEN;
    SYNC_GCLK();


    // perform a software reset on the RTC, which zeros all registers
    // and disables it. It has to be disabled to allow mode changes.

    RTC->MODE0.CTRL.reg = RTC_MODE0_CTRL_SWRST;
    SYNC_RTC0();

    NVIC_EnableIRQ(RTC_IRQn);
    NVIC_SetPriority(RTC_IRQn, 0x03);
}

void Timer_start(uint32_t cmp)
{
    // The count should already be zero since we stop the
    // timer using a SWRST

    // set the compare register
    RTC->MODE0.COMP[0].reg = cmp;
    SYNC_RTC0();

    RTC->MODE0.CTRL.reg =
        RTC_MODE0_CTRL_MODE_COUNT32    |   // 32-bit up-counter
        RTC_MODE0_CTRL_PRESCALER_DIV32 |   // divide down to 1kHz
        RTC_MODE0_CTRL_MATCHCLR        |   // clear count on match
        RTC_MODE0_CTRL_ENABLE;             // enable
    SYNC_RTC0();

    RTC->MODE0.INTENSET.reg = RTC_MODE0_INTENSET_CMP0;  // enable interrupt
    SYNC_RTC0();
}

void Timer_set_compare(uint32_t cmp)
{
    RTC->MODE0.COMP[0].reg = cmp;
    SYNC_RTC0();
}

void Timer_stop(void)
{
    // stop using a software reset, which should also
    // clear the COUNT for next start.
    RTC->MODE0.CTRL.reg = RTC_MODE0_CTRL_SWRST;
    SYNC_RTC0();
}

volatile uint32_t Timer_triggerCount;

void RTC_Handler(void)
{
    RTC->MODE0.INTFLAG.reg = RTC_MODE0_INTFLAG_CMP0; // clear interrupt
    SYNC_RTC0();
    ++Timer_triggerCount;
    Timer_triggered();
}
