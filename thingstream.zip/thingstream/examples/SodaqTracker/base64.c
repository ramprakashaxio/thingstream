/*
 * Copyright 2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "base64.h"

static const char b64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

void base64encode(const uint8_t* in, uint16_t len, char* out)
{
    // consumes all input if length is divisible by 3
    while (len >= 3) {
        // 6 MSB from byte[0]
        *out++ = b64_chars[(in[0] >> 2) & 0x3F];
        // 2 LSB from byte[0] + 4 MSB from byte[1]
        *out++ = b64_chars[((in[0] & 0x3) << 4) | ((in[1] >> 4) & 0xF)];
        // 4 LSB from byte[1] + 2 MSB from byte[2]
        *out++ = b64_chars[((in[1] & 0xF) << 2) | ((in[2] >> 6) & 0x3)];
        // 6 LSB from byte[2]
        *out++ = b64_chars[in[2] & 0x3F];
        len -= 3;
        in += 3;
    }
    // handle remaining bytes (there are either 0, 1 or 2)
    if (len > 0) {
        // 6 MSB from byte[0]
        *out++ = b64_chars[(in[0] >> 2) & 0x3F];
        if (len == 1) {
            // 2 LSB from byte[0]
            *out++ = b64_chars[((in[0] & 0x3) << 4)];
            *out++ = '=';
        } else { // len must be 2
            // 2 LSB from byte[0] + 4 MSB from byte[1]
            *out++ = b64_chars[((in[0] & 0x3) << 4) | ((in[1] >> 4) & 0xF)];
            // 4 LSB from byte[1]
            *out++ = b64_chars[((in[1] & 0xF) << 2)];
        }
        *out++ = '=';
    }
    *out = 0;
}
