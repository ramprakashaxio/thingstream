/*
 * Copyright 2017-2021 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#include <thingstream.h>
#include "platform.h"

#include "leds.h"
#include "led_fader.h"
#include "led_fader_config.h"  // platform-specific implementation details


/* The public interface uses brightness 0-100
 * For fading, that can result in obvious steps, especially
 * at the lowest intensity. So an implementation can choose
 * to scale all numbers up by a factor of up to 600 or so
 * (so that it still fits in a uint16_t - could detect that and
 * use uin32_t, of course).
 * Must be a constant.
 */

#ifndef LED_SCALE_FACTOR
#define LED_SCALE_FACTOR 1
#endif

/* The type we use to store program entries */
#if LED_SCALE_FACTOR > 2
typedef uint16_t rgb_t;
#else
typedef uint8_t rgb_t;
#endif


/* When running the background breathing pattern, we use the
 * absolute value of a signed 8-bit counter (so that it counts
 * from 0 to 127, then 128 down to 1).
 * By incrementing twice every 32ms, the cycle runs in just
 * over 4 seconds, which feels about right.
 * led_fader_config can set these to other values if desired.
 */

#ifndef BREATH_TICK_MS
#define BREATH_TICK_MS         32
#endif

#ifndef BREATH_TICK_INCREMENT
#define BREATH_TICK_INCREMENT   2
#endif


/* Format of one entry in a programmed sequence.
 * A program is an array of instances of this.
 * This might become public later, but for now it's internal.
 * Note that duration needs to be in timer ticks, not ms.
 */
typedef struct led_program_s
{
    uint32_t duration;   /* of this row, in timer ticks  (ms * ticksPerMs) */
    rgb_t  rgb[3];       /* red, green and blue, 0-100. */
} led_program_t;


/* The configuration of the state engine
 * LedFader_tick() writes the leds in program[row], then
 * updates row for the next call.
 * For an up-counter, it sets the interval to be that of the
 * current row ; for a down-counter, it sets the next interval
 * to be that of the next row.
 */
static struct
{
    /* set during LedFader_init() to allow platform to configure
     * ticks per ms.
     */
    uint32_t ticksPerMs;

    /* Active pattern */

    const led_program_t *program;  /* current program sequence */
    uint32_t repeat;               /* overall repeat count */
    uint8_t length;                /* length of current program */
    uint8_t row;                   /* current row number */

    /* Foreground pattern - for use by Led_Flash() */
    led_program_t fg_prog[3];

    /* To avoid a foreground pattern being immediately replaced by
     * another, a minimum time is enforced (ms).
     */
    uint32_t soonest;

    /* Background state */

    rgb_t bg_rgb[3];        /* the configured values */
    int8_t fader;           /* increments each tick */

    /* On each call to LedFader_Tick(), the value of fader is
     * adjusted, and then new values for bg_prog.rgb[] are
     * calculated from bg_rgb[] and fader.
     * Note that bg_prog.duration == 0 is used as a flag to
     * indicate no background pattern.
     */
    led_program_t bg_prog;
} led_state;



void LedFader_Init(uint32_t ticksPerMs)
{
    led_state.ticksPerMs = ticksPerMs;
    led_state.soonest = Thingstream_Platform_getTimeMillis();
}



/* Called by the timer interrupt to advance the state engine
 * Also called at the start of a new program to set things
 * going.
 */

void LedFader_Tick(void)
{
    const led_program_t *program = led_state.program;
    int row = led_state.row;

    /* program should not be NULL on entry - when a foreground
     * pattern ends, it should set it to the background program,
     * or stop the timer if there is none. But better safe than
     * sorry - timer might be used for other things.
     */
    if (!program)
        return;

    const rgb_t *rgb = program[row].rgb;
    uint32_t tmp;

    LED_SET_RGB(rgb[0], rgb[1], rgb[2]);

    /* If this is an up-counter, we need to set the duration
     * of this row.
     */
    LED_TIMER_SET_COMPARE(program[row].duration);

    /* See what's happening next */

    if (++row < led_state.length ||
        ((row = 0), (--led_state.repeat > 0)))
    {
        /* There's another row to display, possibly repeating from row 0 */
        led_state.row = row;

        /* For a down-counter, need to set the next interval now */
        LED_TIMER_SET_NEXT_INTERVAL(program[row].duration);
    }
    else if ((tmp = led_state.bg_prog.duration) > 0)
    {
        /* Either activate or continue the background breathing pattern.
         * Calculate the next set of values to write to the LEDs.
         *
         * Since this is a background indicator, use only half
         * the maximum intensity.  fader is 0 to 128, so shift
         * by 8 rather than 7.
         */
        int_fast8_t fader = led_state.fader;
        led_state.fader = (int8_t)(fader + BREATH_TICK_INCREMENT);

        if (fader < 0)
            fader = -fader;  /* now 0 <= fader <= 128 */

        for (int led = 0; led < 3; ++led)
        {
            led_state.bg_prog.rgb[led] =
                (led_state.bg_rgb[led] * fader) >> 8;
        }

        /* We write the breathing pattern with length 1, repeat count 1
         * so that it always has to go through the update code, even though
         * the rest of this is a bit redundant.
         */
        led_state.program = &led_state.bg_prog;
        led_state.row = 0;
        led_state.length = 1;
        led_state.repeat = 1;

        LED_TIMER_SET_NEXT_INTERVAL(tmp);
    }
    else
    {
        /* Last element of current program (hopefully black) and no active
         * background program
         */
        LED_TIMER_STOP();
        led_state.program = NULL;
    }
}

/* This may later become public, but for now is kept internal.
 * Note that the stored program must take ticksPerMs and LED_SCALE_FACTOR
 * into account.
 */
static void LedFader_sequence(const led_program_t *sequence, int rows, int repeat)
{
    /* Assume that we have to stop the timer before we can start a new interval */

    LED_TIMER_STOP();

    /* When starting a foreground pattern, or turning on background for the
     * first time, we always clear the background fade level, so that it
     * starts from black.
     */
    led_state.fader = 0;

    led_state.program = sequence;
    led_state.length = rows;
    led_state.row = 0;
    led_state.repeat = repeat;

    /* We can get LedFader_Tick to do all the work - we just have to start
     * the timer for the first duration, and ask it to load up the leds for
     * the first entry. For a down-counter, it will update the reload register
     * with the next required interval. An up-counter will re-write the compare
     * register with the same value.
     */
    LED_TIMER_START(sequence->duration);
    LedFader_Tick();
}


/* Establish a simple program with on-off flashes */

void Led_Flash(uint8_t red, uint8_t green, uint8_t blue, uint32_t on, uint32_t off, uint32_t count)
{
    led_program_t *program = led_state.fg_prog;

    uint32_t now = Thingstream_Platform_getTimeMillis();

    if (led_state.program == program)
    {
        /* Ensure that previous program has run for its minimum time */
        while (TIME_COMPARE(now, <, led_state.soonest))
        {
            Platform_wfi();
            now = Thingstream_Platform_getTimeMillis();
        }
    }

    /* Ensure that this sequence flashes on at least once.
     * Since we start with a little bit of 'off', include
     * that.
     */
    led_state.soonest = now + on + 60;

    /* Start the sequence with a short black period, to make it
     * easier to pick out a strong flash from a background fader.
     * rgb for program [0] and [2] are always 0 so we don't need to
     * overwrite them.
     */
    program[0].duration = 50 * led_state.ticksPerMs;

    program[1].duration = on * led_state.ticksPerMs;
    program[1].rgb[0] = LED_SCALE_FACTOR * red;
    program[1].rgb[1] = LED_SCALE_FACTOR * green;
    program[1].rgb[2] = LED_SCALE_FACTOR * blue;

    program[2].duration = (off > 60 ? off - 50 : 10) * led_state.ticksPerMs;

    LedFader_sequence(program, 3, count);
}


void Led_Background(uint8_t red, uint8_t green, uint8_t blue)
{
    /* we update state without masking interrupts, which hopefully
     * works okay...
     *
     * One simple case is that there is background sequence programmed,
     * and we are just replacing it with a different sequence.
     * That will transition over to the new colour scheme transparently.
     *
     * Another easy case is, once we have set up the parameters,
     * we find no active sequence running, in which case we simply
     * start it going.
     *
     * It gets more complicated if there is a foreground sequence, but
     * no background sequence, and the foreground sequence ends during
     * this code update.
     */

    if ( (red | green | blue) == 0)
    {
        /* Cancelling any background sequence. The important
         * thing here is that if there is a background sequence
         * configured, stopping it abruptly could leave the
         * LEDs on. Changing the config in this order should
         * mean that, no matter whether an interrupt occurs
         * mid-way through the update, there should always
         * be at least one extra cycle which will write zero
         * before stopping the timer.
         */
        led_state.fader = 0;
        led_state.bg_prog.rgb[0] = 0;
        led_state.bg_prog.rgb[1] = 0;
        led_state.bg_prog.rgb[2] = 0;

        /* Now clear the duration - this tells LedFader_Tick() that there
         * is no background program. But if the timer is still running
         * (because there was previously a background program),
         * it will still write the next set of rgb values (black) to
         * the hardware before stopping the clock.
         */
        led_state.bg_prog.duration = 0;

        /* We must of course consider the possibility that there
         * was no foreground or background program running anyway !
         * But foreground sequences should always be written to
         * end with black, so there's nothing to reset.
         */
    }
    else
    {
        /* New background activity to set up. There's less that could
         * go wrong here...
         */
        led_state.bg_rgb[0] = LED_SCALE_FACTOR * red;
        led_state.bg_rgb[1] = LED_SCALE_FACTOR * green;
        led_state.bg_rgb[2] = LED_SCALE_FACTOR * blue;
        led_state.bg_prog.duration = BREATH_TICK_MS * led_state.ticksPerMs;

        if (led_state.program == NULL)
        {
            /* No running program - start it now */
            led_state.bg_prog.rgb[0] = 0;
            led_state.bg_prog.rgb[1] = 0;
            led_state.bg_prog.rgb[2] = 0;

            /* This will reset fader so that we start from black */
            LedFader_sequence(&led_state.bg_prog, 1, 1);
        }
        /* else it will either start when the foreground stops,
         * or just quietly replace the current background pattern,
         * without changing fader value
         */
    }
}


void Led_setRGB(uint8_t red, uint8_t green, uint8_t blue)
{
    LED_TIMER_STOP();
    led_state.program = NULL;
    LED_SET_RGB((LED_SCALE_FACTOR * red),
                (LED_SCALE_FACTOR * green),
                (LED_SCALE_FACTOR * blue));
}


void Led_Wait(bool full)
{
    if (led_state.program != led_state.fg_prog)
        return;

    if (full)
    {
        /* wait for foreground pattern to complete */
        do
        {
            Platform_wfi();
        }
        while (led_state.program == led_state.fg_prog);
    }
    else
    {
        /* Ensure that previous program has run for its minimum time */
        uint32_t now = Thingstream_Platform_getTimeMillis();
        while (TIME_COMPARE(now, <, led_state.soonest))
        {
            Platform_wfi();
            now = Thingstream_Platform_getTimeMillis();
        }
    }
}
