/*
 * Copyright 2021-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* Hardware abstraction for SODAQ SARA boards */

#include <Arduino.h>
#include <Wire.h>

#include "flags.h"        // configuration
#include <thingstream.h>
#include "platform.h"

#include "modem_uart_transport.h"

#define DEBUG_PORT_BAUD 115200

#define MODEM_SERIAL Serial1
#define MODEM_SERIAL_PARAMS 115200

#define GNSS_I2C_ADR 0x42

void Platform_init(void)
{
    pinMode(SARA_ENABLE, OUTPUT);
    pinMode(GPS_ENABLE, OUTPUT);
    pinMode(SARA_TX_ENABLE, OUTPUT);
    pinMode(SARA_R4XX_TOGGLE, INPUT);
    pinMode(ACCEL_INT1, INPUT);
    pinMode(ACCEL_INT2, INPUT);

    // the RGB LED pins get configured for PWM output
    // by analogWrite()

    SERIAL_PORT_MONITOR.begin(DEBUG_PORT_BAUD);
    while (!SERIAL_PORT_MONITOR)
    {
      // wait at most 2s for serial monitor to connect
      if (millis() > 2000) break;
    }
    MODEM_SERIAL.begin(MODEM_SERIAL_PARAMS);

    Wire.begin();
}

bool Platform_modemIsEnabled()
{
    uint32_t timeout = Thingstream_Platform_getTimeMillis() + 100;

    while (TIME_COMPARE(Thingstream_Platform_getTimeMillis(), <, timeout))
    {
        if (digitalRead(PIN_SERIAL1_RX) == HIGH)
        {
            return true;
        }
    }
    return false;
}

static void pulse_modem_pwrkey(uint16_t millis)
{
    /* The modem runs at a lower voltage than the MCU. The SARA_R4XX_TOGGLE
     * signal is not level shifted, so we must never actively pull that line
     * high. Instead, reconfigure the GPIO as an input to stop actively pulling
     * it low. */
    pinMode(SARA_R4XX_TOGGLE, OUTPUT);
    digitalWrite(SARA_R4XX_TOGGLE, LOW);
    delay(millis);
    pinMode(SARA_R4XX_TOGGLE, INPUT);
}

bool Platform_modemEnable(void)
{
    digitalWrite(SARA_ENABLE, HIGH);
    digitalWrite(SARA_TX_ENABLE, HIGH);

    delay(500);

    if (Platform_modemIsEnabled())
    {
        DEBUGOUT("Platform_modemEnable(): Already enabled\n");
        return true;
    }

    DEBUGOUT("Platform_modemEnable(): Enabling modem ... ");
    pulse_modem_pwrkey(2000);

    uint32_t timeout = Thingstream_Platform_getTimeMillis() + 10000;
    bool enabled = false;
    while (!enabled && TIME_COMPARE(Thingstream_Platform_getTimeMillis(), <, timeout))
    {
        if (Platform_modemIsEnabled())
        {
            enabled = true;
        }
        Platform_wfi();
    }
    DEBUGOUT(enabled ? "successful\n" : "failed\n");
    return enabled;
}

bool Platform_modemDisable(void)
{
    if (Platform_modemIsEnabled())
    {
        DEBUGOUT("Platform_modemDisable(): Disabling modem ... ");
        pulse_modem_pwrkey(2000);

        /* Wait for modem to turn off */
        uint32_t timeout = Thingstream_Platform_getTimeMillis() + 10000;
        bool disabled = false;
        while (!disabled && TIME_COMPARE(Thingstream_Platform_getTimeMillis(), <, timeout))
        {
            if (!Platform_modemIsEnabled())
            {
                disabled = true;
            }
            Platform_wfi();
        }
        DEBUGOUT(disabled ? "successful\n" : "failed\n");
    }
    else
    {
        DEBUGOUT("Platform_modemDisable(): Already disabled! Insufficient power?\n");
    }
    digitalWrite(SARA_ENABLE, LOW);
    return true;
}


uint32_t Platform_wire_read(uint8_t device, int16_t preamble, uint8_t *data, uint8_t len)
{
    if (preamble >= 0)
    {
        Wire.beginTransmission(device);
        Wire.write((uint8_t)preamble);
        if (Wire.endTransmission(false) != 0)
            return 0;
    }

    len = Wire.requestFrom(device, len);

    for (uint_fast16_t i = 0; i < len; ++i)
        *data++ = Wire.read();

    return len;
}


uint8_t Platform_wire_write(uint8_t device, const uint8_t *data, uint8_t len)
{
    Wire.beginTransmission(device);
    Wire.write(data, len);
    return Wire.endTransmission();
}


bool Platform_gnssEnable(void)
{
    DEBUGOUT("Platform_gnssEnable()\n");
    digitalWrite(GPS_ENABLE, true);
    return true;
}

bool Platform_gnssDisable(void)
{
    DEBUGOUT("Platform_gnssDisable()\n");
    digitalWrite(GPS_ENABLE, false);
    return true;
}


void Platform_gnssSend(uint8_t *buffer, uint32_t len)
{
    /* Device does not use register numbers for write,
     * so we can pass the entire message directly.
     */
    while (len > 0)
    {
        uint8_t now = (len <= 255 ? len : 255);
        Platform_wire_write(GNSS_I2C_ADR, buffer, now);
        len -= now;
    }
}


uint32_t Platform_gnssRecv(uint8_t *buffer, uint32_t bufsiz)
{
    /* The documentation describes the ports as 0xfd - 0xff,
     * but since the addresses are only 7 bits, they are
     * really 0x7d - 0x7f with the auto-increment bit set.
     */
    uint8_t sizebuf[2];
    if (Platform_wire_read(GNSS_I2C_ADR, 0xfd, sizebuf, 2) < 2)
        return 0;
    uint_fast16_t count = (sizebuf[0] << 8) | sizebuf[1];

    if (count > bufsiz)
        count = bufsiz;

    /* Cannot read more than 255 bytes with a single request,
     * since the implementation uses a 256-element ring buffer.
     */
    if (count > 255)
        count = 255;

    /* no need to resend register
     * Auto-increment stops at 0xff
     */
    return Platform_wire_read(GNSS_I2C_ADR, -1, buffer, (uint8_t)count);
}


bool Platform_DeepSleepEnabled(void)
{
    if (SERIAL_PORT_MONITOR)
    {
        /* The USB CDC endpoint has been opened by a connected host, such as a
         * serial terminal program for capturing logs. Avoid entering deep sleep,
         * as this would disconnect USB. */
        return false;
    }
    return true;
}

void Platform_wfi(void)
{
    __WFI();
}


void Platform_low_power_wfi(void)
{
    /* enter a deep sleep
     *
     * from https://forum.arduino.cc/index.php?topic=691880.0
     *
     * >> Due to a hardware bug on the SAMD21, the SysTick interrupts become
     * >> active before the flash has powered up from sleep, causing a hard fault
     * >> To prevent this the SysTick interrupts are disabled before entering sleep mode
     *
     * That also mentions SAMD21 errata 1.14.2 which talks about disabling power-saving
     * mode of the NVMCTRL, but I assume that's the responsibility of the startup code.
     * Not sure if these are the same problem - if NVM has been configured to never
     * power down, there shouldn't be an issue with systick ?
     *
     * https://www.embedded.com/the-definitive-guide-to-arm-cortex-m0-m0-ultralow-power-designs/
     * suggests __WFE() is slightly better than __WFI() when waiting for
     * interrupt handler to change a variable - avoids a small race. But here
     * it makes little difference whether we miss an interrupt occassionally.
     */

    SysTick->CTRL &= ~SysTick_CTRL_TICKINT_Msk;
    SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;
    __DSB();
    __WFI();
    SCB->SCR &= ~SCB_SCR_SLEEPDEEP_Msk;
    SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;
}


void Thingstream_Platform_puts(const char* str, int len)
{
    SERIAL_PORT_MONITOR.write(str, len);
}

/* Create a serial transport instance to communicate with the modem. */

ThingstreamTransport* modem_uart_transport_create(void)
{
    Thingstream_Util_printf("modem_uart_transport_create\n");

    enum debugLevel_e debugLevel;
#if defined(DEBUG_LOG_MODEM) && (DEBUG_LOG_MODEM > 0)
    /* Logging inside Tracker_run() will be provided by the Thingstream stack
     * so don't ask for any serial logging.
     */
    debugLevel = DEBUG_NONE;
#else /* DEBUG_LOG_MODEM */
    debugLevel = DEBUG_NORMAL;
#endif /* DEBUG_LOG_MODEM */

    ThingstreamTransport* transport = serial_transport_create(&MODEM_SERIAL, false, &SERIAL_PORT_MONITOR, debugLevel);
    if (transport == NULL)
    {
        DEBUGOUT("Unable to create serial transport device\n");
    }
    return transport;
}
