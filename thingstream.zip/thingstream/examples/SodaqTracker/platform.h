/*
 * Copyright 2017-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_PLATFORM_H_
#define INC_PLATFORM_H_

#include <stdint.h>
#include <stdbool.h>

#include "battery.h"
#include "accel.h"

#if defined(DEBUG_ENABLE)
/* For Thingstream_Util_printf() */
#include "thingstream.h"
#endif /* defined(DEBUG_ENABLE) */

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

extern void Platform_init(void);

/**
 * Sleep briefly until next interrupt
 */
extern void Platform_wfi(void);

/* Enter a low-power state, turning off some systems,
 * then wait for an interrupt.
 * External interrupts must have been configured to ensure
 * that the device wakes up again.
 */
extern void Platform_low_power_wfi(void);

extern bool Platform_modemIsEnabled(void);
extern bool Platform_modemEnable(void);
extern bool Platform_modemDisable(void);

extern bool Platform_gnssEnable(void);
extern bool Platform_gnssDisable(void);

/* Check whether the board may be put into deep sleep. */
extern bool Platform_DeepSleepEnabled(void);

/* Helper to read from the wire.
 * @param device  address of device
 * @param preamble optional initial byte to send, such as a register number, or -1 if not required
 * @param data the buffer to receive the data - must be less than 256
 * @param len number of bytes to receive - must be > 0
 * @return the number of bytes read
 */
extern uint32_t Platform_wire_read(uint8_t device, int16_t preamble, uint8_t *data, uint8_t len);

/* Helper to write to the wire. If the device requires a register number,
 * that must be included in the data stream.
 * @param device  address of device
 * @param data the data to send
 * @param len number of bytes to send - must be > 0
 * @return the value returned by Wire.endTransmission()
 */
extern uint8_t Platform_wire_write(uint8_t device, const uint8_t *data, uint8_t len);

extern void Platform_gnssSend(uint8_t *buffer, uint32_t len);
extern uint32_t Platform_gnssRecv(uint8_t *buffer, uint32_t bufsiz);

#define Platform_getBatteryState(v,c) Battery_getState(v,c)

/* temperature is provided by accelerometer */
#define Platform_getTemperature(p)  Accel_getTemperature(p)

#if defined(DEBUG_ENABLE)
#define DEBUGOUT(...) Thingstream_Util_printf(__VA_ARGS__)
#else /* defined(DEBUG_ENABLE) */
#define DEBUGOUT(...)
#endif /* defined(DEBUG_ENABLE) */

#if defined(__cplusplus)
}
#endif

#endif /* INC_PLATFORM_H_ */
