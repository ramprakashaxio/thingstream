/*
 * Copyright 2017-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Process NMEA input from the GNSS. The parser is implemented as a
 * Transport_callback, so it can directly be registered with a serial
 * transport.
 *
 * Example data from the SIM868:
 * $GNGGA,195550.000,3724.513638,N,12156.161851,W,1,11,0.97,-7.325,M,-25.528,M,,*6B
 *
 * NMEA sentences other than GGA are ignored. GnssNmea_getQuality() can be used
 * for polling whether a fix has been obtained (quality > 0).
 *
 * For u-blox receivers that support the protocols also parse MEASX messages.
 */
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#include "flags.h"
#include "platform.h"
#include "gnss_parser.h"
#include "gnss_measx.h"

#ifdef GNSS_ENABLED

/* Max length of a NMEA field (between ','); depends on GNSS */
#define MAX_FIELD_LEN 16

typedef struct
{
    /* Once we have a fix, record the data here */

    struct
    {
        int32_t latitude_udeg;
        int32_t longitude_udeg;
#ifdef MANUFACTURING_TEST_MODE
        uint32_t utc;
#endif /* MANUFACTURING_TEST_MODE */
        uint8_t quality;
    } ggaFields;

    /* Parsing state */

    enum { READ_IDLE,
           READ_FIELD,
           READ_CHECKSUM,
           READ_UGUBX_HEADER,
           READ_UGUBX_DATA_HI,
           READ_UGUBX_DATA_LO
         } state;
    uint8_t fieldCount;  /* index of current comma-separated field */
    uint8_t fieldLen;    /* number of characters collected in field[] */
    char field[MAX_FIELD_LEN];  /* accumulate the field characters */

    struct
    {
        uint8_t *buf;   /* Buffer for u-blox MEASX (or MEAS50) data */
        uint16_t size;  /* Size of measxBuf buffer */
        uint16_t len;   /* Length of MEASX message in measxBuf */
        measx_callback *callback; /* The handler to call when measx received */
    } measx;

} gnss_state_t;

static gnss_state_t gnss_state;


static bool processField(gnss_state_t *state);
static bool parseCoord(char *ptr, uint8_t fieldLen, int32_t* coord);



/****** debug support ****/

#if defined(GNSS_LOG_ENABLED) && defined(DEBUG_ENABLE)
/* Attempting to trace the gnss data in the interrupt callback tends
 * to cause loss of data. Use a scheme similar to the line buffer
 * and log it in the interrupt handler, but display it in the
 * foreground via debug_dump()
 * Buffer is empty when head == tail
 * tail always points at the start of the next line to display
 */

#define LOG_SIZE 512  /* must be power of 2 */

static struct
{
    /* fields written in interrupt handler */
    volatile uint16_t head;
    volatile int16_t lastChar;
    volatile uint16_t linesFilled;

    /* fields written by foreground reader */
    uint16_t tail;
    uint16_t linesEmptied;

    char buffer[LOG_SIZE + 1];  /* extra element is always 0 */
} debug;

/* Add one character to the log ring buffer, unless it is
 * full. Store \r or \n as 0, but don't store multiple 0
 */
static void debug_log(char c)
{
    uint16_t oldHead = debug.head;
    uint16_t newHead = (oldHead + 1) & (LOG_SIZE-1);
    if (newHead == debug.tail)
        return;  /* full */

    if (c == '\r' || c == '\n')
    {
        c = 0;
        if (debug.lastChar == 0)
            return;
    }

    debug.buffer[oldHead] = c;
    debug.lastChar = c;
    debug.head = newHead;
    if (c == 0)
        debug.linesFilled += 1;
}

/* Dump any complete lines from the ring buffer */
static void debug_dump(void)
{
    while (debug.linesEmptied != debug.linesFilled)
    {
        /* We know there is a 0 just past the end of the buffer, so the string
         * starting at tail is terminated.
         */
        int tail = debug.tail;
        char *p = debug.buffer + tail;
        int len = strlen(p);

        if (tail + len >= LOG_SIZE)
        {
            /* the 0 beyond the buffer was detected, so the line wraps.
             * The first character after the wrap might be a 0, but
             * that's okay
             */
            DEBUGOUT("NMEA: %s%s\n", p, debug.buffer);
            tail = 0;
            len = strlen(debug.buffer);
        }
        else
        {
            DEBUGOUT("NMEA: %s\n", p);
        }

        debug.tail = (tail + len + 1) & (LOG_SIZE - 1);
        debug.linesEmptied += 1;
    }
}

#else /* GNSS_LOG_ENABLED && DEBUG_ENABLE */

#define debug_log(c)
#define debug_dump()

#endif /* GNSS_LOG_ENABLED && DEBUG_ENABLE */

/** @see gnss.h */
void *GnssParser_init(bool enable, uint8_t* measxBuf, uint16_t measxSize, measx_callback measx_process)
{
    gnss_state_t *gstate = &gnss_state;

    /* If we are enabling GNSS then also zero the ggaFields structure.
     * But if we are disabling, then do not zero to keep any results.
     */
    if (enable)
    {
        Platform_gnssEnable();
        memset(&(gstate->ggaFields), 0, sizeof(gstate->ggaFields));
        gstate->state = READ_IDLE;
        gstate->measx.buf = measxBuf;
        gstate->measx.size = measxSize;
        gstate->measx.callback = measx_process;
    }
    else
    {
        Platform_gnssDisable();

        /* Flush anything lingering in the ring buffer */
        debug_log('\n');
        debug_dump();
    }

    return gstate;
}

/** @see gnss.h */
void *GnssNmea_init(bool enable)
{
    return GnssParser_init(enable, NULL, 0, NULL);
}

/** @see gnss.h */
uint8_t GnssNmea_getQuality(void)
{
    return gnss_state.ggaFields.quality;
}

/** @see gnss.h */
int32_t GnssNmea_getLatitude(void)
{
    return gnss_state.ggaFields.latitude_udeg;
}

/** @see gnss.h */
int32_t GnssNmea_getLongitude(void)
{
    return gnss_state.ggaFields.longitude_udeg;
}

#ifdef MANUFACTURING_TEST_MODE
uint32_t GnssNmea_time(void)
{
    return gnss_state.ggaFields.utc;
}
#endif /* MANUFACTURING_TEST_MODE */

/** @see gnss.h */
void GnssNmea_callback(void* cookie, uint8_t* data, uint16_t len)
{
    gnss_state_t *gstate = cookie;

    while (len-- > 0)
    {
        char ch = *data++;
        debug_log(ch);
        if (ch == '$')
        {
            gstate->state = READ_FIELD;
            gstate->fieldLen = 0;
            gstate->fieldCount = 0;
        }
        else if ((ch == '+') && (gstate->measx.buf != NULL))
        {
            // Look for +UGUBX: packet containing MEASX/MEAS50
            gstate->state = READ_UGUBX_HEADER;
            gstate->fieldLen = 0;
            gstate->fieldCount = 0;
        }
        else if (gstate->state == READ_FIELD)
        {
            if (ch == ',')
            {
                /* reached end of a field - parse it */
                if (!processField(gstate))
                    gstate->state = READ_IDLE;
            }
            else if (ch == '*')
            {
                /* reached end of last field - parse it */
                if (processField(gstate))
                    gstate->state = READ_CHECKSUM;
                else
                    gstate->state = READ_IDLE;
            }
            else
            {
                /* Add character to current field accumulator */
                uint_fast8_t len = gstate->fieldLen;
                gstate->field[len] = ch;
                if (++len >= MAX_FIELD_LEN)
                    gstate->state = READ_IDLE; /* discard line on field overflow */
                gstate->fieldLen = (uint8_t)len;
            }
        }
        else if (gstate->state == READ_CHECKSUM)
        {
            /* TODO: not yet supported */
            gstate->state = READ_IDLE;
        }
        else if (gstate->state == READ_UGUBX_HEADER)
        {
            if ((ch == '"') && (gstate->fieldLen == 7))
            {
                /* reached end of a '+XXXX: "' */
                if (memcmp("UGUBX: ", gstate->field, 7) == 0)
                {
                    gstate->state = READ_UGUBX_DATA_HI;
                    gstate->measx.len = 0;
                }
                else
                {
                    gstate->state = READ_IDLE; /* discard line if other URC */
                }
            }
            else if (gstate->fieldLen < 9)
            {
                /* Add character to current field accumulator */
                uint_fast8_t len = gstate->fieldLen;
                gstate->field[len] = ch;
                gstate->fieldLen = (uint8_t)len + 1;
            }
            else
            {
                gstate->state = READ_IDLE; /* discard line if +XXXX too long */
            }
        }
        else if (gstate->state == READ_UGUBX_DATA_HI)
        {
            if (ch == '"')
            {
                /* End of data */
                Thingstream_Util_printf("FOUND: +UGUBX: '");
                for (uint16_t idx = 0; idx < gstate->measx.len; idx++)
                    Thingstream_Util_printf("%02x", gstate->measx.buf[idx]);
                Thingstream_Util_printf("'\n");
                gstate->measx.callback(gstate->measx.buf, gstate->measx.len);
                gstate->state = READ_IDLE;
            }
            else
            {
                gstate->field[0] = ch;
                gstate->state = READ_UGUBX_DATA_LO;
            }
        }
        else if (gstate->state == READ_UGUBX_DATA_LO)
        {
            /* Convert previous char and this char to a hex byte.
             * This will detect odd number (i.e. '"') as a non-hex nibble.
             */
            gstate->field[1] = ch;
            const char* nibblePair = &gstate->field[0];
            const char* end = nibblePair + 2;
            uint8_t data = Thingstream_Util_parseHex(nibblePair, end, &end);
            if (end == (nibblePair + 2))
            {
                uint16_t len = gstate->measx.len;
                gstate->measx.buf[len] = data;
                if (++len >= gstate->measx.size)
                    gstate->state = READ_IDLE; /* discard data on overflow */
                gstate->measx.len = len;
                gstate->state = READ_UGUBX_DATA_HI;
            }
            else
            {
                gstate->state = READ_IDLE; /* discard line if data malformed */
            }
        }
    }
}

/**
 * Parse current field.
 * This is called whenever we encounter ',' or '*'.
 * Use the information in gstate->parser to interpret the field.
 * @param gstate the gnss state
 * @return true if the field was parsed successfully, false on error or when
 * encountering data not supported by the parser
 */
static bool processField(gnss_state_t *gstate)
{
    bool ret = false;

    uint_fast8_t fieldLen = gstate->fieldLen;
    char *field = gstate->field;
    gstate->fieldLen = 0;  /* reset for next field */

    /* we can unconditionally increment fieldCount here since the
     * value only matters in the case of a true return.
     */
    switch (gstate->fieldCount++)
    {
        case 0: /* sentence identifier */
            if ((fieldLen == 5) && (strncmp(field + 2, "GGA", 3) == 0))
                ret = true;
            break;
        case 1: /* GNSS time. */
#ifdef MANUFACTURING_TEST_MODE
            {
                char *ptr = field;
                uint32_t utc = 0;
                while (fieldLen-- > 0)
                {
                    utc *= 10;
                    utc += (*ptr++ - '0');
                }
                gstate->ggaFields.utc = utc;
            }
#endif /* MANUFACTURING_TEST_MODE */
            ret = true;
            break;
        case 2: /* lattitude */
            ret = parseCoord(field, fieldLen, &(gstate->ggaFields.latitude_udeg));
            break;
        case 3: /* N/S */
            if (fieldLen == 1)
            {
                if (field[0] == 'S')
                    gstate->ggaFields.latitude_udeg *= -1;
                ret = true;
            }
            break;
        case 4: /* longitude */
            ret = parseCoord(field, fieldLen, &(gstate->ggaFields.longitude_udeg));
            break;
        case 5: /* E/W */
            if (fieldLen == 1)
            {
                if (field[0] == 'W')
                    gstate->ggaFields.longitude_udeg *= -1;
                ret = true;
            }
            break;
        case 6: /* quality */
            if ((fieldLen == 1) && field[0] > '0')
            {
                gstate->ggaFields.quality = field[0] - '0';
                ret = true;
            }
            break;
        default: /* fall through and return false */
            break;
    }

    return ret;
}

/**
 * Parse a coordinate in the format "DDDMM.MMMMMM" and store the result as
 * microdegrees in @p coord. Uses #field and #fieldLen to access the raw
 * coordinate data.
 * @param ptr the character-sequence to parse
 * @param fieldLen the length of the character sequence
 * @param coord points to where the result should be stored
 * @return true if successfully parsed, false on error
 */
static bool parseCoord(char *ptr, uint8_t fieldLen, int32_t* coord)
{
    if (fieldLen < 8)
        return false; /* should see DDMM.MMM at least */

    char *end = ptr + fieldLen;

    /* convert "12345.67890" to 12345678
     *         "12345.6"     to 12345600
     *         "12345"       to 12345000 */
    int32_t tmp = 0;
    int scale = 0;
    while (ptr < end)
    {
        char ch = *ptr++;
        if ((ch >= '0') && (ch <= '9'))
        {
            tmp = (10 * tmp) + (ch - '0');
            scale /= 10;
        }
        else if (ch == '.')
        {
            if (scale > 0)
                return false; /* more than one '.' */
            scale = 1000;
            if (end - ptr > 3)
                end = ptr + 3; /* stop 3 digits after '.' */
        }
        else
        {
            return false;
        }
    }
    if (scale == 0)
        scale = 1000; /* no '.' seen, multiply by 1000 */
    tmp *= scale;

    *coord = (tmp / 100000 * 1000000) +  /* degrees to microdegrees */
             (tmp % 100000 * 1000 / 60); /* milliminutes to microdegrees */

    return true;
}


#ifdef DEBUG_ENABLE

/* A wrapper around Platform_wfi() that can be used while waiting for
 * gnss data to become available. When gnss logging is enabled, it
 * takes the opportunity to write the buffers to stdout - doing
 * it in the interrupt handler can cause data to be lost.
 */
void GnssNmea_wfi(void)
{
    debug_dump();
    Platform_wfi();
}

#endif /* DEBUG_ENABLE */

#endif /* GNSS_ENABLED */
