/*
 * Copyright 2021-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdbool.h>

#include "nvmem.h"
#include "config.h"
#include "tracker2.h"
#include "thingstream.h"
#include "tokenizer.h"

typedef enum config_context_e
{
    CTXT_ROOT      = (1 << 0),
    CTXT_CONFIG    = (1 << 1),
    CTXT_INTERVAL  = (1 << 2),
    CTXT_LOCATION  = (1 << 3),
    CTXT_ASSISTNOW = (1 << 4)
} ConfigContext_t;

struct ConfigState_s
{
    NVMem *nvmem;
    ConfigContext_t context;
    bool locPrioCleared;
};

/* Cause an error if NUM_LOCATIONS changes and we forget to change
 * the initializer for locationSourceNames below. */
typedef char CHECK_LOCATION_NAMES_SIZE[NUM_LOCATIONS == 5 ? 1 : -1];

static const char * const locationSourceNames[NUM_LOCATIONS] = {
    [locationGnss]  = "gnss",
    [locationCell]  = "cell",
    [locationWifi]  = "wifi",
    [locationMeasx] = "measx",
    [locationBLE]   = "ble"
};


/**
 * Check whether the null-terminated str matches the character sequence
 * starting at key with length klen.
 * @return true if the key matches the given string
 */
static bool match(const char *str, uint8_t *key, uint16_t klen)
{
    int idx;
    for (idx = 0; idx < klen; idx++)
    {
        // TODO: allow case insensitive matches?
        if ((str[idx] != (char) key[idx]) || (str[idx] == '\0'))
        {
            return false;
        }
    }
    // All klen characters matched. Check that we've reached the end of str
    return str[idx] == '\0';
}

static bool readInt(uint8_t *value, uint16_t len, int32_t *out, int32_t min, int32_t max)
{
    const char *start = (const char*) value;
    const char *end = start + len;
    const char *rem;
    int32_t intValue = Thingstream_Util_parseInt(start, end, &rem);
    if ((rem == end) && (intValue >= min) && (intValue <= max))
    {
        *out = intValue;
        return true;
    }
    return false;
}

static void processToken(TokenizerValue_t type, uint8_t *key, uint16_t klen, uint8_t *value, uint16_t vlen,
        void *cookie)
{
    struct ConfigState_s *state = (struct ConfigState_s*) cookie;

    switch (type)
    {
    case TOKENIZER_OBJECT:
        {
            ConfigContext_t savedContext = state->context;
            if ((state->context == CTXT_ROOT) && match("config", key, klen))
            {
                state->context = CTXT_CONFIG;
            }
            else if ((state->context & (CTXT_ROOT | CTXT_CONFIG)) && match("interval", key, klen))
            {
                state->context = CTXT_INTERVAL;
            }
            else if ((state->context & (CTXT_ROOT | CTXT_CONFIG)) && match("loc", key, klen))
            {
                state->context = CTXT_LOCATION;
            }
            else if ((state->context & (CTXT_ROOT | CTXT_CONFIG)) && match("AssistNow", key, klen))
            {
                state->context = CTXT_ASSISTNOW;
            }
            else
            {
                break;
            }
            tokenizeString(value, vlen, processToken, cookie);
            state->context = savedContext;
        }
        break;

    case TOKENIZER_STRING:
    case TOKENIZER_CHARS:
        if (state->context & (CTXT_ROOT | CTXT_CONFIG | CTXT_INTERVAL))
        {
            int32_t intValue;
            if (readInt(value, vlen, &intValue, 0, UINT16_MAX))
            {
                if (match("min", key, klen))
                {
                    state->nvmem->interval.min = intValue;
                    break;
                }
                else if (match("max", key, klen))
                {
                    state->nvmem->interval.max = intValue;
                    break;
                }
            }
        }
        if (state->context & (CTXT_ROOT | CTXT_CONFIG | CTXT_LOCATION))
        {
            int32_t intValue;
            if (readInt(value, vlen, &intValue, -1, MAX_PRIORITY_CLASS))
            {
                int locSrc;
                for (locSrc = 0; locSrc < NUM_LOCATIONS; locSrc++)
                {
                    if (match(locationSourceNames[locSrc], key, klen))
                    {
                        if (!state->locPrioCleared)
                        {
                            for (int i = 0; i < NUM_LOCATIONS; i++)
                            {
                                state->nvmem->priority[i] = -1;
                            }
                            state->locPrioCleared = true;
                        }
                        state->nvmem->priority[locSrc] = intValue;
                        break;
                    }
                }
            }
        }
        if (state->context & (CTXT_ROOT | CTXT_CONFIG))
        {
            int32_t intValue;
            if (match("motion", key, klen)
                    && readInt(value, vlen, &intValue, 0, MAX_MOTION_SENSITIVITY))
            {
                state->nvmem->motionSensitivity = intValue;
                break;
            }
        }
        if (state->context & (CTXT_ASSISTNOW))
        {
            int32_t intValue;
            if (match("age", key, klen)
                    && readInt(value, vlen, &intValue, 0, MAX_ASSISTNOW_AGE))
            {
                state->nvmem->assistNow.age = intValue;
                break;
            }
            if (match("lat", key, klen)
                    && readInt(value, vlen, &intValue, -90, +90))
            {
                state->nvmem->assistNow.lat = intValue;
                break;
            }
            if (match("lon", key, klen)
                    && readInt(value, vlen, &intValue, -180, +180))
            {
                state->nvmem->assistNow.lon = intValue;
                break;
            }
        }
        break;

    case TOKENIZER_ARRAY:
    default:
        // not supported; ignore
        break;
    }
}

void parseConfigString(uint8_t *input, uint16_t len, NVMem *nvmem)
{
    struct ConfigState_s state = {
        .nvmem = nvmem,
        .context = CTXT_ROOT,
        .locPrioCleared = false
    };
    tokenizeString(input, len, processToken, &state);
}

void writeConfigString(JsonBuffer *jbuf, NVMem *nvmem)
{
    json_key_append(jbuf, "config");
    json_start_object(jbuf);
    json_key_append(jbuf, "interval");
    json_start_object(jbuf);
    json_named_uint32_append(jbuf, "max", nvmem->interval.max);
    json_named_uint32_append(jbuf, "min", nvmem->interval.min);
    json_end_object(jbuf); /* interval */
    json_named_uint32_append(jbuf, "motion", nvmem->motionSensitivity);
    json_key_append(jbuf, "AssistNow");
    json_start_object(jbuf);
    json_named_uint32_append(jbuf, "age", nvmem->assistNow.age);
    json_named_int32_append(jbuf, "lat", nvmem->assistNow.lat);
    json_named_int32_append(jbuf, "lon", nvmem->assistNow.lon);
    json_end_object(jbuf); /* AssistNow */
    json_key_append(jbuf, "loc");
    json_start_object(jbuf);
    for (int locSrc = 0; locSrc < NUM_LOCATIONS; locSrc++)
    {
        if (nvmem->priority[locSrc] >= 0)
        {
            json_named_int32_append(jbuf, locationSourceNames[locSrc], nvmem->priority[locSrc]);
        }
    }
    json_end_object(jbuf); /* loc */
    json_end_object(jbuf); /* config */
}
