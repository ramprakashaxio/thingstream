/*
 * Copyright 2021 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* The accelerometer outputs int16_t values. Resolution is selectable,
 * allowing only the top 12,10 or 8 bits to be significant.
 * The range can be configured to be +/- 2,4,8 or 16g. (Though the spec
 * for 16g seems anomalous - behaves more like 24g.)
 * In 2g range, each unit change corresponds to 0.06mg => 32767 = 1.97g
 * In 8g range, each unit change corresponds to 0.24mg => 32767 = 7.84g
 *
 * In 8-bit,  4g range, sensitivity is 31mg  -  (1 << 8) * 0.12
 * In 12-bit, 8g range, sensitivity is 3.8mg -  (1 << 4) * 0.24
 *
 * But in this application, that sort of sensitivity is really just noise.
 *
 * There's a high-pass filter, which can use to screen out the effect
 * of gravity. But the documentation doesn't really specify what
 * HPCF ("high-pass filter cutoff frequency selection") does.
 *
 * We use the 'active/inactive' feature by configuring a threshold.
 * The device enters a low-power (10Hz) inactive state when the reading
 * is below the threshold, and returns to normal operation when
 * the reading crosses above it. This state is reflected in
 * an output pin, which we can very easily monitor.
 *
 * There is some hysteresis : the device always becomes
 * active immediately, but only enters the inactive state after
 * the low reading has persisted for some (configurable) time.
 */

#include <Arduino.h>
#include <thingstream.h>
#include "platform.h"
#include "tracker2.h"   /* for MAX_MOTION_SENSITIVITY */

/* I2C bus addresses */

#define ACCEL  0x19
#define MAGNET 0x1e  /* unused */

/* Register offsets.
 * Auto-increment on register is indicated by setting
 * top bit of the register
 */
#define AUTOINCREMENT 0x80

#define OUT_TEMP_L_A   0x0c
#define OUT_TEMP_H_A   0x0d
#define TEMP_CFG_REG_A 0x1f

#define CTRL_REG1_A  0x20
#define CTRL_REG2_A  0x21
#define CTRL_REG3_A  0x22
#define CTRL_REG4_A  0x23
#define CTRL_REG5_A  0x24
#define CTRL_REG6_A  0x25
#define OUT_X_L_A    0x28
#define OUT_X_H_A    0x29
#define OUT_Y_L_A    0x2a
#define OUT_Y_H_A    0x2b
#define OUT_Z_L_A    0x2c
#define OUT_Z_H_A    0x2d
#define Act_THS_A    0x3e
#define Act_DUR_A    0x3f


/* Config messages to send over i2c to the device.
 * Note that the register number is the first byte
 * of each message.
 */

/* Configuration of the control registers */

static const uint8_t accel_ctrl_config[] =
{
   TEMP_CFG_REG_A | AUTOINCREMENT,  /* destination */
   0xc0,   /* TEMP_CFG_REG_A - enabled - also requires BDU */
   0x2f,   /* CTRL_REG1_A - 10Hz, low power (8 bits), XYZ enabled */
   0x88,   /* CTRL_REG2_A - HPM=10 (enabled), HPCF=00 (?), FDS=1 (output regs receive filtered data) */
   0x00,   /* CTRL_REG3_A - no interrupts enabled */
   0x80,   /* CTRL_REG4_A - BDU enabled, 2g range, not HR */
   0x00,   /* CTRL_REG5_A - FIFO disabled */
   0x08,   /* CTRL_REG6_A - P2_ACT=1 */
};

#if MAX_MOTION_SENSITIVITY != 5
#error Need to update sensitivity table
#endif

/* Configuration of the activity/inactivity feature, for each
 * sensitivity level. Each of these writes the Act_THS_A and
 * Act_DUR_A registers.
 * Since we are using 8-bit resolution and 2g range, the
 * threshold is in units of 16mg
 * The duration is the delay before becoming inactive, in units
 * of 8 / ODR. Since we are using 10Hz, that's 0.8s.
 * The delay is only for the active to inactive transition,
 * so there's no particular need to use a high value. But we also
 * don't want lots of interrupts as it moves between active and
 * inactive states. A value of 5 (for 4s) seems reasonable.
 */
static const uint8_t accel_activity_config[][3] =
{

 /* For sensitivity 0, use threshold of 0 to turn the feature off.
  * We do lose the feature that the device switches to its low-power
  * state when inactive, but that appears to just mean 10Hz and 8-bit
  * resolution, and we're already using that mode. Unfortunately, the
  * INT2_PIN remains in the low (active) state, so code testing that
  * pin will need to be aware of that.
  */
 {
    Act_THS_A | AUTOINCREMENT,
    0,
    0
 },

 /* sensitivity 1 = 1024mg */
 {
    Act_THS_A | AUTOINCREMENT,
    64,
    5
 },

 /* sensitivity 2 = 512mg */
 {
    Act_THS_A | AUTOINCREMENT,
    32,
    5
 },

 /* sensitivity 3 = 256mg */
 {
    Act_THS_A | AUTOINCREMENT,
    16,
    5
 },

 /* sensitivity 4 = 128mg */
 {
    Act_THS_A | AUTOINCREMENT,
    8,
    5
 },

 /* sensitivity 5 = 48mg
  * (anything lower just tends to trigger randomly)
  */
 {
    Act_THS_A | AUTOINCREMENT,
    3,
    5
 }
};


/* Remember the configured sensitivity level.
 * Powers up in the 0 state.
 */
static uint8_t sensitivity;


void Accel_init()
{
    /* configure the control registers */
    Platform_wire_write(ACCEL, accel_ctrl_config, sizeof(accel_ctrl_config));
}


void Accel_setSensitivity(int s)
{
    if (s > MAX_MOTION_SENSITIVITY)
        s = MAX_MOTION_SENSITIVITY;
    if (s != sensitivity)
    {
        Platform_wire_write(ACCEL, accel_activity_config[s], sizeof(accel_activity_config[s]));
        sensitivity = s;
    }
}


bool Accel_isActive(void)
{
    /* Report false when sensitivity is set to 0, even though the
     * pin will be in the low state.
     */
    return (sensitivity != 0) && (digitalRead(ACCEL_ACTIVITY_PIN) == LOW);
}


/* Get temperature in units of 0.1C */

bool Accel_getTemperature(int16_t *out)
{
    uint8_t buffer[2];

    if (Platform_wire_read(ACCEL, OUT_TEMP_L_A | AUTOINCREMENT, buffer, 2) == 2)
    {
        /* The result is given as signed 16-bit fixed-point (8.8)
         * delta from 25.0 C. The top bit of the fractional part
         * does appear to vary, so assume resolution of 0.5 degrees
         * is available.
         */
        int16_t raw = (int16_t)((buffer[1] << 8) | buffer[0]);
        *out = 250 + 5 * (raw >> 7);
        return true;
    }
    return false;
}
