/*
 * Copyright 2017-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string.h>
#include <stdlib.h>

#include "thingstream.h"

#include "cell_info.h"
#include "flags.h"
#include "modem_multiplexor.h"

#ifndef LOCATE_MOBILE_CELL_METHODS
/* If the locate methods are not specified then try all methods in turn */
#define LOCATE_MOBILE_CELL_METHODS  LOCATE_MOBILE_CELL_ANY
#endif /* LOCATE_MOBILE_CELL_METHODS */

#if (LOCATE_MOBILE_CELL_METHODS != LOCATE_MOBILE_CELL_NONE)

/* Mobile cell information is sent for at most MAX_CELL_INFO cells.
 * Only the ones with the strongest signal are reported. */
#ifndef MAX_CELL_INFO
#define MAX_CELL_INFO 5
#endif /* MAX_CELL_INFO */

static CellInfo cellInfoArray[MAX_CELL_INFO];
static uint8_t cellInfoCount = 0;

#if (LOCATE_MOBILE_CELL_METHODS != LOCATE_MOBILE_CELL_CxREG)
static void addCellInfo(CellInfo* latest)
{
    int dstIdx = -1;
    if (cellInfoCount < MAX_CELL_INFO)
    {
        dstIdx = cellInfoCount++;
    }
    else
    {
        int minIdx = 0;
        int16_t minRssi = cellInfoArray[0].rssi;
        int i;
        for (i = 1; i < cellInfoCount; i++)
        {
            int16_t rssi = cellInfoArray[i].rssi;
            if (rssi < minRssi)
            {
                minRssi = rssi;
                minIdx = i;
            }
        }
        if (latest->rssi <= minRssi)
        {
            /* discard latest info */
            return;
        }
        dstIdx = minIdx;
    }
    memcpy(&cellInfoArray[dstIdx], latest, sizeof(CellInfo));
}
#endif /* METHODS != CxREG */


#if (LOCATE_MOBILE_CELL_METHODS & (LOCATE_MOBILE_CELL_QOPS | LOCATE_MOBILE_CELL_QENG | LOCATE_MOBILE_CELL_CSURVC))
/*
 * The Quectel UG95 cell scan returns signal strength in dBm but
 * the current server flows for triangulation expect the encoded
 * rssi value as supplied by the Simcom AT+CNETSCAN.
 * TS-382 has been raised to request that the server slows accept
 * both encoded and raw signal strengths.
 * Until the change requested in TS-382 is implemented we need to
 * convert raw dBmvalues into Simcom encoded values.
 *
 * @param  dBm the raw signal strength in dBm (always negative)
 * @return the Simcom encoded strength (0..31 or 99).
 */
static int16_t convertToSimcomRssi(int32_t dBm)
{
    /*
     * Simcom    raw dBm
     *   0        -113 dBm or less
     *   1        -111 dBm
     *  2...30    -109... -53 dBm
     *  31        -51 dBm or greater
     *  99        Not known or not detectable
     */
    if (dBm >= 0)
        return 99;
    if (dBm >= -51)
        return 31;
    if (dBm <= -113)
        return 0;
    return ((dBm >> 1) + 56);
}
#endif /* METHODS & (QOPS | QENG | CSURVC) */

/*
 * Print the given (unsigned) value as either 4 or 8 hex chars.
 *
 * @param result the buffer to put the 4 or 8 hex chars.
 * @param value the value to print in hex.
 */
#if (LOCATE_MOBILE_CELL_METHODS != LOCATE_MOBILE_CELL_CxREG)
static void hexPrint(char *result, uint32_t value)
{
    if (value >= 0x10000)
    {
        hexPrint(result, value >> 16);
        result += 4;
    }
    *result++ = "0123456789ABCDEF"[(value >> 12) & 0xF];
    *result++ = "0123456789ABCDEF"[(value >>  8) & 0xF];
    *result++ = "0123456789ABCDEF"[(value >>  4) & 0xF];
    *result++ = "0123456789ABCDEF"[(value      ) & 0xF];
}
#endif /* METHODS != CxREG */

/*
 * Parse the mobile cell scan output using a format string to decode.
 *
 * @param ptr the input data tobe parsed
 * @param endPtr the char past the end of the input data
 * @param format the pattern to define the format of the fields in the data
 *   If the format specifier starts with a ':' then a "<key>:" will be stripped
 *   from the front of each field entry. The letters below parse individual
 *   fields from comma separated entries.
 *   '-' : skip field
 *   'M' : parse MCC
 *   'N' : parse MNC
 *   'C' : parse cellId (extract hex digits)
 *   'c' : parse cellId (extract decimal digits)
 *   'L' : parse lac (extract hex digits)
 *   'l' : parse lac (extract decimal digits)
 *   'S' : parse rssi or dBm
 * * @return a pointer to the first byte after the parsed data
 */
#if (LOCATE_MOBILE_CELL_METHODS != LOCATE_MOBILE_CELL_CxREG)
static const char* parseCellInfo(const char *ptr, const char *endPtr, const char *format)
{
    CellInfo cellInfo = EMPTY_CELLINFO;
    bool stripKeys = false;
    if (*format == ':')
    {
        stripKeys = true;
        ++format;
    }
    char fCh;
    while ((fCh = *format++) != '\0')
    {
        if (stripKeys)
        {
            do
            {
                if (ptr >= endPtr)
                    return endPtr;
            } while (*ptr++ != ':');
        }
        const char *field = ptr;
        while ((++ptr <= endPtr) && (ptr[-1] != ','))
            ;
        int fieldLen = ptr - field - 1;
        if (fCh == '-')
            continue; /* field ignored */
        if (fieldLen == 0)
            return endPtr; /* field missing */
        switch (fCh)
        {
        case 'M':
            if (fieldLen >= (int)sizeof(cellInfo.mcc))
                return endPtr; /* mcc too large */
            memcpy(cellInfo.mcc, field, fieldLen);
            break;

        case 'N':
            if (fieldLen >= (int)sizeof(cellInfo.mnc))
                return endPtr; /* mnc too large */
            memcpy(cellInfo.mnc, field, fieldLen);
            break;

        case 'C':
            if (fieldLen == 1 && *field == '0')
                return endPtr;  /* ignore cellid == 0 */
            if (fieldLen >= (int)sizeof(cellInfo.cellId))
                return endPtr; /* cellId too large */
            memcpy(cellInfo.cellId, field, fieldLen);
            break;

        case 'c':
            {
                uint32_t cellId = Thingstream_Util_parseUInt(field, endPtr, NULL);
                hexPrint(cellInfo.cellId, cellId);
            }
            break;

        case 'L':
            if (fieldLen >= (int)sizeof(cellInfo.lac))
                return endPtr; /* lac too large */
            memcpy(cellInfo.lac, field, fieldLen);
            break;

        case 'l':
            {
                uint32_t lac = Thingstream_Util_parseUInt(field, endPtr, NULL);
                hexPrint(cellInfo.lac, lac);
            }
            break;

        case 'S':
            cellInfo.rssi = Thingstream_Util_parseInt(field, endPtr, NULL);
#if (LOCATE_MOBILE_CELL_METHODS & (LOCATE_MOBILE_CELL_QOPS | LOCATE_MOBILE_CELL_CSURVC))
            if (cellInfo.rssi < 0)
                cellInfo.rssi = convertToSimcomRssi(cellInfo.rssi);
#endif /* METHODS & (QOPS | CSURVC) */
            break;

        default:
            return endPtr; /* Format error */
        }
    }
    addCellInfo(&cellInfo);
    return ptr;
}
#endif /* METHODS != CxREG */


#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_CNETSCAN)
static void cnetscan_callback(const char* data, uint16_t len)
{
    while ((len > 0) && (data[len - 1] == '\n'))
        len--;
    if ((len > 20) && (memcmp(data, "Operator:", 9) == 0))
    {
        const char *ptr = (const char*)data;
        const char *dataEnd = (const char*)data + len;
        /* Operator:"<Name>",MCC:<MCC>,MNC:<MNC>,Rxlev:<Rxlev>,
         *                Cellid:<CellID>,Arfcn:<Arfcn>,Lac:<Lac>,Bsic:<Bsic>
         */
        parseCellInfo(ptr, dataEnd, ":-MNSC-L");
    }
}
#endif /* METHODS & CNETSCAN */

#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_QENG)
static void qeng_callback(const char* data, uint16_t len)
{
    while ((len > 0) && (data[len - 1] == '\n'))
        len--;
    /*
     * Parse the AT+QENG? response (format AT+QENG=1,1)
     *
     * First line is serving cell
     *  +QENG: 0,<mcc>,<mnc>,<lac>,<cellid>,<bcch>,<bsic>,<dbm>,<c1>,<c2>, ...
     *
     * then up to six neighbour cells
     *  +QENG: 1,(<ncell>,<bcch>,<dbm>,<bsic>,<c1>,<c2>,<mcc>,<mnc>,<lac>,<cellid>)
     */
    if ((len < 50) || (memcmp(data, "+QENG: ", 7) != 0))
        return;

    const char *ptr = (const char*)data + 7;
    const char *dataEnd = (const char*)data + len;
    char ch = *ptr++;
    if ((ch != '0') && (ch != '1'))
        return; /* Wrong format */
    if (*ptr++ != ',')
        return; /* Missing comma */
    if (ch == '0')
    {
        /* +QENG: 0,<mcc>,<mnc>,<lac>,<cellid>,<bcch>,<bsic>,<dbm>,... */
        parseCellInfo(ptr, dataEnd, "MNLC--S");
    }
    else
    {
        /* +QENG: 1,(<ncell>,<bcch>,<dbm>,<bsic>,<c1>,<c2>,<mcc>,<mnc>,<lac>,<cellid>) */
        do
        {
            ptr = parseCellInfo(ptr, dataEnd, "--S---MNLC");
        } while (ptr < dataEnd);
    }
}
#endif /* METHODS & QENG */

#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_QOPS)
static void qops_callback(const char* data, uint16_t len)
{
    while ((len > 0) && (data[len - 1] == '\n'))
        len--;
    /*
     * Parse the (undocumented) AT+QOPS=1 response.
     *
     *  +QOPS: <stat>,<op-num>,"<op-name>",<mcc>,<mnc>,<lac>,<cid>,<bs>,<dBm>,x,0,0,0,0,0,0,0,0,0
     *
     * My Quectel UG95 responded:
     *
     *  +QOPS: 2,2987,"vodafone UK",234,15,120,2C8F726,220,-98,245,0,0,0,0,0,0,0,0,0
     *  +QOPS: 2,2938,"vodafone UK",234,15,120,2C8F530,225,-95,245,0,0,0,0,0,0,0,0,0
     *  +QOPS: 2,2963,"O2 - UK",234,10,54D0,2C8C1AA,472,-100,242,0,0,0,0,0,0,0,0,0
     *  +QOPS: 2,10761,"EE",234,30,45D,8B99B0,179,-93,251,0,0,0,0,0,0,0,0,0
     *  +QOPS: 2,10588,"3 UK",234,20,6B,8BD7A2,189,-94,252,0,0,0,0,0,0,0,0,0
     *  +QOPS: 2,3012,"O2 - UK",234,10,54D0,2C8BB72,81,-99,246,0,0,0,0,0,0,0,0,0
     *  +QOPS: 2,10564,"3 UK",234,20,6B,8BD787,189,-97,251,0,0,0,0,0,0,0,0,0
     *  +QOPS: 2,10612,"3 UK",234,20,6B,8BD65F,189,-91,253,0,0,0,0,0,0,0,0,0
     *  +QOPS: 2,10661,"O2 - UK",234,10,54D0,2C858D0,262,-110,243,0,0,0,0,0,0,0,0,0
     *  +QOPS: 2,10637,"O2 - UK",234,10,54D0,2C850A5,262,-106,245,0,0,0,0,0,0,0,0,0
     */
    if ((len < 50) || (memcmp(data, "+QOPS: ", 7) != 0))
        return;

    const char *ptr = (const char*)data + 7;
    const char *ptrEnd = (const char*)data + len;
    parseCellInfo(ptr, ptrEnd, "---MNLC-S");
}
#endif /* METHODS & QOPS */

#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_CSURVC)
static void csurvc_callback(const char* data, uint16_t len)
{
    while ((len > 0) && (data[len - 1] == '\n'))
        len--;
    /*
     * Parse the Telit AT#CSURVC response.
     *
     *  <arfcn>,<bsic>,<rxLev>,<ber>,<mcc>,<mnc>,<lac>,<cellId>,...
     *
     * My telit GL-685 responded:
     *
     *  723,-100
     *  768,-100
     *  766,-100
     *  619,-100
     *  678,-100
     *  90,4,-100,0.04,234,15,289,57374,5,3,66 77 90
     *
     * Note that the lac and cellId appear in this data as decimal number
     * and we store the values in CellInfo as hex (most other modems).
     */
    if (len < 30)
        return;

    const char *ptr = (const char*)data;
    const char *ptrEnd = (const char*)data + len;
    parseCellInfo(ptr, ptrEnd, "--S-MNlc");
}
#endif /* METHODS & CSURVC */

#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_UCFSCAN)
static void ucfscan_callback(const char* data, uint16_t len)
{
    /* Output is of the form
     *  +UCFSCAN: 0,1001,0,40,234,10,5454,81D5,0,50,1
     * The signal strength field varies in position and encoding
     * depending on the RAT - for now, just ignore it
     */
    if ((len > 10) && (memcmp(data, "+UCFSCAN: ", 10) == 0))
        parseCellInfo(data + 10, data + len, "----MNLC");
}

/* Helper to send a UCFSCAN request, interrupting it if it
 * doesn't respond within the timeout.
 */
static bool issue_ucfscan(ThingstreamTransport *modem,
                          ThingstreamTransportResult (*send_modem_line)(ThingstreamTransport* self, const char* line, uint32_t millis),
                          const char *cmd)
{
    /* The manual gives the maximum time as up to 3 minutes,
     * but since we can choose to wait for less, we may need
     * interrupt it.
     */
    ThingstreamResult tRes = send_modem_line(modem, cmd, 60000);
    if (tRes == TRANSPORT_SUCCESS)
    {
        return true;
    }
    else
    {
        /* A no-op to interrupt the request, if necessary */
        send_modem_line(modem, "AT", 1000);
    }
    return false;
}
#endif /* METHODS & UCFSCAN */

#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_CxREG)
static void cops_callback(const char* data, uint16_t len)
{
    /* Parse lines of the form:
     *   +COPS: 0,2,"23415",3
     * and combine with CREG lac/cid data
     */
    CellInfo *cellInfo = &cellInfoArray[0];

    if (strncmp(data, "+COPS: 0,2,\"", 12) == 0)
    {
        const char* end = data + len;
        data += 12;
        const char* quote = data;
        while (*quote != '"')
        {
            if (++quote >= end)
                return;
        }
        memcpy(cellInfo->mcc, data, 3);
        data += 3;
        len = quote - data;
        if (len > 3)
            return;
        memcpy(cellInfo->mnc, data, len);

        cellInfo->rssi = SDK_DATA_GSM_BEARER(strength);
    }

    /* The callback may be for a CxREG result. On every callback,
     * check for valid parsed lac/cid data.
     */
    if (SDK_DATA_AT_CREG(lac)[0] != 0 && SDK_DATA_AT_CREG(cid)[0] != 0)
    {
        memcpy(cellInfo->lac, SDK_DATA_AT_CREG(lac), sizeof(SDK_DATA_AT_CREG(lac)));
        memcpy(cellInfo->cellId, SDK_DATA_AT_CREG(cid), sizeof(SDK_DATA_AT_CREG(cid)));
    }
}
#endif /* METHODS & CxREG */

#endif /* METHODS != NONE */

#define ASSERT(test)  if (test) ; else return NULL

CellInfo *get_cell_info(ThingstreamTransport *modem,
                        ThingstreamTransportResult (*send_modem_line)(ThingstreamTransport* self, const char* line, uint32_t millis),
                        int *count)
{

#if (LOCATE_MOBILE_CELL_METHODS == LOCATE_MOBILE_CELL_NONE)

    *count = 0;
    return NULL;

#else /* METHODS != NONE */

    cellInfoCount = 0;
    *count = 0;  /* in case an assert causes a premature return */
    ThingstreamTransportResult tRes;

    tRes = send_modem_line(modem, "ATE0", 1000);
    ASSERT(tRes == TRANSPORT_SUCCESS);

#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_CNETSCAN)
    tRes = send_modem_line(modem, "AT+CNETSCAN=1", 1000);
    if (tRes == TRANSPORT_SUCCESS)
    {
        Application_activeModemCallback = cnetscan_callback;
        tRes = send_modem_line(modem, "AT+CNETSCAN", 45000);
        ASSERT(tRes == TRANSPORT_SUCCESS);
        goto scandone;
    }
#endif /* METHODS & CNETSCAN */

#if (LOCATE_MOBILE_CELL_METHODS & (LOCATE_MOBILE_CELL_QOPS | LOCATE_MOBILE_CELL_QENG))
    /* The QENG needs a QOPS (to do the actual scan) first */
    Application_activeModemCallback = qops_callback;
    tRes = send_modem_line(modem, "AT+QOPS=1", 120000);
    if (tRes == TRANSPORT_SUCCESS)
    {
#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_QENG)
        if (cellInfoCount == 0)
        {
            Application_activeModemCallback = qeng_callback;
            send_modem_line(modem, "AT+QENG=1,1", 1000);
            (void) send_modem_line(modem, "AT+QENG=0,0", 2000);
        }
#endif /* METHODS & QENG */
        goto scandone;
    }
#endif /* METHODS & (QOPS | QENG) */

#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_CSURVC)
    {
        Application_activeModemCallback = csurvc_callback;
        tRes = send_modem_line(modem, "AT#CSURVC", 120000);

        if (tRes == TRANSPORT_SUCCESS)
            goto scandone;
    }
#endif /* METHODS & CSURVC */

#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_UCFSCAN)
    Application_activeModemCallback = ucfscan_callback;
    /* Try each of the permitted values 0 (GSM), 7 (LTE CatM1), 9 (NB-IoT).
     * Only access methods allowed by URAT will return a result.
     */
    if (issue_ucfscan(modem, send_modem_line, "AT+UCFSCAN=0") && (cellInfoCount > 0))
        goto scandone;

    if (issue_ucfscan(modem, send_modem_line, "AT+UCFSCAN=7") && (cellInfoCount > 0))
        goto scandone;

    if (issue_ucfscan(modem, send_modem_line, "AT+UCFSCAN=9") && (cellInfoCount > 0))
        goto scandone;
#endif /* METHODS & UCFSCAN */

#if (LOCATE_MOBILE_CELL_METHODS & LOCATE_MOBILE_CELL_CxREG)

    if (send_modem_line(modem, "AT+COPS=3,2", 2000) == TRANSPORT_SUCCESS)
    {
        Application_activeModemCallback = cops_callback;
        /* The cops_callback is looking for lines of the form
         *    +COPS: 0,2,"23415",3
         * that occur with a valid lac/cid from a previous +CxREG: line.
         * The SDK automatically extracts lac/cid and stores them in
         * SDK_DATA_AT_CREG(lac) and SDK_DATA_AT_CREG(cid).
         * Because short form +CxREG: lines will invalidate the lac/cid,
         * issue AT+CxREG? until we have all the information.
         *
         * Since this method can provide at most one result, the callback
         * can build up the data directly into cellInfoArray[0].  So we
         * only need to issue the COPS once.
         */
        memset(cellInfoArray, 0, sizeof(cellInfoArray[0]));
        static const char * const cmds[] =
        {
            "AT+CSQ",
            "AT+COPS?",
            "AT+CREG=2",
            "AT+CREG?",
            "AT+CGREG=2",
            "AT+CGREG?",
            "AT+CEREG=2",
            "AT+CEREG?",
            NULL
        };
        for (int idx = 0; idx <= 3; idx++)
        {
            const char * const *cmdPtr = cmds;
            do
            {
                (void) send_modem_line(modem, *cmdPtr++, 2000);

                if (cellInfoArray[0].mnc[0] != 0 &&
                    cellInfoArray[0].cellId[0] != 0)
                {
                    /* Both halves of the data have been supplied */
                    cellInfoCount = 1;
                    goto scandone;
                }
            } while (*cmdPtr != NULL);
        }
        goto scandone;
    }
#endif /* METHODS & CxREG */

 scandone:
    Application_activeModemCallback = NULL;
    *count = cellInfoCount;
    return cellInfoArray;
#endif /* METHODS != NONE */
}
