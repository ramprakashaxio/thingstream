/*
 * Copyright 2021-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdlib.h>

#include "flags.h"
#include "thingstream.h"
#include "platform.h"
#include "modem_config.h"
#include "modem_multiplexor.h"
#include "modem_uart_transport.h"

/* This is set to the expected string. It can optionally end
 * in '*' or '$' to indicate the type of match to perform:
 *  '$' indicates an exact match - the '$' must correspond to
 *  the end of the input string.
 *  '*' indicates a substring match - the '*' matches any
 *  number of trailing characters in the data string.
 * Substring matching is the default if neither is present.
 * '*' is really only needed if the last character in
 * the pattern is a literal '$' or '*'.
 *
 * The callback sets it to NULL if the response is matched, as a flag.
 */
static const char *expected_response;

/* The modem callback registered with the modem multiplexor
 * Compare modem input against expected_response, if any,
 * and clear expected_response on a match.
 *
 * All spaces from the modem are ignored.
 */
static void modem_config_callback(const char *data, uint16_t len)
{
    (void)len;
    const char *expected = expected_response;
    if (expected != NULL)
    {
        char nc;  // read-ahread of the expected string
        char ec;  // current expected char

        nc = *expected++;
        while ( (ec = nc) != 0)
        {
            char dc;  // current data char
            do
                dc = *data++;
            while (dc == ' ');  // ignore all input whitespace

            if ( (nc = *expected++) == 0)
            {
                // ec is last char of expected string
                // check for one of the special control characters.
                if (ec == '*')
                    break;  // success

                if (ec == '$')
                {
                    if (dc == 0)
                        break;  // success
                    else
                        return; // no match
                }
            }

            if (ec != dc)
            {
                return;  // mismatch
            }
        }

        // if we get here, match was successful
        expected_response = NULL;
    }
}

/* A shorthand for Thingstream_Modem_sendline() - assumes
 * a local variable * called 'modem' is in scope
 */
#define sendline(cmd) \
    Thingstream_Modem_sendLine(modem, (cmd), 10000)


/* Some commands may have to be sent repeatedly until the
 * modem gives an OK response.
 * This helper issues the request repeatedly until it succeeds.
 * Return true on success, false on timeout.
 */
static bool repeatCmd(ThingstreamTransport *modem, const char *cmd, uint16_t duration)
{
    uint32_t now = Thingstream_Platform_getTimeMillis();
    uint32_t limit = now + duration;
    for (;;)
    {
        if (sendline(cmd) == TRANSPORT_SUCCESS)
            return true;
        now = Thingstream_Util_run(modem, 2000);
        if (TIME_COMPARE(now, >=, limit))
            return false;
    }
}

/* Send a command to the modem, and check that the expected response is
 * seen
 */
static bool expect(ThingstreamTransport *modem, const char *cmd, const char *response)
{
    expected_response = response;
    return (sendline(cmd) == TRANSPORT_SUCCESS) && (expected_response == NULL);
}


static void resetModem(ThingstreamTransport *modem)
{
    sendline("AT+CFUN=15");
    Thingstream_Util_run(modem, 1000);

    // shutdown the modem transport so that the next call to
    // sendline will rerun the early handshaking sequence
    modem->shutdown(modem);
}



bool check_modem_config(ThingstreamTransport *modem)
{
    Application_activeModemCallback = modem_config_callback;

    if (expect(modem, "AT+UMNOPROF?", "+UMNOPROF:100"))
    {
        if (expect(modem, "AT+URAT?", "+URAT:7,9") &&
            expect(modem, "AT+USVCDOMAIN?", "+USVCDOMAIN:2") &&
            expect(modem, "AT+UBANDMASK?", "+UBANDMASK:0,530574") &&
            expect(modem, "AT+CPSMS?", "+CPSMS:0") &&
            expect(modem, "AT+CEDRXS?", "+CEDRXS:$") &&
            expect(modem, "AT+UPSMR?", "+UPSMR:1"))
        {
            // Skip querying AT+UFOTACONF=2, as it is slow
            // and interferes with disabling ULWM2M
            return true;  // configuration matches
        }

        // if we get here, the profile is 100, but one of the
        // settings is wrong. In order to perform a reset,
        // we first need to switch away from profile 100

        sendline("AT+COPS=2");
        sendline("AT+UMNOPROF=0");
        resetModem(modem);
    }

    // switch to profile 100 and configure
    sendline("AT+COPS=2");
    sendline("AT+UMNOPROF=100");
    resetModem(modem);

    sendline("AT+COPS=2");
    if (expect(modem, "AT+GMM", "SARA-R422"))
    {
        /* SARA R422 does not support UFOTACONF */
    }
    else
    {
        /* The modem will not respond to UFOTACONF read/set
         * until one of its internal modules has started up,
         * which can take some time. So we need to issue
         * this repeatedly.
         * Do this first, so that if one-time config is
         * interrupted by the user, the values we check for
         * at every startup still reflect that we have not
         * completed the one-time modem config.
         */
        repeatCmd(modem, "AT+UFOTACONF=2,-1", 45000);
    }

    sendline("AT+URAT=7,9");
    sendline("AT+USVCDOMAIN=2");
    sendline("AT+UBANDMASK=0,530574");
    sendline("AT+CPSMS=0");
    sendline("AT+CEDRXS=0,2");
    sendline("AT+CEDRXS=0,4");
    sendline("AT+CEDRXS=0,5");
    sendline("AT+UPSMR=1");
    resetModem(modem);
    // Make sure the modem has fully restarted before continuing
    sendline("AT");

    return true;
}



void setup_modem(void)
{
    // only need a small buffer since we're not sending anything
    static uint8_t modem_buffer[128];
    ThingstreamTransport *transport;

    transport = modem_uart_transport_create();

#if defined(RING_BUFFER_LENGTH) && (RING_BUFFER_LENGTH > 0)
    static uint8_t ringBuffer[RING_BUFFER_LENGTH];
    transport = Thingstream_createRingBufferTransport(transport,
                                                      ringBuffer, RING_BUFFER_LENGTH);
#endif /* RING_BUFFER_LENGTH */

#ifdef DEBUG_ENABLE
    transport = Thingstream_createModemLogger(transport,
                                              Thingstream_Util_printf,
                                              TLOG_TRACE | TLOG_TIME);
#endif

    transport = Thingstream_createModemTransport(transport, 0,
                                                 modem_buffer, sizeof(modem_buffer),
                                                 UDP_MODEM_INIT);

    check_modem_config(transport);
    transport->shutdown(transport);
}
