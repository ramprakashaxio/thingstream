/*
 * Copyright 2017-2021 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file
 * @brief An interface for flashing patterns on LED.
 *
 * A generic interrupt-driven led fader library providing a background
 * fading pattern, which can be briefly interrupted by a foreground
 * flashing program. Quite sophisticated foreground patterns could be
 * set up, but for now, only simple on-off flashes are offered.
 * For use on a target with
 *   - PWM-controlled RGB led
 *   - an interval timer with (at least) 1-ms resolution.
 *
 * The timer can be either an up-counter which allows the overflow
 * to be adjusted while the counter is running, or a down-counter which
 * allows the next period to be set without changing the current period.
 *
 * Platform must provide led_fader_config.h which defines:
 *
 *  LED_SET_RGB()                      - write values to the led
 *  LED_TIMER_START(ticks)             - start timer with given interval
 *  LED_TIMER_STOP                     - stop timer - no need to save settings
 *  LED_TIMER_SET_NEXT_INTERVAL(ticks) - for down-counter, next interval
 *  LED_TIMER_SET_COMPARE(ticks)       - for an up-counter, current interval
 *
 * LED_TIMER_SET_NEXT_INTERVAL should be a no-op for an up-counter
 * LED_TIMER_SET_COMPARE should be a no-op for a down-counter
 *
 * These must be callable from within interrupt handler.
 */

#ifndef INC_LED_FADER_H_
#define INC_LED_FADER_H_

#include "leds.h"

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif


/**
 * Initialise the LED fader library. Platform must separately set up timers.
 * @param ticksPerMs frequency of the timer counter, in kHz
 */
extern void LedFader_Init(uint32_t ticksPerMs);

/**
 * LED fader interrupt handler. Platform must set up timers to call this
 * on timer interrupt.
 */
extern void LedFader_Tick(void);

#if defined(__cplusplus)
}
#endif

#endif /* INC_LED_FADER_H_ */
