/*
 * Copyright 2021 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_TOKENIZER_H_
#define INC_TOKENIZER_H_

#include <stdint.h>

#include "nvmem.h"

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

typedef enum tokenizer_valuetype_e
{
    TOKENIZER_STRING,
    TOKENIZER_CHARS,
    TOKENIZER_OBJECT,
    TOKENIZER_ARRAY,
    TOKENIZER_NUM_TYPES
} TokenizerValue_t;

typedef void (*TokenHandler_t)(TokenizerValue_t type, uint8_t *key, uint16_t klen, uint8_t *value,
        uint16_t vlen, void *cookie);

void tokenizeString(uint8_t *str, uint16_t len, TokenHandler_t handler, void *cookie);

#if defined(__cplusplus)
}
#endif

#endif /* INC_TOKENIZER_H_ */
