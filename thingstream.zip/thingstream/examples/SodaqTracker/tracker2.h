/*
 * Copyright 2017-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_TRACKER_H_
#define INC_TRACKER_H_

#include <stdint.h>
#include <stdbool.h>

#include "thingstream.h"
#include "nvmem.h"

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

/* Location sources. Add new sources at the end, since the
 * numbers are used as indexes into various tables.
 */

typedef enum LocationType_e
{
    locationGnss,
    locationCell,
    locationWifi,
    locationMeasx,
    locationBLE,

    NUM_LOCATIONS
} LocationType;


/* Invocaton events.
 * Add new events at the end - there are tables that
 * make use of the ordering.
 * Config is not included in this list, since a config event
 * generates a completely different message.
 */
typedef enum InvocationType_e
{
    eventTimer,
    eventButton,
    eventMotion,
    eventPower,

    NUM_EVENTS
} InvocationType;

/**
 * Perform the actions of the tracker app
 * @param invocation one of eventPower, eventMotion, etc
 * @param nvmem the non-volatile store
 * @param pEpochGuess the address of the (best guess) current unix epoch time
 * @param modemCreateFlags the flags to use when creating the modem transport
 * @return true on successful send of message, false otherwise
 */
extern bool Tracker_run(InvocationType invocation,
                        NVMem *nvmem,
                        uint32_t *pEpochGuess,
                        uint16_t modemCreateFlags);


/* upper limit for specifying priority classes */
#define MAX_PRIORITY_CLASS 9

/* upper limit for motion sensitivity setting */
#define MAX_MOTION_SENSITIVITY 5

/* upper limit for asistnow.age setting */
#define MAX_ASSISTNOW_AGE 0x3FFF

/* This defines the structure to be stored by nvmem */

struct nvmem_s
{
    /* reserved for use by the platform, perhaps to store
     * version number information, or for flash wear levelling
     */
    uint32_t  platform;

    /* min and max intervals, in minutes */
    struct
    {
        uint16_t  min, max;
    } interval;

    /* The motion detection sensitivity, from 0 (disabled) to
     * 5 (most sensitive) */
    uint8_t motionSensitivity;

    struct __attribute__((packed))
    {
        int32_t   // 3 fields packed into 4 bytes
            age: 15,  /* Age in minutes. Disables AssistNow if <= 0. */
            lat: 8,   /* Approximate latitude, -90..+90 */
            lon: 9;   /* Approximate longitude -180..+180 */
    } assistNow;

    /* for each event location source, the priority class.
     * -1 means never
     *  0 means always
     * Otherwise, priority classes are visited in order
     * 1,2,3...MAX_PRIORITY_CLASS until one group has provided a location.
     */
    int8_t   priority[NUM_LOCATIONS];
};


/**
 * Send the line to the modem and wait for an OK response.
 *
 * @param line a null-terminated line to send to the modem ("\r\n" will be added)
 * @param millis the maximum number of milliseconds to run
 * @return an integer status code (success / fail)
 */
ThingstreamTransportResult Tracker_modem_send_line(const char* line, uint32_t millis);


/**
 * Get the modem ThingstreamTransport used by the Tracker.
 *
 * @return the modem transport
 */
ThingstreamTransport* Tracker_get_modem(void);


/**
 * Get the modem inner ThingstreamTransport used by the Tracker.
 *
 * @return the modem inner transport
 */
ThingstreamTransport* Tracker_get_modem_inner(void);


/* The Thingstream domain key to use. For SIM-based devices, NULL can be used,
 * since the SIM should already be associated with the correct domain.
 */
#ifndef DOMAIN_KEY
#define DOMAIN_KEY NULL
#endif


/* increment this when the layout changes - platforms might
 * choose to incorporate it into the value they store in
 * the platform field.
 */
#define NVMEM_FORMAT_VERSION  3


#if defined(__cplusplus)
}
#endif

#endif /* INC_TRACKER_H_ */
