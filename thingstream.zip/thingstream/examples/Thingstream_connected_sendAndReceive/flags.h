/*
 * Copyright 2022-2023 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file
 * @brief Configuration file for the examples running on Arduino IDE
 */


#ifndef INC_FLAGS_H_
#define INC_FLAGS_H_

#include "Arduino.h"

/* Specify the modem initialisation routine to pass to
 * Thingstream_createModemTransport() unless already setup
 * in hardware_config.h
 */
//#define THINGSTREAM_MODEM_INIT Thingstream_<modem or Ussd>Init

/*
 * Thingstream Modem and Client logging
 *
 * Set the following defines to '1' to enable Thingstream modem
 * and/or client transport logging.
 *
 * If the modem logging appears to truncate long messages, that
 * might indicate a timing issue with the logging. See the example
 * documentation for details.
 */
#define DEBUG_LOG_MODEM 0
#define DEBUG_LOG_CLIENT 0

/* When DEBUG_LOG_MODEM > 0 and logging is provided by a Thingstream transport
 * default the serial logging to DEBUG_NONE.
 */
#if (DEBUG_LOG_MODEM > 0)
#define DEBUG_LEVEL DEBUG_NONE
#else
#define DEBUG_LEVEL DEBUG_VERBOSE
#endif

#endif /* INC_FLAGS_H_ */
