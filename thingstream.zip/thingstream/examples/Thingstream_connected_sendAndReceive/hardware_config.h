/*
 * Copyright 2021-2023 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_HARDWARE_CONFIG_H_
#define INC_HARDWARE_CONFIG_H_

/* SoftwareSerial, if used, requires the RX, TX pins to be specified.
 * Make sure to check SoftwareSerial restrictions on which pins can
 * be used. Some implementations require change interrupt capability
 * on the RX pin.
 */


#if defined(ARDUINO_AVR_MEGA2560)
    // modem on RX1/TX1 pins
    #define MODEM_SERIAL Serial1
    #define MODEM_SERIAL_PARAMS 19200

#elif defined(ARDUINO_ARCH_ESP8266)
    #include <SoftwareSerial.h>
    // modem on GPIO14(RX) and GPIO12(TX)
    SoftwareSerial swSerial(14, 12);
    #define MODEM_SERIAL swSerial
    #define MODEM_SERIAL_PARAMS 19200

#elif defined(ARDUINO_ESP32_DEV)
    #warning "Assuming LilyGo T-Call target"
    HardwareSerial hwSerial(1);
    #define MODEM_SERIAL hwSerial
    // Configure hardware UART 1 using pins GPIO26(RX) and GPIO27(TX)
    #define MODEM_SERIAL_PARAMS 115200,SERIAL_8N1,26,27
    #define THINGSTREAM_MODEM_INIT Thingstream_Simcom800Init
    #define MODEM_POWER 23
    #define DEBUG_SERIAL Serial

#elif defined(ARDUINO_ARCH_ESP32)
    HardwareSerial hwSerial(1);
    #define MODEM_SERIAL hwSerial
    #define MODEM_SERIAL_PARAMS 115200,SERIAL_8N1,4,5
    #define DEBUG_SERIAL Serial

#elif defined(ARDUINO_SAMD_MKRGSM1400)
    #define MODEM_SERIAL Serial2
    #define THINGSTREAM_MODEM_INIT Thingstream_uBloxSaraU2Init
    // GSM_RESETN name is misleading; pin is active high
    #define MODEM_RESET GSM_RESETN

#elif defined(ARDUINO_SAMD_MKRNB1500)
    #define MODEM_SERIAL SerialSARA
    #define THINGSTREAM_MODEM_INIT Thingstream_uBloxSaraR4Init
    #define MODEM_POWER SARA_PWR_ON
    // SARA_RESETN name is misleading; pin is active high
    #define MODEM_RESET SARA_RESETN

#elif defined(ARDUINO_SODAQ_SARA) || defined(ARDUINO_SODAQ_SFF)
    #define THINGSTREAM_MODEM_INIT Thingstream_uBloxSaraR4Init
    #define MODEM_SERIAL Serial1
    #define DEBUG_SERIAL SerialUSB
    #define MODEM_POWER SARA_ENABLE
    // SARA_R4XX_TOGGLE has no level shifter; do not set to OUTPUT HIGH
    #define MODEM_EXTRA_POWERON() do { \
            pinMode(SARA_R4XX_TOGGLE, OUTPUT); \
            digitalWrite(SARA_R4XX_TOGGLE, LOW); \
            delay(2000); \
            pinMode(SARA_R4XX_TOGGLE, INPUT); \
        } while(0)

#elif defined(ARDUINO_ARCH_SAMD)
    // modem on D0(RX) and D1(TX)
    #define MODEM_SERIAL Serial1
    #define DEBUG_SERIAL SerialUSB

#elif defined(TEENSYDUINO) && defined(__arm__)
    #define MODEM_SERIAL Serial1
    #define DEBUG_SERIAL SerialUSB

#elif defined(ARDUINO_ARCH_STM32)
    #include <HardwareSerial.h>
    HardwareSerial Serial1(USART1);
    #define MODEM_SERIAL Serial1
#endif

// Default to 115200 baud for platforms that do not define a rate above
#ifndef MODEM_SERIAL_PARAMS
    #define MODEM_SERIAL_PARAMS 115200
#endif

#ifndef MODEM_EXTRA_POWERON
#define MODEM_EXTRA_POWERON() do {} while(0)
#endif

#endif /* INC_HARDWARE_CONFIG_H_ */
