/*
 * Copyright 2018-2025 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <Arduino.h>    // Include before thingstream.h to avoid issues with stdbool.h
#include "thingstream.h"
#include "run_example.h"
#include "click_select.h"

typedef const struct ModemClickDetails_s
{
    struct
    {
        uint32_t name;   // A Mikroe_xxx_Click define from click_select.h
        const char *nameString;
        const char *areaString;
    } click;
    struct
    {
        const char* name;
        ThingstreamModemUdpInit * init;
    } modem;
} ModemClickDetails;


/* The table of supported MikroBus modem Clicks */
static const ModemClickDetails modems[] =
{
    {
        /* MIKROE-4325 see https://www.mikroe.com/lte-iot-5-click */
        { Mikroe_LTE_IoT_5_Click,      "LTE IoT 5", "" },
        "u-blox SARA-R510M8S",
        Thingstream_uBloxSaraR5Init
    },
    {
        /* MIKROE-5290 see https://www.mikroe.com/lte-iot-7-click */
        { Mikroe_LTE_IoT_7_Click,      "LTE IoT 7", "" },
        "u-blox SARA-R422M8S",
        Thingstream_uBloxSaraR4Init
    },
    {
        /* MIKROE-3072 see https://www.mikroe.com/lte-iot-click */
        { Mikroe_LTE_IoT_Click,        "LTE IoT", ""   },
        "u-blox SARA-R410M",
        Thingstream_uBloxSaraR4Init
    },
    {
        /* MIKROE-5991 see https://www.mikroe.com/lte-cat4-3-click-data */
        { Mikroe_LTE_Cat_4_3_Click,     "LTE Cat.4 3", "" },
        "u-blox LARA-R6004D",
        Thingstream_uBloxLaraR6Init
    },
    {
        /* MIKROE-5890 see https://www.mikroe.com/4g-ltegnss-click */
        { Mikroe_4G_LTE_GNSS_Click,     "4G LTE&GNSS", "" },
        "u-blox LENA-R8001",
        Thingstream_uBloxLenaR8Init
    },
    {
        /* MIKROE-2527 see https://www.mikroe.com/4g-lte-e-click */
        { Mikroe_4G_LTE_EU_Click,      "4G LTE", "EU"   },
        "u-blox LARA-R211",
        Thingstream_uBloxLaraR2Init
    },
    {
        /* MIKROE-2226 see https://www.mikroe.com/3g-ea-click */
        { Mikroe_3G_EU_Aus_Click,      "3G", "EU+Aus" },
        "Quectel UG95EA",
        Thingstream_QuectelUG95Init
    },
    {
        /* MIKROE-2296 see https://www.mikroe.com/3g-aa-click */
        { Mikroe_3G_USA_Click,         "3G", "USA" },
        "Quectel UG95AA",
        Thingstream_QuectelUG95Init
    },
    {
        /* MIKROE-2439 see https://www.mikroe.com/gsm-gnss-click */
        { Mikroe_GSM_GNSS_Click,       "GSM/GNSS", ""   },
        "Quectel MC60",
        Thingstream_QuectelMC60Init
    },
    {
        /* MIKROE-3144 see https://www.mikroe.com/lte-iot-2-click */
        { Mikroe_LTE_IoT_2_Click,      "LTE IoT 2", "" },
        "Quectel BG96",
        Thingstream_QuectelBG96Init
    },
    {
        /* MIKROE-4118 see https://www.mikroe.com/lte-iot-3-click */
        { Mikroe_LTE_IoT_3_Click,      "LTE IoT 3", "" },
        "Cinterion EXS82-W",
        Thingstream_ThalesExs82wInit
    },
    {
        /* MIKROE-2440 see https://www.mikroe.com/gsmgnss-2-click */
        { Mikroe_GSM_GNSS_2_Click,     "GSM/GNSS 2", "" },
        "Sim868",
        Thingstream_Simcom868Init
    },
    {
        /* MIKROE-6152 see https://www.mikroe.com/lte-cat1-3-click */
        { Mikroe_LTE_Cat_1_3_EU_Click,     "LTE Cat.1 3", "EU" },
        "Quectel EG91",
        Thingstream_QuectelEG91Init
    },

#ifdef UNTESTED
    {
        /* MIKROE-4388 see https://www.mikroe.com/lte-iot-6-click */
        { Mikroe_LTE_IoT_6_Click,      "LTE IoT 6", "" },
        "u-blox SARA-R412M",
        Thingstream_uBloxSaraR4Init
    },
    {
        /* MIKROE-2535 see https://www.mikroe.com/4g-lte-na-click */
        { Mikroe_4G_LTE_USA_Click,     "4G LTE", "USA" },
        "u-blox LARA-R204",
        Thingstream_uBloxLaraR2Init
    },
    {
        /* MIKROE-3350 see https://www.mikroe.com/4g-lte-att-click */
        { Mikroe_4G_LTE_USA_ATT_Click, "4G LTE", "USA-AT&T" },
        "u-blox LARA-R202",
        Thingstream_uBloxLaraR2Init
    },
    {
        /* MIKROE-3351 see https://www.mikroe.com/4g-lte-apj-click */
        { Mikroe_4G_LTE_Japan_Click,   "4G LTE", "Japan" },
        "u-blox LARA-R280",
        Thingstream_uBloxLaraR2Init
    },
    {
        /* MIKROE-4465 see https://www.mikroe.com/lte-iot-9-click */
        { Mikroe_LTE_IoT_9_Click,      "LTE IoT 9", "" },
        "Cinterion EXS62-W",
        Thingstream_ThalesExs62wInit
    }
#endif /* UNTESTED */
};
#define NUM_MODEMS (sizeof(modems) / sizeof(modems[0]))
#define LAST_MODEM_CHAR(x) ((char)((x + NUM_MODEMS - 1)))

/**
 * Find the modem click in the modems[] table by name.
 *
 * @param clickName the Mikroe_xxx_Click name from the table above
 *        of the modem click board.
 * @return the index in the modems[] table or -1 if it could not be found.
 */
int findClickByName(uint32_t clickName)
{
    for (int idx = 0; idx < (int)NUM_MODEMS; idx++)
    {
        if (clickName == modems[idx].click.name)
        {
            return idx;
        }
    }
    DEBUG_SERIAL.print("Unable to find MIKROE-");
    DEBUG_SERIAL.print(clickName);
    DEBUG_SERIAL.print(" in the modems[] table");
    return -1;
}



/**
 * Return the Mikroe_xxx_Click name from within the modems[] table.
 *
 * @param clickIdx the index into the table of modem Clicks
 * @return the name (one of the Mikroe_xxx_Click defines above)
 *         of the modem click board, or zero if not found.
 */
uint32_t getClickNameFromIdx(int clickIdx)
{
    if ((clickIdx >= 0) && (clickIdx < (int)NUM_MODEMS))
    {
        return modems[clickIdx].click.name;
    }
    return 0;
}

/* The following sets of defines map the MikroBus pins for each slot to the
 * corresponding ArduinoDue internal pin numbers as used by the Flip&Click
 */
#define A_PWM ( 6)
#define B_PWM ( 7)
#define C_PWM ( 8)
#define D_PWM ( 9)

#define A_INT (26)
#define B_INT (27)
#define C_INT (28)
#define D_INT (29)

#define A_AN  (54)
#define B_AN  (55)
#define C_AN  (56)
#define D_AN  (57)

#define A_RST (33)
#define B_RST (34)
#define C_RST (35)
#define D_RST (38)

#define A_CS  (77)
/* The FlipAndClick hardware is based on the ArduinoDue, but the Due
 * software does not have an entry in its tables that allows PA29 (wired to
 * the CS pin of slot B) to be used a general IO. We use a fake value here
 * that will be handled specially by the doPinMode(), doDigitalWrite() and
 * doDigitalRead() wrapper routines.
 */
#define B_CS  (255)
#define C_CS  (52)
#define D_CS  (78)

#define LEDA  (38)
#define LEDB  (37)
#define LEDC  (39)
#define LEDD  (40)


/* There is #define PWM in sam3x8e.h that would prevent us using PWM as
 * field in the SlotInfo structure.
 */
#undef PWM

typedef struct Slot_s
{
    uint32_t LED;
    HardwareSerial* uart;
    uint8_t AN;
    uint8_t RST;
    uint8_t CS;
    uint8_t PWM;
    uint8_t INT;
} SlotInfo;

static const SlotInfo slots[4] =
{
    { LEDA, &Serial1, A_AN, A_RST, A_CS, A_PWM, A_INT },
    { LEDB, &Serial2, B_AN, B_RST, B_CS, B_PWM, B_INT },
    { LEDC, &Serial3, C_AN, C_RST, C_CS, C_PWM, C_INT },
    /* Slots C and D share Serial3 */
    { LEDD, &Serial3, D_AN, D_RST, D_CS, D_PWM, D_INT }
};


/* The askMillis variable is a timer for periodically issuing the prompt */
static uint32_t askMillis;

/*
 * Wrapper the Arduino pinMode() api to handle the B_CS with special
 * case code. The ArduinoDue does not support PA29 as a general IO pin.
 *
 * @param ulPin The number of the pin whose mode you wish to set
 * @param ulMode The mode e.g. INPUT, INPUT_PULLUP or OUTPUT
 */
static void doPinMode( uint32_t ulPin, uint32_t ulMode )
{
    if (ulPin == B_CS)
    {
        PIO_Configure(PIOA, PIO_OUTPUT_0, PIO_PA29, PIO_DEFAULT);
    }
    else
    {
        pinMode(ulPin, ulMode);
    }
}

/*
 * Wrapper the Arduino digitalWrite() api to handle the B_CS with special
 * case code. The ArduinoDue does not support PA29 as a general IO pin.
 *
 * @param ulPin The number of the pin
 * @param ulVal The data to write, HIGH or LOW
 */
static void doDigitalWrite( uint32_t ulPin, uint32_t ulVal )
{
    if (ulPin == B_CS)
    {
        PIO_SetOutput(PIOA, PIO_PA29, ulVal, 0, PIO_PULLUP ) ;
    }
    else
    {
        digitalWrite(ulPin, ulVal);
    }
}

/*
 * Wrapper the Arduino digitalRead() api to handle the B_CS with special
 * case code. The ArduinoDue does not support PA29 as a general IO pin.
 *
 * @param ulPin The number of the pin
 * @return the data value HIGH or LOW
 */
static int doDigitalRead( uint32_t ulPin )
{
    if (ulPin == B_CS)
    {
        if (PIO_Get(PIOA, PIO_INPUT, PIO_PA29) == 1)
        {
            return HIGH;
        }
        else
        {
            return LOW;
        }
    }
    else
    {
        return digitalRead(ulPin);
    }
}

enum ModemAction_e
{
    MODEM_INIT_PINS,
    MODEM_ENABLE,
    MODEM_DISABLE,
    MODEM_RESET
};

/**
 * Pulse the given pin, in the given direction, for the given duration.
 *
 * @param pin the pin to pulse
 * @param firstEdge the desired level of the pulse after the first edge
 * @param width the width of the pulse in milliseconds
 */
static void pulsePin(uint32_t pin, uint32_t firstEdge, uint32_t width)
{
    doDigitalWrite(pin, firstEdge);
    delay(width);
    doDigitalWrite(pin, firstEdge == HIGH ? LOW: HIGH);
}


/**
 * A helper routine to turn on a modem click while using the cts pin to
 * detect if/when the modem is on.
 * The cts pin must have been configured in INPUT_PULLUP mode and will
 * be driven low when the modem is powered.
 *
 * Provide debug output using the given modem name.
 *
 * @param cts the cts to check
 * @param pwr the pwr to pulse
 * @param firstEdge the desired level of the pulse after the first edge
 * @param width the width of the pulse in milliseconds
 * @param wait minimum time to wait for the modem to be ready after pulse,
 *             in milliseconds
 * @param name the name of the modem for debug.
 * @return true if the modem is on (cts is low)
 */
static boolean modemOnCheckCtsPulsePwr(uint32_t cts, uint32_t pwr, uint32_t firstEdge, uint32_t width, int32_t wait, const char* name)
{
    if (doDigitalRead(cts) == LOW)
    {
        /* If already low then the modem must already be powered */
        DEBUG_SERIAL.print(name);
        DEBUG_SERIAL.println(" already powered on");
    }
    else
    {
        pulsePin(pwr, firstEdge, width);

        /* Wait for the modem to pull down the CTS pin */
        int count = 0;
        while (doDigitalRead(cts) == HIGH)
        {
            if (count > 30)
            {
                DEBUG_SERIAL.print(name);
                DEBUG_SERIAL.println(" did not turn on");
                return false;
            }
            delay(1000);
            count++;
        }
        DEBUG_SERIAL.print(name);
        DEBUG_SERIAL.print(" turned on after ");
        DEBUG_SERIAL.print(count);
        DEBUG_SERIAL.print(" seconds\n");

        /* Wait any remaining time for the modem to be ready. */
        int remaining_wait_time = wait - 1000*count;
        if (remaining_wait_time > 0)
            delay(remaining_wait_time);
    }

    return true;
}

/**
 * A helper routine to turn off a modem click while using the cts pin to
 * detect when the modem is off.
 * The cts pin must have been configured in INPUT_PULLUP mode.
 *
 * Pulse the pwr pin for the given duration and then check the cts
 * pin floats high.
 *
 * Provide debug output using the given modem name.
 *
 * @param cts the cts to check
 * @param pwr the pwr to pulse
 * @param firstEdge the desired level of the pulse after the first edge
 * @param width the width of the pulse in milliseconds
 * @param name the name of the modem for debug.
 * @return true if the modem is off (cts is high)
 */
static boolean modemOffCheckCtsPulsePwr(uint32_t cts, uint32_t pwr, uint32_t firstEdge, uint32_t width, const char* name)
{
    if (doDigitalRead(cts) == HIGH)
    {
        /* If already high then the modem must already be powered off */
        DEBUG_SERIAL.print(name);
        DEBUG_SERIAL.println(" already powered off");
    }
    else
    {
        pulsePin(pwr, firstEdge, width);

        /* Wait for the modem to let the CTS float high */
        int count = 0;
        while (doDigitalRead(cts) == LOW)
        {
            if (count > 30)
            {
                DEBUG_SERIAL.print(name);
                DEBUG_SERIAL.println(" did not turn off");
                return false;
            }
            delay(1000);
            count++;
        }
        DEBUG_SERIAL.print(name);
        DEBUG_SERIAL.print(" turned off after ");
        DEBUG_SERIAL.print(count);
        DEBUG_SERIAL.print(" seconds\n");
    }
    return true;
}

/**
 * Perform some action for the modem in the given slot.
 *
 * @param action the required action
 * @param modemClick a pointer to the details for the selected modem
 * @param slot the index (0..3) of the mikroBUS slot A..D
 * @return true if action performed
 */
static bool modemAction(ModemAction_e action, ModemClickDetails *modemClick, int slot)
{
    turnSlotLedOnOff(slot, (action == MODEM_INIT_PINS) || (action == MODEM_ENABLE));

    const SlotInfo *slotP = &slots[slot];
    switch (modemClick->click.name)
    {
    case Mikroe_GSM_GNSS_2_Click: // GSM/GNSS 2 click with SIM868
    {
        uint32_t det = slotP->AN;  // SIM detect
        uint32_t pwr = slotP->RST;
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(det, INPUT);
            doPinMode(ri, INPUT);

            /* Use CTS with a MCU pullup to detect that the modem is powered */
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The SIM868 datasheet states that the PWRKEY pin should be pulsed
             * low for at least 1000ms to turn on the module.
             * We use the modem's CTS to detect if the modem is already powered.
             */
            return modemOnCheckCtsPulsePwr(cts, pwr, HIGH, 1100, 0, modemClick->modem.name);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The SIM868 datasheet states that the PWRKEY pin should be pulsed
             * low for more than 1000ms (but less than 33s) to turn off the
             * module.
             */
            return modemOffCheckCtsPulsePwr(cts, pwr, HIGH, 1100, modemClick->modem.name);
        }
        else if (action == MODEM_RESET)
        {
            /* The SIM868 does not have an explicit reset pin */
            bool disabled = modemAction(MODEM_DISABLE, modemClick, slot);
            bool enabled = modemAction(MODEM_ENABLE, modemClick, slot);
            return (disabled && enabled);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_3G_EU_Aus_Click: /* 3G click (EU+Aus)        with Quectel UG95EA */
    case Mikroe_3G_USA_Click:    /* 3G click (USA)           with Quectel UG95AA */
    {
        /* These modems use a pulse on PWRKEY to turn on or turn off the modem.
         * Recommened practice is to monitor the STATUS pin to decide if a
         * PWRKEY pulse is required. However the 3G click does not have a
         * pull-down on the STATUS pin nor does the SAMX3 support pull-down
         * on input pins so we are not able to use STATUS to determine if the
         * module is already powered on. Instead we use CTS with a MCU pull-up.
         */
        uint32_t pwr = slotP->RST;
        uint32_t sta = slotP->AN;
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(sta, INPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(ri, INPUT);
            /* Detecting modem powered on via STAT is not possible since this
             * pin floats high when the modem is not powered and the SAMX3 does
             * not provide a configurable pull-down. Use CTS instead.
             */
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The Quectel UG95 hardware design guide states:
             *    When UG95 is in power off mode, it can be turned on to normal
             *    mode by driving the PWRKEY pin to a low level for at least
             *    100ms.
             * We use the modem's CTS to detect if the modem is already powered.
             */
            return modemOnCheckCtsPulsePwr(cts, pwr, HIGH, 110, 0, modemClick->modem.name);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The Quectel UG95 uses the PWRDWN_N pin to turn off the module.
             * The "3G click" does not route this pin to any mikroBUS pin.
             * The AT+QPOWD=1 can be used to turn off the modem.
             */
            if (doDigitalRead(cts) == LOW)
            {
                slotSerial->println("AT+QPOWD=1\r");
                for (int idx = 0; idx < 5000/50; idx++)
                {
                    if (doDigitalRead(cts) == HIGH)
                    {
                        break;
                    }
                    delay(50);
                }
            }
        }
        else if (action == MODEM_RESET)
        {
            /* These Quectel modems do not have an explicit reset pin */
            bool disabled = modemAction(MODEM_DISABLE, modemClick, slot);
            bool enabled = modemAction(MODEM_ENABLE, modemClick, slot);
            return (disabled && enabled);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_LTE_IoT_2_Click: /* LTE IoT 2 click          with Quectel BG96 */
    {
        /* These modems use a pulse on PWRKEY to turn on or turn off the modem.
         * Recommened practice is to monitor the STATUS pin to decide if a
         * PWRKEY pulse is required. However this click does not have a
         * pull-down on the STATUS pin nor does the SAMX3 support pull-down
         * on input pins so we are not able to use STATUS to determine if the
         * module is already powered on. Instead we use CTS with a MCU pull-up.
         */
        uint32_t pwr = slotP->RST;
        uint32_t sta = slotP->AN;
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(sta, INPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(ri, INPUT);

            /* Detecting modem powered on via STAT is not possible since this
             * pin floats high when the modem is not powered and the SAMX3 does
             * not provide a configurable pull-down. Use CTS instead.
             */
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The Quectel BG96 hardware design guide states:
             *    When BG96 is in power off mode, it can be turned on to normal
             *    mode by driving the PWRKEY pin to a low level for at least
             *    500ms.
             * We use the modem's CTS to detect if the modem is already powered.
             */
            return modemOnCheckCtsPulsePwr(cts, pwr, HIGH, 510, 0, modemClick->modem.name);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The Quectel BG96 hardware design guide states:
             *    Driving the PWRKEY pin to a low level voltage for at least
             *    650ms, the module will execute power-down procedure after
             *    the PWRKEY is released.
             * We use the modem's CTS to detect if the modem is already powered off.
             */
            return modemOffCheckCtsPulsePwr(cts, pwr, HIGH, 700, modemClick->modem.name);
        }
        else if (action == MODEM_RESET)
        {
            /* These Quectel modems do not have an explicit reset pin */
            bool disabled = modemAction(MODEM_DISABLE, modemClick, slot);
            bool enabled = modemAction(MODEM_ENABLE, modemClick, slot);
            return (disabled && enabled);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_LTE_Cat_1_3_EU_Click: /* LTE Cat.1 3 for EU with Quectel EG91 */
    {
        /* These modems use a pulse on PWRKEY to turn on or turn off the modem.
         * Recommened practice is to monitor the STATUS pin to decide if a
         * PWRKEY pulse is required. However this click's STATUS pin is not
         * mapped to the Mikro BUS. Instead we use CTS with a MCU pull-up.
         */
        uint32_t pwr = slotP->AN;
        uint32_t rst = slotP->RST;
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;

        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rts, LOW);
            doDigitalWrite(rst, HIGH);
            doPinMode(pwr, OUTPUT);
            doPinMode(rst, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(ri, INPUT);

            /* Detecting modem powered on via STAT is not possible since this
             * pin floats high when the modem is not powered and the SAMX3 does
             * not provide a configurable pull-down. Use CTS instead.
             */
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The Quectel EG91 hardware design guide states:
             *    When EG91 is in power off mode, it can be turned on to normal
             *    mode by driving the PWRKEY pin to a low level for at least
             *    500ms.
             * We use the modem's CTS to detect if the modem is already powered.
             * CTS indicates the modem is on, but not necessarily ready.
             * Add an extra delay after the powering on to allow the modem
             * to start.
             */
            return modemOnCheckCtsPulsePwr(cts, pwr, HIGH, 510, 5000, modemClick->modem.name);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The Quectel EG91 hardware design guide states:
             *    Driving the PWRKEY pin to a low level voltage for at least
             *    650ms, the module will execute power-down procedure after
             *    the PWRKEY is released.
             * We use the modem's CTS to detect if the modem is already powered off.
             */
            return modemOffCheckCtsPulsePwr(cts, pwr, HIGH, 700, modemClick->modem.name);
        }
        else if (action == MODEM_RESET)
        {
            /* The Quectel EG91 hardware design guide states that the RESET_N pin
             * should be held low for between for 150ms~460ms to force a module reset.
             */
            pulsePin(rst, LOW, 300);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_LTE_IoT_Click: /* LTE IoT click            with u-blox SARA-R410M */
    {
        uint32_t pwr = slotP->AN;
        uint32_t rst = slotP->RST;
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, HIGH);
            doDigitalWrite(rst, HIGH);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(rst, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(ri, INPUT);

            /* We use CTS to detect that the modem has powered up since
             * this is an active low signal and the SAM3X only has input
             * pull-ups.
             */
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The u-blox SARA-R410M datasheet states that the PWR_ON key
             * should be pulsed low for at least 150ms to turn on the module.
             * We use the modem's CTS to detect if the modem is already powered.
             */
            return modemOnCheckCtsPulsePwr(cts, pwr, LOW, 165, 0, modemClick->modem.name);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The u-blox SARA-R410M datasheet states that the PWR_ON pin
             * should be pulsed low for at least 1500ms to turn off the module.
             */
            pulsePin(pwr, LOW, 1600);
        }
        else if (action == MODEM_RESET)
        {
            /* The u-blox SARA-R410M datasheet states that the RESET_N pin
             * should be held low for at least 10s to force a module reset.
             */
            pulsePin(rst, LOW, 11000);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_LTE_IoT_6_Click: /* LTE IoT 6 click          with u-blox SARA-R412M */
    case Mikroe_LTE_IoT_7_Click: /* LTE IoT 7 click          with u-blox SARA-R422M8S */
    {
        uint32_t pwr = slotP->AN;
        uint32_t rst = slotP->RST;
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rst, LOW);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(rst, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(ri, INPUT);

            /* We use CTS to detect that the modem has powered up since
             * this is an active low signal and the SAM3X only has input
             * pull-ups.
             */
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The u-blox SARA-R412M datasheet states that the PWR_ON key
             * should be pulsed low for at least 150ms to turn on the module.
             * We use the modem's CTS to detect if the modem is already powered.
             */
            return modemOnCheckCtsPulsePwr(cts, pwr, HIGH, 165, 0, modemClick->modem.name);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The u-blox SARA-R412M datasheet states that the PWR_ON pin
             * should be pulsed low for at least 1500ms to turn off the module.
             */
            pulsePin(pwr, HIGH, 1600);
        }
        else if (action == MODEM_RESET)
        {
            /* The u-blox SARA-R412M datasheet states that the RESET_N pin
             * should be held low for at least 10s to force a module reset.
             */
            pulsePin(rst, HIGH, 11000);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_LTE_IoT_3_Click: /* LTE IoT 3 click  with Cinterion EXS82-W */
    case Mikroe_LTE_IoT_9_Click: /* LTE IoT 9 click  with Cinterion EXS62-W */
    {
        uint32_t smi = slotP->AN;  // Suspend Monitor
        uint32_t pwr = slotP->RST;
        uint32_t cts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t rts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(smi, INPUT);
            doPinMode(ri, INPUT);
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The Cinterion EXS62-W/EXS82-W hardware interface manual
             * recommends that the ON pin is pulsed upwards (only rising edge
             * significant) for at least 1ms. After ~22ms the interfaces are
             * powered.
             */
            pulsePin(pwr, HIGH, 50);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The "LTE IoT 3 click" and "LTE IoT 9 click" click boards
             * do not route the hardware shutdown pin FST_SHDN) so we use
             * software instead.
             */
            slotSerial->println("AT^SMSO\r");
            delay(500);
        }
        else if (action == MODEM_RESET)
        {
            /* The "LTE IoT 3 click" and "LTE IoT 9 click" click boards do not
             * provide access to the hardware emergency reset pin.
             */
            bool disabled = modemAction(MODEM_DISABLE, modemClick, slot);
            bool enabled = modemAction(MODEM_ENABLE, modemClick, slot);
            return (disabled && enabled);
        }
        else
        {
            return false;
        }
        break;
    }


    case Mikroe_GSM_GNSS_Click: /* GSM/GNSS click           with Quectel MC60 */
    {
        uint32_t det = slotP->AN;  // SIM detect
        uint32_t pwr = slotP->RST;
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(det, INPUT);
            doPinMode(ri, INPUT);
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The Quectel MC60 Hardware Design manual recommends a power on
             * low pulse pulse of width > 1.0s to turn on the module.
             * The PWRKEY of the MC60 is available at the mikroBUS RST pin but
             * the level is inverted.
             * We use the modem's CTS to detect if the modem is already powered.
             */
            return modemOnCheckCtsPulsePwr(cts, pwr, HIGH, 1100, 0, modemClick->modem.name);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The Quectel MC60 Hardware Design manual recommends a power off
             * low pulse width of between 0.7s and 1.0s to turn off the module.
             */
            pulsePin(pwr, HIGH, 770);
        }
        else if (action == MODEM_RESET)
        {
            /* The Quectel MC60 does not have an explicit reset pin */
            bool disabled = modemAction(MODEM_DISABLE, modemClick, slot);
            bool enabled = modemAction(MODEM_ENABLE, modemClick, slot);
            return (disabled && enabled);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_LTE_IoT_5_Click: /* LTE IoT 5 click          with u-blox SARA-R510M8S */
    {
        uint32_t pwr = slotP->AN;  // PWR (High pulse to "push" PWR_ON low)
        uint32_t rst = slotP->RST; // RESET
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rst, LOW);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(rst, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(ri, INPUT);
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The SARA-R510M8S data sheet specifies a low pulse of width
             * greater than 0.1s and less than 2s to turn on the module.
             * Other SARA-R5xx modems specify 1.0s as the minimum, so we
             * will use the larger (in case Mikroe change the modem in future).
             * The Click board inverts the AN pin in order to create the active
             * low PWR_ON signal.
             */
            pulsePin(pwr, HIGH, 1100);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The SARA-R510M8S does not provide a pin to power off */
            slotSerial->println("AT+CPWROFF\r");
        }
        else if (action == MODEM_RESET)
        {
            pulsePin(rst, HIGH, 120);
            return (true);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_LTE_Cat_4_3_Click: /* LTE Cat.4 3 click    with u-blox LARA-R6004D */
    {
        uint32_t stat = slotP->AN; // GPIO2 (traced as STAT on click board)
        uint32_t pwr = slotP->RST; // PWR_ON (traced as PWRKEY on click board)
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(stat, INPUT);
            doPinMode(ri, INPUT);

            /* Use CTS with a MCU pullup to detect that the modem is powered */
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The LARA-R6004D data sheet specifies a low pulse of width
             * greater than 0.15s and less than 3.2s to turn on the module.
             * The Click board inverts the RST pin in order to create the active
             * low PWR_ON signal.
             */
            return modemOnCheckCtsPulsePwr(cts, pwr, HIGH, 250, 0, modemClick->modem.name);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The LARA-R6004D data sheet specifies a low pulse of width
             * greater than 1.5s to turn off the module.
             * The Click board inverts the RST pin in order to create the active
             * low PWR_ON signal.
             */
            return modemOffCheckCtsPulsePwr(cts, pwr, HIGH, 1600, modemClick->modem.name);
        }
        else if (action == MODEM_RESET)
        {
            /* There is no reset pin */
            return (true);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_4G_LTE_GNSS_Click:  /* 4G LTE&GNSS click with u-blox LENA-R8001 */
    {
        uint32_t pwr = slotP->AN;  // PWR (High pulse to "push" PWR_ON low)
        uint32_t sel = slotP->RST; // Select ->CS action. 0: EEP-I/O 1:RTS
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rts, LOW);
            doDigitalWrite(sel, HIGH);  // Select RTS on CS pin.
            doPinMode(pwr, OUTPUT);
            doPinMode(sel, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(ri, INPUT);
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The LENA-R8001 data sheet specifies a low pulse of width
             * greater than 2s and less than 3.1s to turn on the module.
             * The Click board inverts the AN pin in order to create the active
             * low PWR_ON signal.
             */
            pulsePin(pwr, HIGH, 2100);
        }
        else if (action == MODEM_DISABLE)
        {
            /* The LENA-R8001 data sheet specifies a low pulse of width
             * greater 3.1s to turn off the module.
             */
            pulsePin(pwr, HIGH, 3500);
        }
        else if (action == MODEM_RESET)
        {
            /* There is no RESET pin connection on this click */
            return (true);
        }
        else
        {
            return false;
        }
        break;
    }

    case Mikroe_4G_LTE_EU_Click:      /* 4G LTE click (EU)        with u-blox LARA-R211 */
    case Mikroe_4G_LTE_USA_Click:     /* 4G LTE click (USA)       with u-blox LARA-R204 */
    case Mikroe_4G_LTE_USA_ATT_Click: /* 4G LTE click (USA-AT&T)  with u-blox LARA-R202 */
    case Mikroe_4G_LTE_Japan_Click:   /* 4G LTE click (Japan)     with u-blox LARA-R280 */
    {
        uint32_t sta = slotP->AN;
        uint32_t pwr = slotP->RST;
        uint32_t rts = slotP->CS;
        uint32_t ri  = slotP->PWM;
        uint32_t cts = slotP->INT;
        if (action == MODEM_INIT_PINS)
        {
            doDigitalWrite(pwr, LOW);
            doDigitalWrite(rts, LOW);
            doPinMode(pwr, OUTPUT);
            doPinMode(rts, OUTPUT);
            doPinMode(ri, INPUT);
            doPinMode(sta, INPUT);

            /* Use CTS with a MCU pullup to detect that the modem is powered */
            doPinMode(cts, INPUT_PULLUP);
        }
        else if (action == MODEM_ENABLE)
        {
            /* The u-blox LARA-R2xx datasheet states that the PWR_ON pin
             * should be pulsed low for at least 50us to turn off the module.
             * Note that the click inverts the signal.
             * We use the modem's CTS to detect if the modem is already powered.
             */
            if (!modemOnCheckCtsPulsePwr(cts, pwr, HIGH, 2, 0, modemClick->modem.name))
            {
                return false;
            }
            slotSerial->println("AT+UMNOPROF=90\r");
        }
        else if (action == MODEM_DISABLE)
        {
            /* The u-blox LARA-R2xx datasheet states that the PWR_ON pin
             * should be pulsed low for at least 1000ms to turn off the module.
             * Note that the click inverts the signal.
             */
            pulsePin(pwr, HIGH, 1100);
        }
        else if (action == MODEM_RESET)
        {
            /* These modems do not have an explicit reset pin */
            bool disabled = modemAction(MODEM_DISABLE, modemClick, slot);
            bool enabled = modemAction(MODEM_ENABLE, modemClick, slot);
            return (disabled && enabled);
        }
        else
        {
            return false;
        }
        break;
    }

    default:
        return false;

    } /* end switch() */
    return true;
}

/**
 * Initialize the pins of the modem in the given slot.
 *
 * @param modemClick a pointer to the details for the selected modem
 * @param slot the index (0..3) of the mikroBUS slot A..D
 * @return true if the slot has been initialized
 */
static bool modemInitPins(ModemClickDetails *modemClick, int slot)
{
    return modemAction(MODEM_INIT_PINS, modemClick, slot);
}

/**
 * Turn on the modem in the given slot.
 *
 * @param modemClickIdx the index into the modems[] table
 * @param slot the index (0..3) of the mikroBUS slot A..D
 * @return true if the modem in the slot has been enabled
 */
bool modemEnable(int modemClickIdx, int slot)
{
    ModemClickDetails *modemClick = &modems[modemClickIdx];
    return modemAction(MODEM_ENABLE, modemClick, slot);
}

/**
 * Turn off the modem in the given slot.
 *
 * @param modemClickIdx the index into the modems[] table
 * @param slot the index (0..3) of the mikroBUS slot A..D
 * @return true if the modem in the slot has been disabled
 */
bool modemDisable(int modemClickIdx, int slot)
{
    ModemClickDetails *modemClick = &modems[modemClickIdx];
    return modemAction(MODEM_DISABLE, modemClick, slot);
}

/**
 * Reset the modem in the given slot.
 *
 * @param modemClickIdx the index into the modems[] table
 * @param slot the index (0..3) of the mikroBUS slot A..D
 * @return true if the modem in the slot has been reset
 */
bool modemReset(int modemClickIdx, int slot)
{
    ModemClickDetails *modemClick = &modems[modemClickIdx];
    return modemAction(MODEM_RESET, modemClick, slot);
}

/**
 * Reject all available input and report that the given character
 * was not in the expected range (but ignore if all was white space).
 *
 *
 * @param ch the out of range character
 * @param invalid the category of item that is invalid
 * @param min the minumum valid character
 * @param max the maximum valid character
 */
static void rejectAllAvailableInput(char ch, const char* invalid, char min, char max)
{
    /* Ignore white space */
    if ((ch == '\r') || (ch == '\n') || (ch == ' '))
    {
        return;  /* Silently return */
    }

    DEBUG_SERIAL.println("");
    DEBUG_SERIAL.print("Invalid ");
    DEBUG_SERIAL.print(invalid);
    DEBUG_SERIAL.print(" selection '");
    if ((ch >= ' ') && (ch < '~'))
    {
        DEBUG_SERIAL.print(ch);
    }
    else
    {
        DEBUG_SERIAL.print("\\x");
        if ((int)ch < 16)
        {
            DEBUG_SERIAL.print("0");
        }
        DEBUG_SERIAL.println((int)ch, HEX);
    }

    /* Discard the rest of the available input. */
    while (true)
    {
        if (DEBUG_SERIAL.available())
        {
            ch = DEBUG_SERIAL.read();
        }
        else
        {
            /* If no more characters are available, delay a small amount
             * in case the MCU is running faster than the serial line.
             */
            delay(250);
            if (!DEBUG_SERIAL.available())
            {
                break;
            }
        }
    }
    DEBUG_SERIAL.println("'");
    DEBUG_SERIAL.print("Please reply '");
    DEBUG_SERIAL.print(min);
    DEBUG_SERIAL.print("' ... '");
    DEBUG_SERIAL.print(max);
    DEBUG_SERIAL.print("' ?");
    askMillis = millis() + 5000;
}


void askWhichClick(void)
{
    if (modemClickIdx == MODEM_CLICK_MENU)
    {
        DEBUG_SERIAL.println();
        DEBUG_SERIAL.println("    Click Name                Modem Hardware        Mikroe part #");
        DEBUG_SERIAL.println("-+--------------------------+----------------------+--------------");
        ModemClickDetails *modemClick = modems;
        while (modemClick < &modems[NUM_MODEMS])
        {
            DEBUG_SERIAL.print((char)('a' + (modemClick - modems)));
            DEBUG_SERIAL.print(": \"");
            const char* clickName = modemClick->click.nameString;
            DEBUG_SERIAL.print(clickName);
            DEBUG_SERIAL.print(" click\"");
            int nameLen = strlen(clickName);
            const char* area = modemClick->click.areaString;
            if ((area != NULL) && (*area != '\0'))
            {
                DEBUG_SERIAL.print(" ");
                DEBUG_SERIAL.print(area);
                nameLen += (1 + strlen(area));
            }
            const char* clickNamePadding = "                 ";
            if (nameLen < (int)strlen(clickNamePadding))
            {
                DEBUG_SERIAL.print(clickNamePadding + nameLen);
            }
            DEBUG_SERIAL.print(" \"");
            DEBUG_SERIAL.print(modemClick->modem.name);
            DEBUG_SERIAL.print("\" ");
            const char* modemNamePadding = "                     ";
            nameLen = strlen(modemClick->modem.name);
            if (nameLen < (int)strlen(modemNamePadding))
            {
                DEBUG_SERIAL.print(modemNamePadding + nameLen);
            }
            DEBUG_SERIAL.print("MIKROE-");
            DEBUG_SERIAL.println(modemClick->click.name);
            modemClick++;
        }
        DEBUG_SERIAL.println();
        askMillis = millis();
    }
    if (millis() >= askMillis)
    {
        if (--modemClickIdx == -6)
        {
            modemClickIdx = -1;  /* Reprint the options next time */
        }
        askMillis = millis() + 30000;
        DEBUG_SERIAL.print("\nWhich Mikroe Click modem from the list above are you using ('a' to '");
        DEBUG_SERIAL.print(LAST_MODEM_CHAR('a'));
        DEBUG_SERIAL.print("') ?");
    }
    if (DEBUG_SERIAL.available())
    {
        int ch = DEBUG_SERIAL.read();
        if ((ch >= 'A') && (ch <= LAST_MODEM_CHAR('A')))
        {
            modemClickIdx = ch - 'A';
        }
        else if ((ch >= 'a') && (ch <= LAST_MODEM_CHAR('a')))
        {
            modemClickIdx = ch - 'a';
        }
        else
        {
            rejectAllAvailableInput(ch, "Click", 'a', LAST_MODEM_CHAR('a'));
            return;
        }
        DEBUG_SERIAL.print("\nSelected \"");
        DEBUG_SERIAL.print(modems[modemClickIdx].click.nameString);
        DEBUG_SERIAL.print(" click \" which uses \"");
        DEBUG_SERIAL.print(modems[modemClickIdx].modem.name);
        DEBUG_SERIAL.println("\" modem hardware");
        askMillis = millis();
    }
}

void askWhichSlot(void)
{
    if (askMillis < millis())
    {
        DEBUG_SERIAL.print("\nIn which mikroBUS socket ('A' to 'D') is modem Click inserted ?");
        askMillis = millis() + 10000;
    }
    if (DEBUG_SERIAL.available())
    {
        char ch = DEBUG_SERIAL.read();
        if ((ch >= 'a') && (ch <= 'd'))
        {
            mikroBusSlot = (ch - 'a');
            DEBUG_SERIAL.print("\nSelected slot ");
            DEBUG_SERIAL.println((char)(mikroBusSlot + 'A'));
        }
        else if ((ch >= 'A') && (ch <= 'D'))
        {
            mikroBusSlot = (ch - 'A');
            DEBUG_SERIAL.print("\nSelected slot ");
            DEBUG_SERIAL.println((char)(mikroBusSlot + 'A'));
        }
        else
        {
            rejectAllAvailableInput(ch, "slot", 'A', 'D');
            return;
        }
    }
}


void askIfUssd(void)
{
    if (askMillis < millis())
    {
        DEBUG_SERIAL.print("\nUSSD rather than UDP?");
        askMillis = millis() + 10000;
    }
    if (DEBUG_SERIAL.available())
    {
        char ch = DEBUG_SERIAL.read();
        if ((ch == 'y') || (ch == 'Y'))
        {
            modemUssd = 1;
        }
        else if ((ch == 'n') || (ch == 'N'))
        {
            modemUssd = 0;
        }
        else
        {
            // Prompt again immediately, if unknown response.
            askMillis = millis();
        }
    }
}

/**
 * Configure the requested modem Click.
 *
 * @param modemIdx the index into the modems[] table
 * @param slot the index (0..3) of the mikroBUS slot A..D
 * @param pInit the address of a variable to receive the modem
 *        init configuration.
 * @return the HardwareSerial instance to talk to the modem (or NULL)
 */
HardwareSerial* configureClick(int modemIdx, int slot, ThingstreamModemUdpInit **pInit)
{
    static bool notifiedSlotInit = false;
    if (!modemInitPins(&modems[modemIdx], slot))
    {
        DEBUG_SERIAL.print("\nNo initialisation code for MIKROE-");
        DEBUG_SERIAL.print(modems[modemIdx].click.name);
        DEBUG_SERIAL.print(" in slot ");
        DEBUG_SERIAL.println((char)(slot + 'A'));
        delay(2000);
        modemClickIdx = MODEM_CLICK_MENU;
        mikroBusSlot = MIKROBUS_SLOT_MENU;
        notifiedSlotInit = false;
        return NULL;
    }
    if (!notifiedSlotInit)
    {
        DEBUG_SERIAL.print("\nInitialized \"");
        DEBUG_SERIAL.print(modems[modemIdx].click.nameString);
        DEBUG_SERIAL.print(" click\" which uses \"");
        DEBUG_SERIAL.print(modems[modemIdx].modem.name);
        DEBUG_SERIAL.print("\" modem hardware in slot ");
        DEBUG_SERIAL.println((char)(slot + 'A'));
        notifiedSlotInit = true;
    }

    *pInit = modems[modemIdx].modem.init;
    return slots[slot].uart;
}


/**
 * Turn on/off the led for the currently selected slot.
 *
 * @param slot the index of the slot (0..3 are valid)
 * @param onOff if true then turn on led
 */
void turnSlotLedOnOff(int slot, bool onOff)
{
    if ((slot >= 0) && (slot < 4))
    {
        const SlotInfo *slotP = &slots[slot];
        uint32_t led = slotP->LED;
        doPinMode(led, OUTPUT);
        doDigitalWrite(led, onOff ? HIGH: LOW);
    }
}
