/*
 * Copyright 2022-2025 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @file
 * @brief Click selection interface for the examples running on FlipAndClick board.
 */


#ifndef INC_CLICK_SELECT_H_
#define INC_CLICK_SELECT_H_

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

#define MIKROBUS_SLOT_A       (0)
#define MIKROBUS_SLOT_B       (1)
#define MIKROBUS_SLOT_C       (2)
#define MIKROBUS_SLOT_D       (3)
#define MIKROBUS_SLOT_MENU    (-1)

#define MODEM_CLICK_MENU      (-1)


/**
 * The names of the modem Click boards (with punctuation replaced by underscore)
 * The numeric values in the define are the MIKROE-<number> PID: values from
 * the mikroe.com product web pages.
 *
 * Note that not all the boards listed here are supported.
 * See click_select.cpp for details.
 */
#define Mikroe_LTE_IoT_5_Click               4325
#define Mikroe_LTE_IoT_7_Click               5290
#define Mikroe_LTE_IoT_Click                 3072
#define Mikroe_4G_LTE_EU_Click               2527
#define Mikroe_3G_EU_Aus_Click               2226
#define Mikroe_3G_USA_Click                  2296
#define Mikroe_GSM_GNSS_Click                2439
#define Mikroe_LTE_IoT_2_Click               3144
#define Mikroe_LTE_IoT_3_Click               4118
#define Mikroe_GSM_GNSS_2_Click              2440
#define Mikroe_LTE_IoT_6_Click               4388
#define Mikroe_4G_LTE_USA_Click              2535
#define Mikroe_4G_LTE_USA_ATT_Click          3350
#define Mikroe_4G_LTE_Japan_Click            3351
#define Mikroe_LTE_IoT_9_Click               4465
#define Mikroe_LTE_Cat_4_3_Click             5991
#define Mikroe_4G_LTE_GNSS_Click             5890
#define Mikroe_LTE_Cat_1_3_EU_Click          6152

/**
 * Find the modem click in the modems[] table by name.
 *
 * @param clickName the name (defined above) of the modem click board.
 * @return the index in the modems[] table or -1 if it could not be found.
 */
extern int findClickByName(uint32_t clickName);

/**
 * Ask which mikroBus slot is being used ('A', 'B', 'C', or 'D').
 *
 * Set modemSlotIdx with a value 0..3 to indicate the slot.
 */
extern void askWhichSlot(void);


/**
 * Ask if USSD should be used (rather than the default UDP).
 *
 * Set modemUssd = 1 for use USSD, = 0 to use UDP
 */
extern void askIfUssd(void);


extern int mikroBusSlot;
extern int modemClickIdx;
extern int modemUssd;

/* A pointer to the Arduino serial  instance that communicates
 * with the modem on the selected Click slot.
 */
extern HardwareSerial* slotSerial;

/**
 * Print a menu of choices on the console and ask which Click
 * modem is being used.
 *
 * Set modemClickIdx with the index of the chosen Click in the
 * modems[] table in click_select.cpp
 */
extern void askWhichClick(void);


/**
 * Return the Mikroe_xxx_Click name from within the modems[] table.
 *
 * @param clickIdx the index into the table of modem Clicks
 * @return the name (one of the Mikroe_xxx_Click defines above)
 *         of the modem click board, or zero if not found.
 */
extern uint32_t getClickNameFromIdx(int clickIdx);

/**
 * Turn on the modem in the given slot.
 *
 * @param modemIdx the index into the modems[] table
 * @param slot the index (0..3) of the mikroBUS slot A..D
 * @return true if the modem in the slot has been enabled
 */
extern bool modemEnable(int modemIdx, int slot);

/**
 * Turn off the modem in the given slot.
 *
 * @param modemIdx the index into the modems[] table
 * @param slot the index (0..3) of the mikroBUS slot A..D
 * @return true if the modem in the slot has been disabled
 */
extern bool modemDisable(int modemIdx, int slot);


/**
 * Configure the requested modem Click.
 *
 * @param modemIdx the index into the modems[] table
 * @param slot the index (0..3) of the mikroBUS slot A..D
 * @param pInit the address of a variable to receive the modem
 *        init configuration.
 * @return the HardwareSerial instance to talk to the modem (or NULL)
 */
extern HardwareSerial* configureClick(int modemIdx, int slot, ThingstreamModemUdpInit **pInit);


/**
 * Turn on/off the led for the currently selected slot.
 *
 * @param slot the index of the slot (0..3 are valid)
 * @param onOff if true then turn on led
 */
void turnSlotLedOnOff(int slot, bool onOff);


#if defined(__cplusplus)
}
#endif

#endif /* INC_CLICK_SELECT_H_ */
