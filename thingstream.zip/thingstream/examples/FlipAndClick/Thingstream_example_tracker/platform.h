/*
 * Copyright 2017-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef INC_PLATFORM_H_
#define INC_PLATFORM_H_

#include <stdint.h>
#include <stdbool.h>

/* For Thingstream_Util_printf(), and to setup conditional compilation */
#include "flags.h"
#include "thingstream.h"

#if defined(__cplusplus)
extern "C" {
#elif 0
}
#endif

void Platform_init(void);

/**
 * Sleep briefly until next interrupt
 */
extern void Platform_wfi(void);

/* Enter a low-power state, turning off some systems,
 * then wait for an interrupt.
 * External interrupts must have been configured to ensure
 * that the device wakes up again.
 */
extern void Platform_low_power_wfi(void);

/* Check whether the board may be put into deep sleep. */
extern bool Platform_DeepSleepEnabled(void);


/* The tracker2.c sources use "UDP_MODEM_INIT" to refer to the
 * selected modem configuration that will be passed to
 * Thingstream_createModemTransport(). We store this selection
 * in a global variable.
 */
extern ThingstreamModemUdpInit *modem_init;
#define UDP_MODEM_INIT        modem_init


bool Platform_modemEnable(void);
bool Platform_modemDisable(void);
bool Platform_gnssEnable(void);
bool Platform_gnssDisable(void);

#if defined(DEBUG_ENABLE)
#define DEBUGOUT(...) Thingstream_Util_printf(__VA_ARGS__)
#else /* defined(DEBUG_ENABLE) */
#define DEBUGOUT(...)
#endif /* defined(DEBUG_ENABLE) */


#if defined(__cplusplus)
}
#endif

#endif /* INC_PLATFORM_H_ */
