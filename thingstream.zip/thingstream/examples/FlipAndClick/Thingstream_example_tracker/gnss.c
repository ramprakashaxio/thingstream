/*
 * Copyright 2017-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* An implementation of gnss which uses a ThingstreamTransport
 * instance to communicate with an NMEA source.
 */

#include <stdlib.h>
#include <string.h>
#include "thingstream.h"
#include "flags.h"
#include "gnss.h"
#include "gnss_assist.h"
#include "gnss_parser.h"
#include "gnss_measx.h"
#include "platform.h"
#include "gnss_uart_transport.h"
#include "tracker2.h"
#include "modem_multiplexor.h"
#include "config.h"
#include "json.h"

/**
 * A table of supported "combo" modems whch have built in GNSS.
 * Each entry has the appropriate AT command to init/poll/stop the GNSS.
 */
typedef const struct
{
    const char* ati0;          // Expected ATI response (choice A)
    const char* ati1;          // Expected ATI response (choice B)
    const char* init;          // AT commands to enable/setup GNSS
    const char* assist;        // AT pre-amble commands for AssistNow
    const char* poll;          // AT commands to poll for NMEA data.
    const char* measx_enable;  // AT commands to enable MEASX data.
    const char* measx_poll;    // AT commands to poll for MEASX data.
    const char* stop;          // AT commands to stop NMEA data.
    const uint32_t interval;   // Time (in millis) between polls
} ComboModem;
static ComboModem comboModems[] =
{
  {
     .ati0 = "SARA-R422M8S",
     .ati1 = "SARA-R510M8S",
     .init = "AT+UGPS=1,0,127\n" // Turn on GNSS (will fail if already on)
             "AT+UGGSV=1\n"
             "AT+UGGGA=1",
     .assist = "AT+UGUBX=\"B56206040400FFFF00000000\"\n" // hard reset GNSS
               "AT+UGPS?\n"                              // wait a while
               "AT+UGUBX=\"B562013400000000\"\n" // FIXME: Why does this help?
               "AT+UGPS?\n",                     // FIXME: Why does this help?
     .poll = "AT+UGGSV?\n"
             "AT+UGGGA?",       // Ask for GGA NMEA line.
     .stop = "AT+UGPS=0",       // Turn off GNSS
     .measx_enable = "AT+UGPS=0\n"  // Turn off GNSS (so we can enable just GPS)
                     "AT+UGPS=1,0,1\n" // Turn on GNSS (just GPS)
                     "AT+UGUBX=\"B56206010300021401216E\"\r\n",
     .measx_poll   = "AT+UGUBX=\"B562021400000000\"\r\n",
     .interval = 1000
  }
  ,
  {
     .ati0 = "SIM868",
     .init = "AT+CGNSPWR=1\n"   // Turn on GNSS (will fail if already on)
             "AT+CGNSTST=1",    // Send GNSS via modem
     .poll = NULL,              // Do not poll
     .stop = "AT+CGNSTST=0\n"   // Turn off GNSS data via modem
             "AT+CGNSPWR=0",    // Turn off GNSS
     .interval = 120000
  }
  ,
  {
     .ati0 = "BG96",
     .init = "AT+QGPS=1\nAT+QGPSLOC=1",  // Turn on GNSS (fail if already on)
     .poll = "AT+QGPSLOC?",     // Poll GNSS via modem
     .stop = "AT+QGPSEND",      // Turn off GNSS data via modem
     .interval = 1000
  }
  ,
  {
     .ati0 = "LENA-R8001M10",
     .init = "AT+UGPS=1,0,127\n" // Turn on GNSS (will fail if already on)
             "AT+UGGSV=1\n"
             "AT+UGGGA=1",
     .poll = "AT+UGGSV?\n"
             "AT+UGGGA?",       // Ask for GGA NMEA line.
     .stop = "AT+UGPS=0",       // Turn off GNSS
     .measx_enable = "AT+UGPS=0\n"  // Turn off GNSS (so we can enable just GPS)
                     "AT+UGPS=1,0,1\n", // Turn on GNSS (just GPS)
     .measx_poll   = "AT+UGUBX=\"B562021400001644\"\r\n",
     .interval = 1000
  }
};
#define NUM_COMBO_MODEMS ((int)(sizeof(comboModems) / sizeof(comboModems[0])))

#if defined(GNSS_ENABLED) && defined(UBLOX_ASSIST_NOW)
/* This is the Unix Epoch when the last AssistNow data was received. */
static uint32_t assistNowEpoch;
#endif /* GNSS_ENABLED && UBLOX_ASSIST_NOW */

/* The index into comboModems[] once supported modem is identified */
static int comboIdx = -1;

/* The cookie to pass to GnssNmea_callback() */
static void *gnss_cookie;

/* A wrapper for GnssNmea_callback() */
static void gnss_modem_callback(const char* data, uint16_t len)
{
    GnssNmea_callback(gnss_cookie, (uint8_t*)data, len);
}

/* The cookie used by gnss_measx_callback to pass to GnssNmea_callback() */
static void *measx_cookie;

/* A MEASX wrapper for GnssNmea_callback() */
static void measx_modem_callback(const char* data, uint16_t len)
{
    GnssNmea_callback(measx_cookie, (uint8_t*)data, len);
}

/*
 * A callback handler to check the response from an ATI command sent to the
 * modem. Use this to detect supported combo modems.
 *
 * If a known modem is detected then comboIdx will be set >=0.
 *
 * @data the response line received from the modem
 * @len the length of the response.
 */
static void ati_callback(const char* data, uint16_t len)
{
    if (comboIdx >= 0)
        return;       // Don't bother checking if we already have a match
    for (int idx = 0; idx < NUM_COMBO_MODEMS; idx++)
    {
        const char* expected0 = comboModems[idx].ati0;
        if (expected0 != NULL)
        {
            uint16_t expectLen0 = strlen(expected0);
            if ((expectLen0 <= len)
             && (strncmp(data, expected0, expectLen0) == 0))
            {
                comboIdx = idx;
                return;
            }
        }
        const char* expected1 = comboModems[idx].ati1;
        if (expected1 != NULL)
        {
            uint16_t expectLen1 = strlen(expected1);
            if ((expectLen1 <= len)
             && (strncmp(data, expected1, expectLen1) == 0))
            {
                comboIdx = idx;
                return;
            }
        }
    }
}

/*
 * Send commands to the modem.
 * A '\n' in the command string is treated as a line separator and
 * is replaced by "\r\n".
 *
 * @param cmds the '\n' separated AT commands to send.
 */
static void sendCommands(const char* cmds)
{
    char buffer[64];
    while (cmds && (*cmds != '\0'))
    {
        const char* end = strchr(cmds, '\n');
        const char* next;
        if (end == NULL)
        {
            next = NULL;
            end = cmds + strlen(cmds);
        }
        else
        {
            next = end + 1;  // Skip '\n'
        }
        uint32_t len = end - cmds;
        if (len > (sizeof(buffer) - 3))
        {
            Thingstream_Util_printf("sendCommands: '%s' too long\n", cmds);
            return;
        }
        memcpy(buffer, cmds, len);
        char *ptr = buffer + len;
        *ptr++ = '\r';
        *ptr++ = '\n';
        *ptr = '\0';
        (void) Tracker_modem_send_line(buffer, 5000);
        cmds = next;
    }
}


uint8_t Gnss_get_location(uint32_t maxtime, int32_t *lat, int32_t *lon)
{
    uint8_t gnssFixQuality = 0;
    ThingstreamTransportResult tRes;

    /* Turn on GNSS (which may already be on) */
    gnss_cookie = GnssNmea_init(true);

    /* Some modems have an integrated GNSS where GNSS commands can be sent
     * to the GNSS via AT commands sent to the modem.
     * Identify the modem so we can enable that feature for supported modems.
     */
    ThingstreamTransport* modem = NULL;
    ThingstreamTransport* gnssST = gnss_uart_transport_create();
    if (gnssST == NULL)
    {
        modem = Tracker_get_modem();
        modem->run(modem, 100);
        Application_activeModemCallback = ati_callback;
        (void) Tracker_modem_send_line("ATI\r\n", 1000);
    }
    if (comboIdx >= 0)
    {
        sendCommands(comboModems[comboIdx].init);
        gnssST = NULL;
        Application_activeModemCallback = gnss_modem_callback;
    }
    else
    {
        /* set up a transport instance to represent the serial connection
         * to the GNSS system. Data read will be sent to GnssNmea_callback()
         * for processing.
         */
        if (gnssST == NULL)
            goto gnss_transport_failed;
        tRes = gnssST->init(gnssST, TRANSPORT_VERSION_1);
        if (tRes != TRANSPORT_SUCCESS)
            goto gnss_init_failed;
        tRes = gnssST->register_callback(gnssST, GnssNmea_callback, gnss_cookie);
        if (tRes != TRANSPORT_SUCCESS)
            goto gnss_register_failed;
    }

#if defined(GNSS_ENABLED) && defined(UBLOX_ASSIST_NOW)
    uint8_t *savedData;
    uint16_t savedLen = Gnss_load_assistNow(&savedData);
    if (savedLen > 0)
    {
        Gnss_install_assistNow(gnssST, savedData, savedLen);
    }
#endif /* GNSS_ENABLED && UBLOX_ASSIST_NOW */

    uint32_t now = Thingstream_Platform_getTimeMillis();
    uint32_t start = now;
    uint32_t gnssTimeout = now + maxtime;

    /* Wait for a fix, polling (if configured) periodically. */
    uint32_t next = now;
    do
    {
        if (TIME_COMPARE(now, >=, gnssTimeout))
        {
            DEBUGOUT("Failed to latch GNSS location\n");
            goto gnss_timeout;
        }
        if (TIME_COMPARE(now, >=, next))
        {
            if (comboIdx >= 0)
            {
               sendCommands(comboModems[comboIdx].poll);
               next = now + comboModems[comboIdx].interval;
            }
            else
            {
               next = now + 120000;
            }
        }
        if (gnssST == NULL)
        {
            modem->run(modem, 1000);
        }
        else
        {
            gnssST->run(gnssST, 1000);
        }
        GnssNmea_wfi();
        now = Thingstream_Platform_getTimeMillis();
    } while ((gnssFixQuality = GnssNmea_getQuality()) == 0);

    /* If we get here, we have achieved a fix */
    DEBUGOUT("GNSS location determined successfully (%d) after %d.%03ds\n",
             gnssFixQuality, (now - start) / 1000, (now - start) % 1000);
    *lat = GnssNmea_getLatitude();
    *lon = GnssNmea_getLongitude();

#if defined(GNSS_ENABLED) && defined(UBLOX_ASSIST_NOW)
    NVMem* nvmem = NVMem_init();
    if (nvmem->assistNow.age != 0)
    {
        int8_t approxLat = ((*lat + 500000) / 1000000);
        int16_t approxLon = ((*lon + 500000) / 1000000);
        int latDiff = nvmem->assistNow.lat - approxLat;
        int lonDiff = nvmem->assistNow.lon - approxLon;

        if ((latDiff | lonDiff) != 0)
        {
            /* Since longitude +179 is close to longitude -179 adjust any
             * differences that are near to +/- 360
             */
            if (lonDiff > 300)
                lonDiff -= 360;
            if (lonDiff < -300)
                lonDiff += 360;
            /* Tf there is a big difference between the stored position and
             * the new (correct) position then invalidate the AssistNow data.
             */
            const int maxDiff = 2;
            if ((latDiff > maxDiff) || (latDiff < -maxDiff)
             || (lonDiff > maxDiff) || (lonDiff < -maxDiff))
            {
                assistNowEpoch = 0;
            }
            nvmem->assistNow.lat = approxLat;
            nvmem->assistNow.lon = approxLon;
            NVMem_commit();
        }
    }
#endif /* GNSS_ENABLED && UBLOX_ASSIST_NOW */

    /* Shutdown the gnss serial transport instance and
     * turn off the GNSS chip to avoid corruption as
     * further GNSS data is received.
     */

  gnss_timeout:
  gnss_register_failed:
    if (gnssST != NULL)
        gnssST->shutdown(gnssST);
  gnss_init_failed:
  gnss_transport_failed:
    if (comboIdx >= 0)
        sendCommands(comboModems[comboIdx].stop);
    GnssNmea_init(false);
    return gnssFixQuality;
}

#if defined(GNSS_ENABLED) && defined(UBLOX_ASSIST_NOW)
/* Cleared by Thingstream_Application_subscribeCallback() to indicate
 * that a AssistNow message from the server was received. If not cleared
 * it is the Thingstream_Platform_getTimeMillis() value when to timeout.
 */
static uint32_t waitAssistNow;

/**
 * Ask for AssistNow data from the Thingstream server
 *
 * @param client the ThingstreamClient to use to request the data.
 * @param pEpochGuess the address of the (best guess) current unix epoch time
 */
void Gnss_request_assistNow(ThingstreamClient * client, uint32_t *pEpochGuess)
{
    ThingstreamClientResult cr;
    NVMem* nvmem = NVMem_init();
    uint32_t fakeEpoch = 0;

    if (pEpochGuess == NULL)
        pEpochGuess = &fakeEpoch;
    /* Estimate age of previous AssistNow data */
    uint32_t secondsSinceLast = (*pEpochGuess - assistNowEpoch);
    if ((secondsSinceLast != 0)
     && (secondsSinceLast < (uint32_t)(nvmem->assistNow.age * 60)))
    {
        /* Data is younger than configured refresh age */
        DEBUGOUT("gnss: AssistNow using previous data (age %d secs %d epoch %d data %d) : %d\n",
                 nvmem->assistNow.age, secondsSinceLast,
                 *pEpochGuess, assistNowEpoch, __LINE__);
        return;
    }
    else
    {
        DEBUGOUT("gnss: AssistNow needs new data (age %d lat %d lon %d secs %d epoch %d data %d) : %d\n",

                 nvmem->assistNow.age,
                 nvmem->assistNow.lat,
                 nvmem->assistNow.lon,
                 secondsSinceLast,
                 *pEpochGuess, assistNowEpoch, __LINE__);
    }

    /* AssistNow enabled, and new AssistNow data is required.
     * Initialise the client
     */
    cr = Thingstream_Client_init(client);
    if (cr != CLIENT_SUCCESS)
    {
        DEBUGOUT("gnss: AssistNow client init fail: %d\n", __LINE__);
        return;
    }
    /* Start building up the json message */
    JsonBuffer jbuf;
    char json_chars[256];
    json_init_buffer(&jbuf, json_chars, sizeof(json_chars));
    json_start_object(&jbuf);
    json_key_append(&jbuf, "AssistNow");
    json_start_object(&jbuf);
    json_named_int32_append(&jbuf, "latitude", nvmem->assistNow.lat);
    json_named_int32_append(&jbuf, "longitude", nvmem->assistNow.lon);
    json_end_object(&jbuf);
    json_end_object(&jbuf);
    uint16_t msgLength = json_terminate(&jbuf);
    DEBUGOUT("gnss: AssistNow request len=%d: %d\n", msgLength, __LINE__);

    /* A connection is needed to be able to receive response */
    cr = Thingstream_Client_connect(client, false, 3, DOMAIN_KEY);
    if (cr != CLIENT_SUCCESS)
    {
        DEBUGOUT("gnss: AssistNow client connect fail: %d\n", __LINE__);
        return;
    }

    /* Publish the data using the connection-less QoS-1 */
    cr = Thingstream_Client_publish(client,
                                    Thingstream_PredefinedSelfTopic,
                                    ThingstreamQOS1, false,
                                    (uint8_t *)json_chars, msgLength);
    if (cr != CLIENT_SUCCESS)
    {
        DEBUGOUT("gnss: AssistNow client publish fail: %d\n", __LINE__);
        return;
    }
    uint32_t now = Thingstream_Platform_getTimeMillis();
    waitAssistNow = now + 10000;
    waitAssistNow |= 1; // Force non-zero
    while ((waitAssistNow != 0) && ((int32_t)(now - waitAssistNow) < 0))
    {
        Thingstream_Client_run(client, 100);
        now = Thingstream_Platform_getTimeMillis();
    }
    if (waitAssistNow == 0)
    {
        /* We expect that the unix epoch has been received from the server
         * and so the value of *pEpochGuess is now fairly accurate.
         */
        assistNowEpoch = *pEpochGuess;
        DEBUGOUT("gnss: AssistNow data received: %d\n", __LINE__);
    }
    Thingstream_Client_run(client, 100);
}

void Gnss_receive_assistNow(const uint8_t *data, uint16_t len)
{
    Gnss_store_assistNow(data, len);

    /* exit early from loop in Gnss_request_assistNow() */
    waitAssistNow = 0;
}

static const uint8_t* send_one_ubx(ThingstreamTransport* combo, const uint8_t *data, const uint8_t* dataEnd)
{
    const char *ubx_msg_start = "AT+UGUBX=\"";
    const uint16_t prefixLen = strlen(ubx_msg_start);
    uint8_t buffer[64 + 3];
    uint8_t *ptr = buffer;
    uint8_t *end = buffer + sizeof(buffer) - 3;
    const uint8_t *ubxEnd = data;
    ubxEnd += 6;              // Skip 2 byte header, class, id, 2-byte len
    ubxEnd += data[4];        // Add len bits 7..0
    ubxEnd += (data[5] << 8); // Add len bits 15..8
    ubxEnd += 2;              // Skip checksum
    memcpy(ptr, ubx_msg_start, prefixLen);
    ptr += prefixLen;
    while ((data < ubxEnd) && (data < dataEnd))
    {
        uint8_t pair = *data++;
        *ptr++ = "0123456789ABCDEF"[ (pair >> 4) & 0xF ];
        *ptr++ = "0123456789ABCDEF"[ (pair >> 0) & 0xF ];
        if (ptr >= end)
        {
            (void) combo->send(combo, 0, buffer, ptr - buffer, 1000);
            ptr = buffer;
        }
        (void) combo->run(combo, 1);
    }
    *ptr++ = '"';
    *ptr++ = '\r';
    *ptr++ = '\n';
    (void) combo->send(combo, 0, buffer, ptr - buffer, 1000);
    (void) combo->run(combo, 50);
    return data;
}

void Gnss_install_assistNow(ThingstreamTransport* gnssST, const uint8_t *data, uint16_t len)
{
    if (len == 0)
    {
        /* Nothing to do */
    }
    else if (gnssST != NULL)
    {
        /* A u-blox modem with a dedicated transport to the GNSS chip */
        (void) gnssST->send(gnssST, 0, (uint8_t*)data, len, 2000);
    }
    else if (comboIdx >= 0)
    {
        /* Some GNSS hardware (e.g. SARA-R422M8S) prefer to be reset before
         * sending the AssistNow data.
         */
        sendCommands(comboModems[comboIdx].assist);
        /* A combo modem, separate the binary data into a number of
         * AT+UBXMGS="..." commands (with hex pairs)
         */
        ThingstreamTransport* combo = Tracker_get_modem_inner();
        const uint8_t* dataEnd = data + len;
        do
        {
            data = send_one_ubx(combo, data, dataEnd);
        } while (data < dataEnd);
    }
    else
    {
        /* Should not get here. */
    }
}
#endif /* GNSS_ENABLED && UBLOX_ASSIST_NOW */

#ifndef MEASX_BUF_LEN
#define MEASX_BUF_LEN (1024)
#endif /* MEASX_BUF_LEN */

bool Gnss_get_measx(uint32_t maxtime, char **measxData, uint16_t *measxLen)
{
    static uint8_t measxBuf[MEASX_BUF_LEN];

    *measxLen = 0;

    /* Some modems have an integrated GNSS to which commands can be sent via
     * modem AT commands.
     * Identify the modem so we can enable that feature for supported modems.
     */
    ThingstreamTransport* modem = NULL;
    ThingstreamTransport* gnssST = gnss_uart_transport_create();
    if (gnssST == NULL)
    {
        modem = Tracker_get_modem();
        modem->run(modem, 100);
        Application_activeModemCallback = ati_callback;
        (void) Tracker_modem_send_line("ATI\r\n", 1000);
    }

    if (comboIdx < 0)
    {
        /* Not currently supported for dedicated GNSS chips (even if u-blox) */
        return false;
    }

    if (comboModems[comboIdx].measx_enable == NULL)
    {
        /* This combo modem is does not support UBX-MEASX */
        return false;
    }

    /* Turn on GNSS.
     * If we are on USB power and this is a repeated button press then
     * GNSS was turned off after the previous fix. We must re-enable it.
     * If starting from power on then GNSS was enabled during startup and
     * re-initialising again here is harmless.
     */
    measx_cookie = GnssNmeaMeasx_init(true, measxBuf, MEASX_BUF_LEN);

    Application_activeModemCallback = measx_modem_callback;

    sendCommands(comboModems[comboIdx].measx_enable);

    /* Wait for a valid measx response */

    uint32_t now = Thingstream_Platform_getTimeMillis();
    uint32_t nextPoll = now;
    uint32_t measxTimeout = now + maxtime;

    while (1)
    {
        if (GnssMeasx_valid(measxData, measxLen))
        {
            DEBUGOUT("GNSS MEASX data obtained\n");
            break;
        }

        now = Thingstream_Platform_getTimeMillis();
        if (TIME_COMPARE(now, >=, nextPoll))
        {
            sendCommands(comboModems[comboIdx].measx_poll);
            nextPoll = now + 1000;
        }
        else if (TIME_COMPARE(now, >=, measxTimeout))
        {
            DEBUGOUT("Failed to get sufficient GNSS MEASX data");
            break;
        }
        GnssNmea_wfi();
        (void) modem->run(modem, 500);
    }

    /* Shutdown the gnss serial transport instance and
     * turn off the GNSS chip to avoid corruption as
     * further GNSS data is received.
     */
    (void) Tracker_modem_send_line("AT+UGPS=0\r\n", 5000);

    GnssNmeaMeasx_init(false, NULL, 0);

    return (*measxLen != 0);
}
