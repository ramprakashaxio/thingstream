/*
 * Copyright 2021-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* Hardware abstraction for Mikroe FlipAndClick board */

#include <Arduino.h>

#include "flags.h"        // configuration
#include <thingstream.h>
#include "platform.h"
#include "click_select.h"
#include "modem_uart_transport.h"
#include "gnss_uart_transport.h"
#include "gnss_assist.h"

void Platform_init(void)
{
    // Stubbed as the FlipAndClick runner already handles initialisation
}

bool Platform_modemEnable(void)
{
    return modemEnable(modemClickIdx, mikroBusSlot);
}

bool Platform_modemDisable(void)
{
    return modemDisable(modemClickIdx, mikroBusSlot);
}


bool Platform_gnssEnable(void)
{
    // Stubbed as the FlipAndClick runner already handles GNSS enable/disable
    return true;
}

bool Platform_gnssDisable(void)
{
    // Stubbed as the FlipAndClick runner already handles GNSS enable/disable
    return true;
}



/* Create a serial transport instance to communicate with the modem. */
ThingstreamTransport* modem_uart_transport_create(void)
{
    enum debugLevel_e debugLevel;
#if defined(DEBUG_LOG_MODEM) && (DEBUG_LOG_MODEM > 0)
    /* Logging inside Tracker_run() will be provided by the Thingstream stack
     * so don't ask for any serial logging.
     */
    debugLevel = DEBUG_NONE;
#else /* DEBUG_LOG_MODEM */
    debugLevel = DEBUG_NORMAL;
#endif /* DEBUG_LOG_MODEM */

    if (slotSerial == NULL)
    {
        DEBUGOUT("modem_uart_transport_create: called with slotSerial NULL\n");
        return NULL;
    }
    slotSerial->begin(115200);
    ThingstreamTransport* transport = serial_transport_create(slotSerial, false, &SERIAL_PORT_MONITOR, debugLevel);
    if (transport == NULL)
    {
        DEBUGOUT("Unable to create serial transport device\n");
    }
    return transport;
}


ThingstreamTransport* gnss_uart_transport_create(void)
{
    return NULL;
}

bool Platform_DeepSleepEnabled(void)
{
    if (SERIAL_PORT_MONITOR)
    {
        /* The USB CDC endpoint has been opened by a connected host, such as a
         * serial terminal program for capturing logs. Avoid entering deep sleep,
         * as this would disconnect USB.
         */
        return false;
    }
    return true;
}

void Platform_wfi(void)
{
    __WFI();
}


void Platform_low_power_wfi(void)
{
    /* enter a deep sleep */
    SysTick->CTRL &= ~SysTick_CTRL_TICKINT_Msk;
    SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;
    __DSB();
    __WFI();
    SCB->SCR &= ~SCB_SCR_SLEEPDEEP_Msk;
    SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;
}


#if defined(GNSS_ENABLED) && defined(UBLOX_ASSIST_NOW)

/* These should be in battery backed-up memory */
static uint8_t assistNowData[UBLOX_ASSIST_NOW_SIZE];
static uint16_t assistNowLen;

void Gnss_store_assistNow(const uint8_t *data, uint16_t len)
{
    if (len <= sizeof(assistNowData))
    {
        memcpy(assistNowData, data, len);
        assistNowLen = len;
    }
    else
    {
        assistNowLen = 0;
    }
}

uint16_t Gnss_load_assistNow(uint8_t **pBuffer)
{
    *pBuffer = assistNowData;
    return assistNowLen;
}
#endif /* GNSS_ENABLED && UBLOX_ASSIST_NOW */
