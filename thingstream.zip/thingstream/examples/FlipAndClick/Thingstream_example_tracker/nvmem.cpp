/*
 * Copyright 2022-2024 Thingstream AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <Arduino.h>
#include "nvmem.h"
#include "tracker2.h"

/* The ram copy returned to callers */
static NVMem nvmem_ram_copy;

/* Initial ROM copy
 */
static const NVMem nvmem_initial =
{
  .platform = NVMEM_FORMAT_VERSION,
  .interval =
  {
    .min = 2,
    .max = 5
  },
  .motionSensitivity = 3,
  .assistNow =
  {
    .age = 0,
    .lat = 0,
    .lon = 0
  },
  .priority =
  {
    [locationGnss]  = 1,
    [locationCell]  = 2,
    [locationWifi]  = -1,
    [locationMeasx] = -1,
    [locationBLE]   = -1,
  }
};


NVMem *NVMem_init(void)
{
    // this might be called multiple times - only do the
    // read the first time

    if (nvmem_ram_copy.platform != NVMEM_FORMAT_VERSION)
    {
        nvmem_ram_copy = nvmem_initial;
    }

    return &nvmem_ram_copy;
}

bool NVMem_commit(void)
{
    // In this example we do not write to non-volatile memory
    return true;
}
